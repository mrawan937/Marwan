import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

/** Small key/value store for values the app generates for itself (e.g. push keys). */
export const appSettingsTable = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
