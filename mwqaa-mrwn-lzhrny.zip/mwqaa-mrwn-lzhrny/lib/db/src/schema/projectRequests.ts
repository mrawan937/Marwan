import {
  index,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// Enum-like columns are stored as text; the API layer validates values
// against the OpenAPI enums, so new services/statuses need no DB migration.
export const projectRequestsTable = pgTable(
  "project_requests",
  {
    id: serial("id").primaryKey(),
    // Clerk identity is assigned from the verified server-side session only.
    clerkUserId: text("clerk_user_id"),
    // Client-generated key makes an uncertain network retry safe.
    submissionId: text("submission_id"),
    name: text("name").notNull(),
    // Optional; only used for a one-line "you have a reply" alert.
    email: text("email"),
    organization: text("organization"),
    service: text("service").notNull(),
    budget: text("budget").notNull().default("undecided"),
    timeline: text("timeline").notNull().default("flexible"),
    description: text("description").notNull(),
    status: text("status").notNull().default("new"),
    adminNotes: text("admin_notes"),
    // Secret for the client's private conversation link (/c/<token>).
    accessToken: text("access_token").notNull(),
    lastMessageAt: timestamp("last_message_at", { withTimezone: true }),
    // Read = last time each side opened the conversation; seen = last poll
    // while it was on screen (used to skip alerts when they're already there).
    // Updates to these four must keep updatedAt unchanged.
    ownerLastReadAt: timestamp("owner_last_read_at", { withTimezone: true }),
    ownerLastSeenAt: timestamp("owner_last_seen_at", { withTimezone: true }),
    assistantPausedAt: timestamp("assistant_paused_at", { withTimezone: true }),
    clientLastReadAt: timestamp("client_last_read_at", { withTimezone: true }),
    clientLastSeenAt: timestamp("client_last_seen_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [
    index("project_requests_status_idx").on(t.status),
    index("project_requests_created_at_idx").on(t.createdAt),
    index("project_requests_clerk_user_id_idx").on(t.clerkUserId),
    uniqueIndex("project_requests_access_token_idx").on(t.accessToken),
    uniqueIndex("project_requests_submission_id_idx").on(t.submissionId),
  ],
);

export const insertProjectRequestSchema = createInsertSchema(
  projectRequestsTable,
).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertProjectRequest = z.infer<typeof insertProjectRequestSchema>;
export type ProjectRequestRow = typeof projectRequestsTable.$inferSelect;
