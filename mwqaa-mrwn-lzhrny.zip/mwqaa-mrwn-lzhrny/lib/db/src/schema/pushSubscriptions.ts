import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { projectRequestsTable } from "./projectRequests";

/**
 * Browser push subscriptions a client allowed for a conversation. One browser
 * has a single endpoint, which may be linked to several of its conversations.
 */
export const pushSubscriptionsTable = pgTable(
  "push_subscriptions",
  {
    id: serial("id").primaryKey(),
    requestId: integer("request_id")
      .notNull()
      .references(() => projectRequestsTable.id, { onDelete: "cascade" }),
    endpoint: text("endpoint").notNull(),
    p256dh: text("p256dh").notNull(),
    auth: text("auth").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    uniqueIndex("push_subscriptions_request_endpoint_idx").on(
      t.requestId,
      t.endpoint,
    ),
  ],
);

export type PushSubscriptionRow = typeof pushSubscriptionsTable.$inferSelect;
