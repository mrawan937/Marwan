import { index, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { projectRequestsTable } from "./projectRequests";

/** Messages between a client and the owner, one thread per project request. */
export const requestMessagesTable = pgTable(
  "request_messages",
  {
    id: serial("id").primaryKey(),
    requestId: integer("request_id")
      .notNull()
      .references(() => projectRequestsTable.id, { onDelete: "cascade" }),
    // "client" | "owner" (validated by the API layer)
    sender: text("sender").notNull(),
    body: text("body").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("request_messages_request_idx").on(t.requestId, t.createdAt)],
);

export type RequestMessageRow = typeof requestMessagesTable.$inferSelect;
