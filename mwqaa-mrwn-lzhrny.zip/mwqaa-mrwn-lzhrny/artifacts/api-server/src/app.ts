import express, {
  type Express,
  type NextFunction,
  type Request,
  type Response,
} from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";
import { isSameOrigin } from "./lib/origin";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();
app.disable("x-powered-by");

// Behind Replit's proxy: lets req.ip reflect the visitor (used for rate limiting).
app.set("trust proxy", true);

app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Content-Security-Policy", "frame-ancestors 'none'; base-uri 'none'");
  if (process.env.NODE_ENV === "production" && req.secure) {
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  }
  next();
});

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          // Conversation tokens are secrets: keep them out of the logs.
          url: req.url
            ?.split("?")[0]
            ?.replace(/^(\/api\/conversations\/)(?!lookup$)[^/]+/, "$1:token"),
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

// Clerk proxy streams raw bytes, so it must come before the body parsers.
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());

const forwarded = (req: Request, header: string) =>
  req.get(header)?.split(",")[0]?.trim();

const requestHasSameOrigin = (req: Request) =>
  isSameOrigin(
    req.get("origin"),
    forwarded(req, "x-forwarded-host") ?? req.get("host"),
    forwarded(req, "x-forwarded-proto") ?? req.protocol,
  );

let crossOriginBlocksSinceLog = 0;
let lastCrossOriginLogAt = 0;

app.use(
  cors((req, callback) => {
    const origin = req.get("origin");
    const allowed = Boolean(origin && requestHasSameOrigin(req));
    callback(null, {
      origin: allowed ? origin : false,
      credentials: true,
      maxAge: 600,
    });
  }),
);

// APIs are same-origin only. CORS alone does not stop simple cross-site
// requests from reaching state-changing endpoints.
app.use((req, res, next) => {
  if (req.get("origin") && !requestHasSameOrigin(req)) {
    crossOriginBlocksSinceLog += 1;
    const now = Date.now();
    if (now - lastCrossOriginLogAt >= 60_000) {
      req.log.warn(
        {
          securityEvent: "cross_origin_block",
          blockedRequests: crossOriginBlocksSinceLog,
        },
        "Cross-origin requests blocked",
      );
      crossOriginBlocksSinceLog = 0;
      lastCrossOriginLogAt = now;
    }
    res.status(403).json({ error: "Cross-origin request blocked" });
    return;
  }
  next();
});

app.use(express.json({ limit: "16kb" }));
app.use(express.urlencoded({ extended: false, limit: "16kb", parameterLimit: 20 }));

app.use(
  clerkMiddleware((req) => ({
    publishableKey: publishableKeyFromHost(
      getClerkProxyHost(req) ?? "",
      process.env.CLERK_PUBLISHABLE_KEY,
    ),
  })),
);

app.use("/api", router);

app.use("/api", (_req: Request, res: Response) => {
  res.status(404).json({ error: "Not found" });
});

app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
  const status =
    typeof err === "object" && err !== null && "status" in err
      ? Number((err as { status: unknown }).status)
      : 500;
  if (status >= 400 && status < 500) {
    res.status(status).json({ error: "Bad request" });
    return;
  }
  req.log.error({ err }, "Unhandled error");
  res.status(500).json({ error: "Something went wrong, please try again" });
});

export default app;
