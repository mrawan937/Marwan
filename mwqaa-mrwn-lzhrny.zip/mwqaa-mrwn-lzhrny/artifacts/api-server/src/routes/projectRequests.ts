import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import { desc, eq } from "drizzle-orm";
import {
  CreateProjectRequestBody,
  CreateProjectRequestResponse,
  ListCustomerProjectRequestsResponse,
} from "@workspace/api-zod";
import {
  db,
  projectRequestsTable,
} from "@workspace/db";
import { rateLimit } from "../lib/rateLimit";
import {
  describeZodError,
  formatReference,
  isSameProjectRequestSubmission,
  normalizeProjectRequestBody,
} from "../lib/projectRequests";
import { notifyOwnerOfNewRequest } from "../lib/notify";
import { newAccessToken, unreadCounts } from "../lib/conversations";

const router: IRouter = Router();
const customerRequestsLimit = rateLimit({
  name: "customer_requests",
  windowMs: 60_000,
  max: 60,
  message: "Too many account requests. Please slow down.",
});
const projectRequestLimit = rateLimit({
  name: "project_request",
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: "Too many requests from this device. Please try again later.",
});

router.get("/customer/project-requests", customerRequestsLimit, async (req, res): Promise<void> => {
  res.set("Cache-Control", "no-store");
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Sign in required" });
    return;
  }

  const rows = await db
    .select({
      id: projectRequestsTable.id,
      accessToken: projectRequestsTable.accessToken,
      service: projectRequestsTable.service,
      status: projectRequestsTable.status,
      lastMessageAt: projectRequestsTable.lastMessageAt,
      createdAt: projectRequestsTable.createdAt,
    })
    .from(projectRequestsTable)
    .where(eq(projectRequestsTable.clerkUserId, userId))
    .orderBy(desc(projectRequestsTable.createdAt));
  const unread = await unreadCounts(rows.map((row) => row.id), "client");

  res.json(
    ListCustomerProjectRequestsResponse.parse(
      rows.map((row) => ({
        reference: formatReference(row.id),
        token: row.accessToken,
        service: row.service,
        status: row.status,
        unreadCount: unread.get(row.id) ?? 0,
        lastMessageAt: row.lastMessageAt,
        createdAt: row.createdAt,
      })),
    ),
  );
});

router.post(
  "/project-requests",
  async (req, res) => {
    const parsed = CreateProjectRequestBody.safeParse(
      normalizeProjectRequestBody(req.body),
    );
    if (!parsed.success) {
      res.status(400).json({ error: describeZodError(parsed.error) });
      return;
    }

    const input = parsed.data;
    const values = {
        clerkUserId: getAuth(req).userId ?? null,
        submissionId: input.submissionId ?? null,
        name: input.name,
        email: input.email ?? null,
        organization: input.organization ?? null,
        service: input.service,
        budget: input.budget ?? "undecided",
        timeline: input.timeline ?? "flexible",
        description: input.description,
        accessToken: newAccessToken(),
      };

    // If the browser lost the response, return the original receipt without
    // counting another submission or sending a second owner notification.
    if (input.submissionId) {
      const [existing] = await db
        .select()
        .from(projectRequestsTable)
        .where(eq(projectRequestsTable.submissionId, input.submissionId))
        .limit(1);
      if (existing) {
        if (!isSameProjectRequestSubmission(existing, values)) {
          res.status(409).json({ error: "This submission key was already used for different details." });
          return;
        }
        res.status(201).json(
          CreateProjectRequestResponse.parse({
            id: existing.id,
            reference: formatReference(existing.id),
            createdAt: existing.createdAt,
            token: existing.accessToken,
          }),
        );
        return;
      }
    }

    let allowed = false;
    projectRequestLimit(req, res, () => {
      allowed = true;
    });
    if (!allowed) return;

    let [row] = input.submissionId
      ? await db
          .insert(projectRequestsTable)
          .values(values)
          .onConflictDoNothing({ target: projectRequestsTable.submissionId })
          .returning()
      : await db.insert(projectRequestsTable).values(values).returning();
    let isNewSubmission = Boolean(row);

    if (!row && input.submissionId) {
      const [existing] = await db
        .select()
        .from(projectRequestsTable)
        .where(eq(projectRequestsTable.submissionId, input.submissionId))
        .limit(1);
      if (!existing) {
        res.status(503).json({ error: "Submission is still being processed. Retry shortly." });
        return;
      }
      if (!isSameProjectRequestSubmission(existing, values)) {
        res.status(409).json({ error: "This submission key was already used for different details." });
        return;
      }
      row = existing;
      isNewSubmission = false;
    }
    if (!row) {
      res.status(500).json({ error: "Could not save project request." });
      return;
    }

    if (isNewSubmission) {
      req.log.info(
        { requestId: row.id, service: input.service },
        "New project request",
      );

      // Awaited (with its own timeout) so the send isn't cut off on hosts that
      // pause work after the response. A failed email never fails the request.
      try {
        const messageId = await notifyOwnerOfNewRequest(row, req.get("origin"));
        req.log.info({ requestId: row.id, messageId }, "Owner notified by email");
      } catch (err) {
        req.log.error({ err, requestId: row.id }, "Owner email notification failed");
      }
    }

    res.status(201).json(
      CreateProjectRequestResponse.parse({
        id: row.id,
        reference: formatReference(row.id),
        createdAt: row.createdAt,
        token: row.accessToken,
      }),
    );
  },
);

export default router;
