import { Router, type IRouter } from "express";
import healthRouter from "./health";
import projectRequestsRouter from "./projectRequests";
import conversationsRouter from "./conversations";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(projectRequestsRouter);
router.use(conversationsRouter);
router.use(adminRouter);

export default router;
