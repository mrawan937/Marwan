import { Router, type IRouter } from "express";
import { and, eq, inArray, notInArray, sql } from "drizzle-orm";
import {
  GetConversationParams,
  GetConversationResponse,
  GetPushPublicKeyResponse,
  LookupConversationsBody,
  LookupConversationsResponse,
  SaveConversationPushSubscriptionBody,
  SaveConversationPushSubscriptionParams,
  SendClientMessageBody,
  SendClientMessageParams,
  SendClientMessageResponse,
} from "@workspace/api-zod";
import { db, projectRequestsTable, pushSubscriptionsTable } from "@workspace/db";
import { rateLimit } from "../lib/rateLimit";
import { describeZodError, formatReference } from "../lib/projectRequests";
import {
  alertClientOfReply,
  addMessage,
  alertOwnerOfMessage,
  addAssistantMessageIfActive,
  cleanMessageBody,
  listMessages,
  markViewing,
  toApiMessage,
  unreadCounts,
} from "../lib/conversations";
import { assistantReplyFor, classifyMessage } from "../lib/message-triage";
import { getVapidKeys } from "../lib/push";
import { isAllowedPushEndpoint } from "../lib/push-endpoint";

/**
 * Public side of the conversations. Whoever holds the secret token from the
 * private link is the client; there is no other sign-in.
 */

const router: IRouter = Router();
const r = projectRequestsTable;
const ps = pushSubscriptionsTable;
const NOT_FOUND = { error: "Conversation not found" };
const MAX_PUSH_SUBSCRIPTIONS = 10;

const readLimit = rateLimit({
  name: "conversation_read",
  windowMs: 60_000,
  max: 300,
  message: "Too many requests. Please slow down.",
});
const sendLimitByIp = rateLimit({
  name: "conversation_message_ip",
  windowMs: 10 * 60_000,
  max: 60,
  message: "Too many messages. Please wait a few minutes.",
});
const sendLimitByConversation = rateLimit({
  name: "conversation_message_token",
  windowMs: 10 * 60_000,
  max: 30,
  message: "Too many messages. Please wait a few minutes.",
  key: (req) => `conversation:${String(req.params.token)}`,
});

// Private content: never cached by browsers or proxies.
router.use("/conversations", (_req, res, next) => {
  res.set("Cache-Control", "no-store");
  next();
});

async function findByToken(token: string) {
  const [row] = await db.select().from(r).where(eq(r.accessToken, token));
  return row ?? null;
}

router.post("/conversations/lookup", readLimit, async (req, res) => {
  const parsed = LookupConversationsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: describeZodError(parsed.error) });
    return;
  }
  const tokens = [...new Set(parsed.data.tokens)];
  if (tokens.length === 0) {
    res.json([]);
    return;
  }

  const rows = await db
    .select({
      id: r.id,
      token: r.accessToken,
      service: r.service,
      status: r.status,
      lastMessageAt: r.lastMessageAt,
    })
    .from(r)
    .where(inArray(r.accessToken, tokens));
  const unread = await unreadCounts(
    rows.map((row) => row.id),
    "owner",
  );

  res.json(
    LookupConversationsResponse.parse(
      rows.map((row) => ({
        token: row.token,
        reference: formatReference(row.id),
        service: row.service,
        status: row.status,
        unreadCount: unread.get(row.id) ?? 0,
        lastMessageAt: row.lastMessageAt,
      })),
    ),
  );
});

router.get("/conversations/:token", readLimit, async (req, res) => {
  const params = GetConversationParams.safeParse(req.params);
  const row = params.success ? await findByToken(params.data.token) : null;
  if (!row) {
    res.status(404).json(NOT_FOUND);
    return;
  }

  const [messages] = await Promise.all([
    listMessages(row.id),
    markViewing(row.id, "client"),
  ]);
  res.json(
    GetConversationResponse.parse({
      reference: formatReference(row.id),
      name: row.name,
      service: row.service,
      status: row.status,
      description: row.description,
      createdAt: row.createdAt,
      ownerLastReadAt: row.ownerLastReadAt,
      messages: messages.map((message) => toApiMessage(message)),
    }),
  );
});

router.post(
  "/conversations/:token/messages",
  sendLimitByIp,
  sendLimitByConversation,
  async (req, res) => {
    const params = SendClientMessageParams.safeParse(req.params);
    if (!params.success) {
      res.status(404).json(NOT_FOUND);
      return;
    }
    const body = SendClientMessageBody.safeParse(req.body);
    const text = body.success ? cleanMessageBody(body.data.body) : null;
    if (!text) {
      res.status(400).json({
        error: body.success ? "Message is empty" : describeZodError(body.error),
      });
      return;
    }

    const row = await findByToken(params.data.token);
    if (!row) {
      res.status(404).json(NOT_FOUND);
      return;
    }
    if (row.status === "archived") {
      res.status(409).json({ error: "This conversation is closed" });
      return;
    }

    const moderationStatus = classifyMessage(text);
    const { message, request } = await addMessage(row.id, "client", text);
    req.log.info({ requestId: row.id }, "Client message");
    await alertOwnerOfMessage(
      req.log,
      request,
      message,
      req.get("origin"),
      moderationStatus === "needs_review",
    );
    const reply = assistantReplyFor(text, moderationStatus);
    if (reply) {
      const automated = await addAssistantMessageIfActive(row.id, reply);
      if (automated) {
        await alertClientOfReply(req.log, automated.request, req.get("origin"), true);
      }
    }
    res.status(201).json(SendClientMessageResponse.parse(toApiMessage(message)));
  },
);

router.put("/conversations/:token/push-subscription", readLimit, async (req, res) => {
  const params = SaveConversationPushSubscriptionParams.safeParse(req.params);
  if (!params.success) {
    res.status(404).json(NOT_FOUND);
    return;
  }
  const body = SaveConversationPushSubscriptionBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: describeZodError(body.error) });
    return;
  }
  const { endpoint, keys } = body.data;
  if (!isAllowedPushEndpoint(endpoint)) {
    res.status(400).json({ error: "Unsupported push service" });
    return;
  }
  const row = await findByToken(params.data.token);
  if (!row) {
    res.status(404).json(NOT_FOUND);
    return;
  }

  await db
    .insert(ps)
    .values({ requestId: row.id, endpoint, p256dh: keys.p256dh, auth: keys.auth })
    .onConflictDoUpdate({
      target: [ps.requestId, ps.endpoint],
      set: { p256dh: keys.p256dh, auth: keys.auth, createdAt: sql`now()` },
    });
  // Keep only the most recent browsers for one conversation.
  const keep = db
    .select({ id: ps.id })
    .from(ps)
    .where(eq(ps.requestId, row.id))
    .orderBy(sql`${ps.createdAt} desc, ${ps.id} desc`)
    .limit(MAX_PUSH_SUBSCRIPTIONS);
  await db
    .delete(ps)
    .where(and(eq(ps.requestId, row.id), notInArray(ps.id, keep)));

  req.log.info({ requestId: row.id }, "Client turned on push notifications");
  res.status(204).end();
});

/**
 * A web app manifest that opens this conversation. The conversation page links
 * it so "Add to Home Screen" (needed for notifications on iPhone) starts at the
 * client's own conversation. Not part of the JSON API contract.
 */
router.get(
  "/conversations/:token/manifest.webmanifest",
  readLimit,
  async (req, res) => {
    const params = GetConversationParams.safeParse(req.params);
    const row = params.success ? await findByToken(params.data.token) : null;
    if (!row) {
      res.status(404).json(NOT_FOUND);
      return;
    }
    const startUrl = `/c/${row.accessToken}`;
    res.type("application/manifest+json").send(
      JSON.stringify({
        id: startUrl,
        name: "مروان الزهراني",
        short_name: "مروان",
        description: `محادثتك على الطلب ${formatReference(row.id)}`,
        lang: "ar",
        dir: "rtl",
        start_url: startUrl,
        scope: "/",
        display: "standalone",
        background_color: "#FCF9F3",
        theme_color: "#141734",
        icons: [
          { src: "/icon-192.png", sizes: "192x192", type: "image/png" },
          { src: "/icon-512.png", sizes: "512x512", type: "image/png" },
        ],
      }),
    );
  },
);

router.get("/push/public-key", readLimit, async (_req, res) => {
  const keys = await getVapidKeys();
  res.json(GetPushPublicKeyResponse.parse({ publicKey: keys.publicKey }));
});

export default router;
