import { Router, type IRouter } from "express";
import {
  and,
  count,
  countDistinct,
  desc,
  eq,
  gt,
  gte,
  ilike,
  isNull,
  or,
  sql,
  type SQL,
} from "drizzle-orm";
import {
  DeleteProjectRequestParams,
  GetAdminConversationParams,
  GetAdminConversationResponse,
  GetAdminSessionResponse,
  GetAdminSummaryResponse,
  GetProjectRequestParams,
  GetProjectRequestResponse,
  ListProjectRequestsQueryParams,
  ListProjectRequestsResponse,
  RequestStatus,
  SendOwnerMessageBody,
  SendOwnerMessageParams,
  SendOwnerMessageResponse,
  ServiceType,
  UpdateProjectRequestBody,
  UpdateProjectRequestParams,
  UpdateProjectRequestResponse,
} from "@workspace/api-zod";
import {
  db,
  projectRequestsTable,
  pushSubscriptionsTable,
  requestMessagesTable,
  type ProjectRequestRow,
} from "@workspace/db";
import { requireAdmin, resolveAdminIdentity } from "../lib/admin";
import { rateLimit } from "../lib/rateLimit";
import {
  addMessage,
  alertClientOfReply,
  cleanMessageBody,
  listMessages,
  markViewing,
  toApiMessage,
  unreadCounts,
} from "../lib/conversations";
import {
  describeZodError,
  escapeLike,
  lastRiyadhDays,
  parseReference,
  toApiProjectRequest,
} from "../lib/projectRequests";

const router: IRouter = Router();
const t = projectRequestsTable;
const m = requestMessagesTable;
const DAY_MS = 24 * 60 * 60 * 1000;
const adminSessionLimit = rateLimit({
  name: "admin_session",
  windowMs: 60_000,
  max: 30,
  message: "Too many sign-in checks. Please try again shortly.",
});
const adminApiLimit = rateLimit({
  name: "admin_api",
  windowMs: 60_000,
  max: 120,
  message: "Too many dashboard requests. Please slow down.",
});

/** Dashboard shape for many rows, with unread client messages counted in one query. */
async function withUnread(rows: ProjectRequestRow[]) {
  const unread = await unreadCounts(
    rows.map((row) => row.id),
    "client",
  );
  return rows.map((row) => toApiProjectRequest(row, unread.get(row.id) ?? 0));
}

router.get("/admin/session", adminSessionLimit, async (req, res) => {
  const identity = await resolveAdminIdentity(req);
  res.json(GetAdminSessionResponse.parse(identity));
});

router.use("/admin", adminApiLimit, requireAdmin);

router.get("/admin/summary", async (_req, res) => {
  const now = new Date();
  const days = lastRiyadhDays(30, now);
  // Start of the oldest charted day in Riyadh (UTC+3, no DST).
  const chartStart = new Date(`${days[0]}T00:00:00+03:00`);
  const riyadhDay = sql<string>`to_char(${t.createdAt} AT TIME ZONE 'Asia/Riyadh', 'YYYY-MM-DD')`;

  const [
    statusRows,
    serviceRows,
    dailyRows,
    [week],
    [month],
    recentRows,
    [unreadRow],
  ] = await Promise.all([
      db.select({ status: t.status, count: count() }).from(t).groupBy(t.status),
      db.select({ service: t.service, count: count() }).from(t).groupBy(t.service),
      db
        .select({ date: riyadhDay, count: count() })
        .from(t)
        .where(gte(t.createdAt, chartStart))
        .groupBy(riyadhDay),
      db
        .select({ count: count() })
        .from(t)
        .where(gte(t.createdAt, new Date(now.getTime() - 7 * DAY_MS))),
      db
        .select({ count: count() })
        .from(t)
        .where(gte(t.createdAt, new Date(now.getTime() - 30 * DAY_MS))),
      db.select().from(t).orderBy(desc(t.createdAt), desc(t.id)).limit(5),
      db
        .select({ count: countDistinct(m.requestId) })
        .from(m)
        .innerJoin(t, eq(t.id, m.requestId))
        .where(
          and(
            eq(m.sender, "client"),
            or(isNull(t.ownerLastReadAt), gt(m.createdAt, t.ownerLastReadAt)),
          ),
        ),
    ]);

  const byStatusMap = new Map(statusRows.map((r) => [r.status, r.count]));
  const byServiceMap = new Map(serviceRows.map((r) => [r.service, r.count]));
  const dailyMap = new Map(dailyRows.map((r) => [r.date, r.count]));
  const statusCount = (s: string) => byStatusMap.get(s) ?? 0;

  res.json(
    GetAdminSummaryResponse.parse({
      total: statusRows.reduce((sum, r) => sum + r.count, 0),
      newCount: statusCount(RequestStatus.new),
      activeCount:
        statusCount(RequestStatus.contacted) +
        statusCount(RequestStatus.in_progress),
      completedCount: statusCount(RequestStatus.completed),
      last7Days: week?.count ?? 0,
      last30Days: month?.count ?? 0,
      unreadConversations: unreadRow?.count ?? 0,
      byStatus: Object.values(RequestStatus).map((status) => ({
        status,
        count: statusCount(status),
      })),
      byService: Object.values(ServiceType).map((service) => ({
        service,
        count: byServiceMap.get(service) ?? 0,
      })),
      daily: days.map((date) => ({ date, count: dailyMap.get(date) ?? 0 })),
      recent: await withUnread(recentRows),
    }),
  );
});

router.get("/admin/project-requests", async (req, res) => {
  const parsed = ListProjectRequestsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: describeZodError(parsed.error) });
    return;
  }
  const { status, service, search } = parsed.data;

  const conditions: SQL[] = [];
  if (status) conditions.push(eq(t.status, status));
  if (service) conditions.push(eq(t.service, service));

  const term = search?.trim();
  if (term) {
    const pattern = `%${escapeLike(term)}%`;
    const matches: SQL[] = [
      ilike(t.name, pattern),
      ilike(t.email, pattern),
      ilike(t.organization, pattern),
      ilike(t.description, pattern),
    ];
    const refId = parseReference(term);
    if (refId !== null) matches.push(eq(t.id, refId));
    conditions.push(or(...matches)!);
  }

  const rows = await db
    .select()
    .from(t)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(t.createdAt), desc(t.id));

  res.json(ListProjectRequestsResponse.parse(await withUnread(rows)));
});

router.get("/admin/project-requests/:id", async (req, res) => {
  const params = GetProjectRequestParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: describeZodError(params.error) });
    return;
  }

  const [row] = await db.select().from(t).where(eq(t.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Request not found" });
    return;
  }
  const [request] = await withUnread([row]);
  res.json(GetProjectRequestResponse.parse(request));
});

router.patch("/admin/project-requests/:id", async (req, res) => {
  const params = UpdateProjectRequestParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: describeZodError(params.error) });
    return;
  }
  const body = UpdateProjectRequestBody.safeParse(req.body ?? {});
  if (!body.success) {
    res.status(400).json({ error: describeZodError(body.error) });
    return;
  }

  const changes: { status?: string; adminNotes?: string | null } = {};
  if (body.data.status !== undefined) changes.status = body.data.status;
  if (body.data.adminNotes !== undefined) {
    const notes = body.data.adminNotes?.trim() ?? "";
    changes.adminNotes = notes === "" ? null : notes;
  }
  if (Object.keys(changes).length === 0) {
    res.status(400).json({ error: "Nothing to update" });
    return;
  }

  const [row] = await db
    .update(t)
    .set(changes)
    .where(eq(t.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Request not found" });
    return;
  }
  const [request] = await withUnread([row]);
  res.json(UpdateProjectRequestResponse.parse(request));
});

router.get("/admin/project-requests/:id/messages", async (req, res) => {
  const params = GetAdminConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: describeZodError(params.error) });
    return;
  }
  const id = params.data.id;
  const [row] = await db.select().from(t).where(eq(t.id, id));
  if (!row) {
    res.status(404).json({ error: "Request not found" });
    return;
  }

  const [messages, [subs]] = await Promise.all([
    listMessages(id),
    db
      .select({ count: count() })
      .from(pushSubscriptionsTable)
      .where(eq(pushSubscriptionsTable.requestId, id)),
    markViewing(id, "owner"),
  ]);
  res.json(
    GetAdminConversationResponse.parse({
      messages: messages.map((message) => toApiMessage(message, true)),
      clientLastReadAt: row.clientLastReadAt,
      clientLastSeenAt: row.clientLastSeenAt,
      pushEnabled: (subs?.count ?? 0) > 0,
      assistantPaused: true,
    }),
  );
});

router.post("/admin/project-requests/:id/messages", async (req, res) => {
  const params = SendOwnerMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: describeZodError(params.error) });
    return;
  }
  const body = SendOwnerMessageBody.safeParse(req.body);
  const text = body.success ? cleanMessageBody(body.data.body) : null;
  if (!text) {
    res.status(400).json({
      error: body.success ? "Message is empty" : describeZodError(body.error),
    });
    return;
  }
  const [row] = await db
    .select({ id: t.id })
    .from(t)
    .where(eq(t.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Request not found" });
    return;
  }

  const { message, request } = await addMessage(row.id, "owner", text);
  req.log.info({ requestId: row.id }, "Owner reply");
  await alertClientOfReply(req.log, request, req.get("origin"));
  res.status(201).json(SendOwnerMessageResponse.parse(toApiMessage(message)));
});

router.delete("/admin/project-requests/:id", async (req, res) => {
  const params = DeleteProjectRequestParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: describeZodError(params.error) });
    return;
  }

  const deleted = await db
    .delete(t)
    .where(eq(t.id, params.data.id))
    .returning({ id: t.id });
  if (deleted.length === 0) {
    res.status(404).json({ error: "Request not found" });
    return;
  }
  res.status(204).end();
});

export default router;
