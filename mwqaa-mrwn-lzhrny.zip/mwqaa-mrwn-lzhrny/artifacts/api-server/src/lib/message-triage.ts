export type MessageModerationStatus = "clear" | "needs_review";
const OWNER_PRESENCE_WINDOW_MS = 15_000;

export function assistantCanReply(
  request: { assistantPausedAt: Date | null; ownerLastSeenAt: Date | null },
  now = Date.now(),
): boolean {
  const ownerIsPresent =
    !!request.ownerLastSeenAt &&
    now - request.ownerLastSeenAt.getTime() < OWNER_PRESENCE_WINDOW_MS;
  return !request.assistantPausedAt && !ownerIsPresent;
}

const reviewTerms = [
  "غبي",
  "حمار",
  "كلب",
  "قذر",
  "نجس",
  "حقير",
  "كذاب",
  "نصاب",
  "اقتلك",
  "بقتلك",
  "ساقتلك",
  "fuck",
  "fucking",
  "idiot",
  "stupid",
  "bitch",
  "asshole",
  "scammer",
  "kill you",
  "i will kill",
];

function normalizeMessage(text: string): string {
  return text
    .normalize("NFKC")
    .toLocaleLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[أإآ]/g, "ا");
}

export function classifyMessage(text: string): MessageModerationStatus {
  const normalized = normalizeMessage(text);
  return reviewTerms.some((term) => normalized.includes(term))
    ? "needs_review"
    : "clear";
}

/** Fixed, source-grounded answers only. Unknown or commercial questions return null. */
export function cannedFaqReply(text: string): string | null {
  const normalized = normalizeMessage(text);
  if (
    /(وش|ايش|ما|ماهي|ما هي).{0,16}(الخدمات|تقدم|تسوي)/u.test(normalized) ||
    /\b(what services|services do you offer|what do you do)\b/i.test(text)
  ) {
    return "أقدّم مواقع تعريفية، أنظمة حجز، تطبيقات جوال، تصميم واجهات، وصيانة وتحديث. أرسل تفاصيل طلبك من نموذج «ابدأ مشروعك»، وسأراجعها وأتابع معك هنا. الأسعار والمدة تُحددان بعد فهم تفاصيل المشروع.";
  }

  if (
    /(كيف|شلون).{0,18}(ابدا|اطلب|مشروع)/u.test(normalized) ||
    /\b(start a project|how do i request|how to start)\b/i.test(text)
  ) {
    return "ابدأ بإرسال تفاصيل مشروعك عبر نموذج «ابدأ مشروعك». ستصلك متابعة عبر هذه المحادثة الخاصة؛ لا ترسل كلمات مرور أو بيانات دفع هنا.";
  }

  return null;
}

export function assistantReplyFor(text: string, moderationStatus: MessageModerationStatus): string | null {
  if (moderationStatus !== "clear") return null;
  return cannedFaqReply(text) ??
    "وصلت رسالتك إلى مروان. لا أملك جوابًا مؤكدًا عن هذا السؤال، وسيكمل معك هنا بعد مراجعته. لا ترسل كلمات مرور أو بيانات دفع.";
}
