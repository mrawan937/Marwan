import webpush from "web-push";
import { eq, inArray } from "drizzle-orm";
import { appSettingsTable, db, pushSubscriptionsTable } from "@workspace/db";
import { adminEmails } from "./admin";
import { siteBaseUrl } from "./site-url";
import { isAllowedPushEndpoint } from "./push-endpoint";

/**
 * Browser push notifications for clients. The VAPID key pair is generated on
 * first use and kept in the database, so every environment gets its own keys
 * with no setup (subscriptions live in the same database).
 */

type VapidKeys = { publicKey: string; privateKey: string };

const VAPID_SETTING = "vapid_keys";
const PUSH_TIMEOUT_MS = 8_000;

let vapidKeys: Promise<VapidKeys> | null = null;

export function getVapidKeys(): Promise<VapidKeys> {
  vapidKeys ??= loadOrCreateVapidKeys().catch((err: unknown) => {
    vapidKeys = null;
    throw err;
  });
  return vapidKeys;
}

async function loadOrCreateVapidKeys(): Promise<VapidKeys> {
  const read = async () =>
    (
      await db
        .select()
        .from(appSettingsTable)
        .where(eq(appSettingsTable.key, VAPID_SETTING))
    )[0];

  let row = await read();
  if (!row) {
    const generated = webpush.generateVAPIDKeys();
    // Two instances may race here; whichever insert wins is the key pair.
    await db
      .insert(appSettingsTable)
      .values({ key: VAPID_SETTING, value: JSON.stringify(generated) })
      .onConflictDoNothing();
    row = await read();
  }
  if (!row) throw new Error("Could not load push keys");
  return JSON.parse(row.value) as VapidKeys;
}

function vapidSubject(): string {
  const site = siteBaseUrl(undefined);
  if (site) return site;
  const [owner] = [...adminEmails()];
  return `mailto:${owner ?? "owner@localhost"}`;
}

export type PushPayload = {
  title: string;
  body: string;
  /** Path relative to the site root, e.g. "c/<token>". */
  path: string;
  /** Notifications with the same tag replace each other on the device. */
  tag: string;
};

/** Sends to every browser subscribed to this conversation; drops dead subscriptions. */
export async function pushToConversation(
  requestId: number,
  payload: PushPayload,
): Promise<{ sent: number; removed: number; failed: number }> {
  const subs = await db
    .select()
    .from(pushSubscriptionsTable)
    .where(eq(pushSubscriptionsTable.requestId, requestId));
  if (subs.length === 0) return { sent: 0, removed: 0, failed: 0 };

  const keys = await getVapidKeys();
  const options = {
    vapidDetails: {
      subject: vapidSubject(),
      publicKey: keys.publicKey,
      privateKey: keys.privateKey,
    },
    TTL: 24 * 60 * 60,
    urgency: "high" as const,
    topic: `mz${requestId}`,
    timeout: PUSH_TIMEOUT_MS,
  };

  const results = await Promise.allSettled(
    subs.map((s) =>
      webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        JSON.stringify(payload),
        options,
      ),
    ),
  );

  const gone: string[] = [];
  let sent = 0;
  let failed = 0;
  results.forEach((result, i) => {
    if (result.status === "fulfilled") {
      sent += 1;
      return;
    }
    const status = (result.reason as { statusCode?: number }).statusCode;
    if (status === 404 || status === 410) gone.push(subs[i]!.endpoint);
    else failed += 1;
  });

  if (gone.length > 0) {
    await db
      .delete(pushSubscriptionsTable)
      .where(inArray(pushSubscriptionsTable.endpoint, gone));
  }
  return { sent, removed: gone.length, failed };
}
