/**
 * Trust only app hosts supplied by the platform. A request Origin is accepted
 * only when it exactly matches one of those HTTPS hosts.
 */
export function siteBaseUrl(origin: string | undefined): string | null {
  const hosts = [
    ...(process.env.REPLIT_DOMAINS ?? "").split(","),
    process.env.REPLIT_DEV_DOMAIN ?? "",
  ]
    .map((host) => host.trim().toLowerCase())
    .filter(Boolean);

  if (origin) {
    try {
      const url = new URL(origin);
      if (url.protocol === "https:" && hosts.includes(url.host.toLowerCase())) {
        return url.origin;
      }
    } catch {
      // Malformed Origin: fall through to the platform-provided host.
    }
  }

  return hosts[0] ? `https://${hosts[0]}` : null;
}