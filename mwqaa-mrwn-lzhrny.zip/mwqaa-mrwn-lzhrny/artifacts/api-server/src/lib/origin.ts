export function isSameOrigin(
  origin: string | undefined,
  host: string | undefined,
  protocol: string | undefined,
): boolean {
  if (!origin || !host || !protocol) return false;

  try {
    const parsed = new URL(origin);
    const normalizedProtocol = protocol.replace(/:$/, "").toLowerCase();
    return (
      (parsed.protocol === "https:" || parsed.protocol === "http:") &&
      parsed.host.toLowerCase() === host.toLowerCase() &&
      parsed.protocol === `${normalizedProtocol}:`
    );
  } catch {
    return false;
  }
}
