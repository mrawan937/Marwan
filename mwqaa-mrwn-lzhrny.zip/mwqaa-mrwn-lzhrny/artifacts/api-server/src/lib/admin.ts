import type { Request, RequestHandler } from "express";
import { clerkClient, getAuth } from "@clerk/express";

export type AdminIdentity = {
  signedIn: boolean;
  isAdmin: boolean;
  email: string | null;
};

const CACHE_TTL_MS = 60_000;
const identityCache = new Map<
  string,
  { value: AdminIdentity; expires: number }
>();

/** Owner emails: allowed into the dashboard and notified of new requests. */
export function adminEmails(): Set<string> {
  return new Set(
    (process.env.ADMIN_EMAILS ?? "")
      .split(",")
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean),
  );
}

/**
 * The dashboard belongs to the site owner only: a signed-in user is an admin
 * when one of their *verified* email addresses is listed in ADMIN_EMAILS.
 */
export async function resolveAdminIdentity(
  req: Request,
): Promise<AdminIdentity> {
  const auth = getAuth(req);
  const userId = auth?.userId;
  if (!userId) return { signedIn: false, isAdmin: false, email: null };

  const cached = identityCache.get(userId);
  if (cached && cached.expires > Date.now()) return cached.value;

  const user = await clerkClient.users.getUser(userId);
  const allowed = adminEmails();
  const isAdmin = user.emailAddresses.some(
    (e) =>
      e.verification?.status === "verified" &&
      allowed.has(e.emailAddress.toLowerCase()),
  );
  const email =
    user.primaryEmailAddress?.emailAddress ??
    user.emailAddresses[0]?.emailAddress ??
    null;

  const value: AdminIdentity = { signedIn: true, isAdmin, email };
  identityCache.set(userId, { value, expires: Date.now() + CACHE_TTL_MS });
  return value;
}

export const requireAdmin: RequestHandler = async (req, res, next) => {
  const identity = await resolveAdminIdentity(req);
  if (!identity.signedIn) {
    res.status(401).json({ error: "Sign in required" });
    return;
  }
  if (!identity.isAdmin) {
    res
      .status(403)
      .json({ error: "This dashboard is only available to the site owner" });
    return;
  }
  next();
};
