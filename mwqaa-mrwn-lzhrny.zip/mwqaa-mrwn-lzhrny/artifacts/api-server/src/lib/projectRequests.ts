import type { ProjectRequestRow } from "@workspace/db";

const OPTIONAL_REQUEST_FIELDS = new Set([
  "email",
  "organization",
  "budget",
  "timeline",
]);

export function formatReference(id: number): string {
  return `MZ-${String(id).padStart(4, "0")}`;
}

/** Trims strings and drops blank optional values before request validation. */
export function normalizeProjectRequestBody(body: unknown): unknown {
  if (!body || typeof body !== "object" || Array.isArray(body)) return body;
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(body)) {
    if (typeof value === "string") {
      const trimmed = value.trim();
      if (trimmed === "" && OPTIONAL_REQUEST_FIELDS.has(key)) continue;
      out[key] = trimmed;
    } else if (value !== null || !OPTIONAL_REQUEST_FIELDS.has(key)) {
      out[key] = value;
    }
  }
  return out;
}

export function isSameProjectRequestSubmission(
  existing: Pick<
    ProjectRequestRow,
    "name" | "email" | "organization" | "service" | "budget" | "timeline" | "description"
  >,
  values: {
    name: string;
    email: string | null;
    organization: string | null;
    service: string;
    budget: string;
    timeline: string;
    description: string;
  },
): boolean {
  return (
    existing.name === values.name &&
    existing.email === values.email &&
    existing.organization === values.organization &&
    existing.service === values.service &&
    existing.budget === values.budget &&
    existing.timeline === values.timeline &&
    existing.description === values.description
  );
}

/** Parses "MZ-0007", "mz7", "#MZ-7" into 7. Plain numbers are not treated as references. */
export function parseReference(input: string): number | null {
  const match = /^#?mz-?0*(\d{1,9})$/i.exec(input.trim());
  return match ? Number(match[1]) : null;
}

/**
 * Dashboard shape of a request. Fields are listed explicitly so secrets such
 * as the conversation token never reach a response by accident.
 */
export function toApiProjectRequest(row: ProjectRequestRow, unreadCount = 0) {
  return {
    id: row.id,
    reference: formatReference(row.id),
    name: row.name,
    email: row.email,
    organization: row.organization,
    service: row.service,
    budget: row.budget,
    timeline: row.timeline,
    description: row.description,
    status: row.status,
    adminNotes: row.adminNotes,
    unreadCount,
    lastMessageAt: row.lastMessageAt,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

/** Escapes LIKE/ILIKE wildcards so user input is matched literally. */
export function escapeLike(input: string): string {
  return input.replace(/[\\%_]/g, (c) => `\\${c}`);
}

/** Calendar date (YYYY-MM-DD) in Riyadh time. */
export function riyadhDate(date: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Riyadh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

/** The last `days` Riyadh calendar dates, oldest first, ending today. */
export function lastRiyadhDays(days: number, now = new Date()): string[] {
  const today = new Date(`${riyadhDate(now)}T00:00:00Z`);
  return Array.from({ length: days }, (_, i) => {
    const d = new Date(today);
    d.setUTCDate(today.getUTCDate() - (days - 1 - i));
    return d.toISOString().slice(0, 10);
  });
}

/** First validation issue as a readable message for ErrorResponse. */
export function describeZodError(error: {
  issues: { path: (string | number)[]; message: string }[];
}): string {
  const issue = error.issues[0];
  if (!issue) return "Invalid input";
  const field = issue.path.join(".");
  return field ? `Invalid "${field}": ${issue.message}` : issue.message;
}
