import { randomUUID } from "node:crypto";
import { ReplitConnectors } from "@replit/connectors-sdk";
import type { ProjectRequestRow, RequestMessageRow } from "@workspace/db";
import { adminEmails } from "./admin";
import { formatReference } from "./projectRequests";
import { siteBaseUrl } from "./site-url";

/**
 * Email alerts, sent from the Gmail account connected to this project:
 * - the owner (ADMIN_EMAILS) hears about new requests and new client messages;
 * - a client who left an email gets one line saying Marwan replied, with a
 *   link back to their conversation and nothing else.
 */

const SEND_TIMEOUT_MS = 8_000;
const SENDER_NAME = "مروان الزهراني";

const SERVICE: Record<string, string> = {
  business_website: "موقع تعريفي",
  booking_system: "نظام حجوزات",
  mobile_app: "تطبيق جوال",
  ui_ux_design: "تصميم واجهات",
  maintenance: "صيانة وتحديث",
  community_package: "باقة المجتمع",
  other: "شيء آخر",
};
const BUDGET: Record<string, string> = {
  under_2k: "أقل من 2,000 ريال",
  from_2k_to_5k: "2,000 – 5,000 ريال",
  from_5k_to_10k: "5,000 – 10,000 ريال",
  over_10k: "أكثر من 10,000 ريال",
  undecided: "لم يحدد بعد",
};
const TIMELINE: Record<string, string> = {
  urgent: "مستعجل",
  within_month: "خلال شهر",
  within_quarter: "خلال 3 أشهر",
  flexible: "مرن",
};

const COLORS = {
  ink: "#141734",
  red: "#CA2C21",
  wool: "#FCF9F3",
  line: "#E8E1D3",
  muted: "#5B5F7A",
};

function escapeHtml(value: string): string {
  return value.replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
}

function headerSafe(value: string): string {
  return value.replace(/[\r\n]+/g, " ").trim();
}

/** RFC 2047 encoded-words, split on character boundaries to stay under the line limit. */
function encodeHeader(value: string): string {
  const words: string[] = [];
  let chunk = "";
  for (const ch of headerSafe(value)) {
    if (Buffer.byteLength(chunk + ch, "utf8") > 45) {
      words.push(chunk);
      chunk = "";
    }
    chunk += ch;
  }
  if (chunk) words.push(chunk);
  return words
    .map((w) => `=?UTF-8?B?${Buffer.from(w, "utf8").toString("base64")}?=`)
    .join("\r\n ");
}

function base64Lines(value: string): string {
  return Buffer.from(value, "utf8")
    .toString("base64")
    .replace(/.{1,76}/g, "$&\r\n");
}

function formatRiyadhTime(date: Date): string {
  return new Intl.DateTimeFormat("ar-SA-u-ca-gregory-nu-latn", {
    timeZone: "Asia/Riyadh",
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

type EmailParts = { subject: string; text: string; html: string };

function button(href: string, label: string): string {
  return `<a href="${escapeHtml(href)}" style="display:inline-block;margin:4px;padding:12px 22px;border-radius:999px;text-decoration:none;font-weight:700;font-size:14px;background:${COLORS.red};color:#ffffff;">${escapeHtml(label)}</a>`;
}

function layout(opts: {
  eyebrow: string;
  title: string;
  reference: string;
  body: string;
  footer: string;
}): string {
  return `<!doctype html>
<html lang="ar" dir="rtl">
<body style="margin:0;padding:24px 12px;background:${COLORS.wool};font-family:Tahoma,'Segoe UI',Arial,sans-serif;">
  <div style="max-width:560px;margin:0 auto;background:#ffffff;border:1px solid ${COLORS.line};border-radius:20px;overflow:hidden;" dir="rtl">
    <div style="background:${COLORS.ink};padding:22px 24px;color:#ffffff;">
      <div style="font-size:13px;opacity:.75;">${escapeHtml(opts.eyebrow)}</div>
      <div style="font-size:22px;font-weight:800;margin-top:4px;" dir="auto">${escapeHtml(opts.title)}</div>
      <div style="font-family:Consolas,Menlo,monospace;font-size:14px;color:#F2B544;margin-top:6px;" dir="ltr">${opts.reference}</div>
    </div>
    ${opts.body}
    <div style="padding:14px 24px;border-top:1px solid ${COLORS.line};color:${COLORS.muted};font-size:12px;line-height:1.8;">
      ${escapeHtml(opts.footer)}
    </div>
  </div>
</body>
</html>`;
}

function quoteBlock(label: string, value: string): string {
  return `<div style="padding:18px 24px 24px;">
      <div style="color:${COLORS.muted};font-size:13px;margin-bottom:8px;">${escapeHtml(label)}</div>
      <div style="background:${COLORS.wool};border-radius:14px;padding:14px 16px;color:${COLORS.ink};font-size:14px;line-height:1.9;white-space:pre-wrap;" dir="auto">${escapeHtml(value)}</div>
    </div>`;
}

const dashboardLink = (baseUrl: string | null, id: number) =>
  baseUrl ? `${baseUrl}/admin/requests/${id}` : null;

export function buildNewRequestEmail(
  row: ProjectRequestRow,
  baseUrl: string | null,
): EmailParts {
  const reference = formatReference(row.id);
  const service = SERVICE[row.service] ?? row.service;
  const url = dashboardLink(baseUrl, row.id);

  const details: [string, string][] = [
    ["الخدمة", service],
    ["الميزانية", BUDGET[row.budget] ?? row.budget],
    ["المدة", TIMELINE[row.timeline] ?? row.timeline],
    ...(row.organization
      ? ([["الجهة", row.organization]] as [string, string][])
      : []),
    ["تنبيه الرد بالبريد", row.email ? "مفعّل" : "لا، داخل الموقع فقط"],
    ["وقت الإرسال", formatRiyadhTime(row.createdAt)],
  ];

  const subject = `طلب جديد ${reference} · ${service} · ${row.name}`;
  const text = [
    `طلب مشروع جديد ${reference}`,
    "",
    `العميل: ${row.name}`,
    ...details.map(([k, v]) => `${k}: ${v}`),
    "",
    "وصف المشروع:",
    row.description,
    "",
    ...(url ? [`افتح الطلب ورد عليه من لوحتك: ${url}`] : []),
  ].join("\n");

  const rows = details
    .map(
      ([k, v]) =>
        `<tr><td style="padding:10px 0;color:${COLORS.muted};font-size:13px;width:38%;border-bottom:1px solid ${COLORS.line};">${escapeHtml(k)}</td><td style="padding:10px 0;color:${COLORS.ink};font-size:14px;font-weight:600;border-bottom:1px solid ${COLORS.line};" dir="auto">${escapeHtml(v)}</td></tr>`,
    )
    .join("");

  const html = layout({
    eyebrow: "طلب مشروع جديد",
    title: row.name,
    reference,
    body: `${url ? `<div style="padding:20px 24px 4px;text-align:center;">${button(url, "افتح الطلب ورد عليه من لوحتك")}</div>` : ""}
    <div style="padding:8px 24px 0;">
      <table role="presentation" style="width:100%;border-collapse:collapse;">${rows}</table>
    </div>
    ${quoteBlock("وصف المشروع", row.description)}`,
    footer: "وصلك هذا التنبيه لأن بريدك الإلكتروني مسجّل بصفته بريد مالك موقع مروان الزهراني. يمكنك الرد على العميل من خلال محادثة الطلب في لوحة التحكم.",
  });

  return { subject, text, html };
}

export function buildClientMessageEmail(
  row: ProjectRequestRow,
  message: RequestMessageRow,
  baseUrl: string | null,
  needsReview = false,
): EmailParts {
  const reference = formatReference(row.id);
  const url = dashboardLink(baseUrl, row.id);
  const subject = needsReview
    ? `رسالة تحتاج مراجعتك · ${reference}`
    : `رسالة جديدة من ${row.name} · ${reference}`;
  const note = needsReview
    ? "أُخفي محتوى الرسالة من البريد لأن الفلتر المحلي رصد ألفاظًا قد تكون مسيئة. راجعها من لوحة التحكم؛ قد يخطئ هذا الفلتر."
    : "لن يصلك تنبيه آخر عبر البريد عن هذه المحادثة حتى تفتحها في لوحة التحكم.";
  const text = [
    needsReview
      ? `رسالة من العميل تحتاج مراجعتك على الطلب ${reference}.`
      : `رسالة جديدة من ${row.name} على الطلب ${reference}:`,
    "",
    ...(needsReview ? [] : [message.body]),
    "",
    ...(url ? [`افتح المحادثة في لوحتك: ${url}`, ""] : []),
    note,
  ].join("\n");
  const html = layout({
    eyebrow: needsReview ? "مراجعة محتوى" : "رسالة جديدة من العميل",
    title: needsReview ? "محتوى الرسالة مخفي" : row.name,
    reference,
    body: `${needsReview ? `<div style="padding:18px 24px 24px;line-height:1.9;">أُخفي النص من البريد. افتح لوحة التحكم لمراجعته بأمان.</div>` : quoteBlock("الرسالة", message.body)}
    ${url ? `<div style="padding:0 24px 22px;text-align:center;">${button(url, "افتح المحادثة في لوحتك")}</div>` : ""}`,
    footer: note,
  });
  return { subject, text, html };
}

export function buildClientReplyEmail(
  row: ProjectRequestRow,
  baseUrl: string,
  automated = false,
): EmailParts {
  const reference = formatReference(row.id);
  const url = `${baseUrl}/c/${row.accessToken}`;
  const line = automated
    ? "لديك رد آلي من مساعد الموقع على سؤال شائع. افتح محادثتك من الرابط التالي:"
    : "لديك رد جديد من مروان. افتح محادثتك من الرابط التالي:";
  const footer =
    "هذا تنبيه آلي. يمكنك قراءة الرد ومتابعة المحادثة من خلال الموقع فقط.";
  return {
    subject: automated
      ? `رد آلي من مساعد الموقع · ${reference}`
      : `رد جديد من مروان · ${reference}`,
    text: [line, url, "", footer].join("\n"),
    html: layout({
      eyebrow: "طلبك",
      title: line,
      reference,
      body: `<div style="padding:24px;text-align:center;">${button(url, "افتح محادثتك")}</div>`,
      footer,
    }),
  };
}

function toRawMessage(to: string[], from: string | null, parts: EmailParts): string {
  const boundary = `mz-${randomUUID()}`;
  const message = [
    ...(from ? [`From: ${encodeHeader(SENDER_NAME)} <${headerSafe(from)}>`] : []),
    `To: ${to.map(headerSafe).join(", ")}`,
    `Subject: ${encodeHeader(parts.subject)}`,
    "MIME-Version: 1.0",
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    "",
    `--${boundary}`,
    "Content-Type: text/plain; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    base64Lines(parts.text),
    `--${boundary}`,
    "Content-Type: text/html; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    base64Lines(parts.html),
    `--${boundary}--`,
    "",
  ].join("\r\n");
  return Buffer.from(message, "utf8").toString("base64url");
}

// The connected account's own address, so the From line can carry a display
// name. Looked up once; if it fails, Gmail fills in the plain address.
let senderAddress: Promise<string | null> | null = null;

function getSenderAddress(): Promise<string | null> {
  senderAddress ??= (async () => {
    const res = await new ReplitConnectors().proxy(
      "google-mail",
      "/gmail/v1/users/me/profile",
      { method: "GET" },
    );
    if (!res.ok) throw new Error(`Gmail profile failed (${res.status})`);
    const json = (await res.json()) as { emailAddress?: string };
    return json.emailAddress ?? null;
  })().catch(() => {
    senderAddress = null;
    return null;
  });
  return senderAddress;
}

async function sendViaGmail(to: string[], parts: EmailParts): Promise<string | null> {
  const raw = toRawMessage(to, await getSenderAddress(), parts);
  // A fresh client per send: the SDK resolves identity and refreshes tokens on each call.
  const res = await new ReplitConnectors().proxy(
    "google-mail",
    "/gmail/v1/users/me/messages/send",
    { method: "POST", body: { raw } },
  );
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`Gmail send failed (${res.status}): ${detail.slice(0, 300)}`);
  }
  const json = (await res.json()) as { id?: string };
  return json.id ?? null;
}

/** Sends with a timeout. Throws on failure so callers can log it. */
async function sendEmail(to: string[], parts: EmailParts): Promise<string | null> {
  let timer: NodeJS.Timeout | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(
      () => reject(new Error(`Gmail send timed out after ${SEND_TIMEOUT_MS}ms`)),
      SEND_TIMEOUT_MS,
    );
  });
  try {
    return await Promise.race([sendViaGmail(to, parts), timeout]);
  } finally {
    clearTimeout(timer);
  }
}

function ownerRecipients(): string[] {
  const to = [...adminEmails()];
  if (to.length === 0) {
    throw new Error("ADMIN_EMAILS is empty, so there is no one to notify");
  }
  return to;
}

export async function notifyOwnerOfNewRequest(
  row: ProjectRequestRow,
  origin: string | undefined,
): Promise<string | null> {
  return sendEmail(ownerRecipients(), buildNewRequestEmail(row, siteBaseUrl(origin)));
}

export async function notifyOwnerOfClientMessage(
  row: ProjectRequestRow,
  message: RequestMessageRow,
  origin: string | undefined,
  needsReview = false,
): Promise<string | null> {
  return sendEmail(
    ownerRecipients(),
    buildClientMessageEmail(row, message, siteBaseUrl(origin), needsReview),
  );
}

export async function notifyClientOfReply(
  row: ProjectRequestRow,
  origin: string | undefined,
  automated = false,
): Promise<string | null> {
  if (!row.email) throw new Error("The client left no email");
  const baseUrl = siteBaseUrl(origin);
  if (!baseUrl) throw new Error("No site address is known for the link");
  return sendEmail([row.email], buildClientReplyEmail(row, baseUrl, automated));
}
