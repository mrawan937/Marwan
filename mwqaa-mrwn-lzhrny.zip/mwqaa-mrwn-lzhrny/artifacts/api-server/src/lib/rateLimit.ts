import type { Request, RequestHandler } from "express";

/**
 * Small in-memory sliding-window limiter, keyed by client IP unless a `key`
 * function is given. Good enough for a single-instance personal site; resets
 * on restart.
 */
export function rateLimit(options: {
  windowMs: number;
  max: number;
  message: string;
  name?: string;
  maxKeys?: number;
  key?: (req: Request) => string;
}): RequestHandler {
  const hits = new Map<string, number[]>();
  const maxKeys = Math.max(1, Math.floor(options.maxKeys ?? 2_000));
  let blockedSinceLog = 0;
  let lastBlockedLogAt = 0;

  const logBlockedBatch = (req: Request) => {
    blockedSinceLog += 1;
    const now = Date.now();
    if (now - lastBlockedLogAt < 30_000) return;
    req.log?.warn(
      {
        securityEvent: "rate_limit",
        limiter: options.name ?? "unnamed",
        blockedRequests: blockedSinceLog,
      },
      "Rate limit blocked requests",
    );
    blockedSinceLog = 0;
    lastBlockedLogAt = now;
  };

  const sweep = setInterval(() => {
    const cutoff = Date.now() - options.windowMs;
    for (const [key, times] of hits) {
      const recent = times.filter((t) => t > cutoff);
      if (recent.length === 0) hits.delete(key);
      else hits.set(key, recent);
    }
  }, options.windowMs);
  sweep.unref();

  return (req, res, next) => {
    const key = options.key?.(req) ?? req.ip ?? "unknown";
    const now = Date.now();
    const cutoff = now - options.windowMs;
    const recent = (hits.get(key) ?? []).filter(
      (t) => t > cutoff,
    );

    if (recent.length >= options.max) {
      const retryAfterSec = Math.ceil(
        (recent[0] + options.windowMs - now) / 1000,
      );
      logBlockedBatch(req);
      res.setHeader("Retry-After", String(Math.max(retryAfterSec, 1)));
      res.status(429).json({ error: options.message });
      return;
    }

    if (!hits.has(key) && hits.size >= maxKeys) {
      // Saturation is rare; prune expired keys once before rejecting new ones.
      for (const [existingKey, times] of hits) {
        if (!times.some((time) => time > cutoff)) hits.delete(existingKey);
      }
      if (hits.size >= maxKeys) {
        logBlockedBatch(req);
        res.setHeader("Retry-After", String(Math.max(1, Math.ceil(options.windowMs / 1000))));
        res.status(429).json({ error: options.message });
        return;
      }
    }

    recent.push(now);
    hits.set(key, recent);
    next();
  };
}
