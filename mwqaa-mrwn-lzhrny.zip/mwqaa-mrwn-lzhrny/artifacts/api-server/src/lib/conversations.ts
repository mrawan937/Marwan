import { randomBytes } from "node:crypto";
import type { Logger } from "pino";
import { and, asc, count, eq, gt, inArray, isNull, or, sql } from "drizzle-orm";
import {
  db,
  projectRequestsTable,
  requestMessagesTable,
  type ProjectRequestRow,
  type RequestMessageRow,
} from "@workspace/db";
import { formatReference } from "./projectRequests";
import { notifyClientOfReply, notifyOwnerOfClientMessage } from "./notify";
import { pushToConversation } from "./push";
import { assistantCanReply, classifyMessage } from "./message-triage";

const r = projectRequestsTable;
const m = requestMessagesTable;

export type Sender = "client" | "owner" | "assistant";

/** Someone polled the conversation this recently, so they are looking at it. */
const PRESENCE_WINDOW_MS = 15_000;

export const MAX_MESSAGE_LENGTH = 2000;

export function newAccessToken(): string {
  return randomBytes(32).toString("base64url");
}

function isPresent(lastSeenAt: Date | null): boolean {
  return !!lastSeenAt && Date.now() - lastSeenAt.getTime() < PRESENCE_WINDOW_MS;
}

export function toApiMessage(message: RequestMessageRow, includeModeration = false) {
  return {
    id: message.id,
    sender: message.sender,
    body: message.body,
    ...(includeModeration
      ? { moderationStatus: classifyMessage(message.body) }
      : {}),
    createdAt: message.createdAt,
  };
}

/** Trims and validates a message body; returns null when it's empty or too long. */
export function cleanMessageBody(body: string): string | null {
  const text = body.replace(/\r\n/g, "\n").trim();
  return text.length > 0 && text.length <= MAX_MESSAGE_LENGTH ? text : null;
}

export function ownerIsPresent(request: ProjectRequestRow): boolean {
  return isPresent(request.ownerLastSeenAt);
}

export function listMessages(requestId: number) {
  return db
    .select()
    .from(m)
    .where(eq(m.requestId, requestId))
    .orderBy(asc(m.createdAt), asc(m.id));
}

/**
 * Per request: messages from `sender` the other side hasn't opened yet.
 * Client messages are compared with the owner's last read, and vice versa.
 */
export async function unreadCounts(
  ids: number[],
  sender: Sender,
): Promise<Map<number, number>> {
  if (ids.length === 0) return new Map();
  const lastRead = sender === "client" ? r.ownerLastReadAt : r.clientLastReadAt;
  const rows = await db
    .select({ requestId: m.requestId, count: count() })
    .from(m)
    .innerJoin(r, eq(r.id, m.requestId))
    .where(
      and(
        inArray(m.requestId, ids),
        sender === "client"
          ? eq(m.sender, "client")
          : inArray(m.sender, ["owner", "assistant"]),
        or(isNull(lastRead), gt(m.createdAt, lastRead)),
      ),
    )
    .groupBy(m.requestId);
  return new Map(rows.map((row) => [row.requestId, row.count]));
}

/**
 * Records that one side has the conversation open: everything so far is read
 * and they are present. Leaves updatedAt alone (this is not an edit).
 */
export async function markViewing(requestId: number, side: Sender) {
  const now = sql`now()`;
  await db
    .update(r)
    .set(
      side === "owner"
        ? {
            ownerLastReadAt: now,
            ownerLastSeenAt: now,
            assistantPausedAt: sql`coalesce(${r.assistantPausedAt}, now())`,
            updatedAt: sql`${r.updatedAt}`,
          }
        : { clientLastReadAt: now, clientLastSeenAt: now, updatedAt: sql`${r.updatedAt}` },
    )
    .where(eq(r.id, requestId));
}

/**
 * Saves a message. Writing counts as reading everything before it, and the
 * owner's first reply moves a "new" request to "contacted".
 */
export async function addMessage(requestId: number, sender: Sender, body: string) {
  return db.transaction(async (tx) => {
    const [message] = await tx
      .insert(m)
      .values({ requestId, sender, body })
      .returning();
    const at = message!.createdAt;
    const [request] = await tx
      .update(r)
      .set(
        sender === "owner"
          ? {
              lastMessageAt: at,
              ownerLastReadAt: at,
              status: sql`case when ${r.status} = 'new' then 'contacted' else ${r.status} end`,
            }
          : sender === "client"
            ? { lastMessageAt: at, clientLastReadAt: at }
            : { lastMessageAt: at },
      )
      .where(eq(r.id, requestId))
      .returning();
    return { message: message!, request: request! };
  });
}

/** Sends a fixed FAQ answer only if the owner has not taken over this thread. */
export async function addAssistantMessageIfActive(requestId: number, body: string) {
  return db.transaction(async (tx) => {
    const [request] = await tx
      .select()
      .from(r)
      .where(eq(r.id, requestId))
      .for("update");
    if (!request || !assistantCanReply(request)) return null;

    const [message] = await tx
      .insert(m)
      .values({ requestId, sender: "assistant", body })
      .returning();
    const [updatedRequest] = await tx
      .update(r)
      .set({ lastMessageAt: message!.createdAt })
      .where(eq(r.id, requestId))
      .returning();
    return { message: message!, request: updatedRequest! };
  });
}

async function unreadSince(requestId: number, sender: Sender, since: Date | null) {
  const [row] = await db
    .select({ count: count() })
    .from(m)
    .where(
      and(
        eq(m.requestId, requestId),
        sender === "client"
          ? eq(m.sender, "client")
          : inArray(m.sender, ["owner", "assistant"]),
        since ? gt(m.createdAt, since) : undefined,
      ),
    );
  return row?.count ?? 0;
}

/**
 * Tells the client Marwan replied, unless they're on the page right now.
 * Push goes out for every reply (same tag, so they replace each other); the
 * email only for the first reply they haven't opened. Never throws.
 */
export async function alertClientOfReply(
  log: Logger,
  request: ProjectRequestRow,
  origin: string | undefined,
  automated = false,
): Promise<void> {
  if (isPresent(request.clientLastSeenAt)) {
    log.info({ requestId: request.id }, "Client is on the page; no alert");
    return;
  }
  const reference = formatReference(request.id);
  const unread = await unreadSince(request.id, "owner", request.clientLastReadAt).catch(
    () => 0,
  );

  const tasks: Promise<void>[] = [
    pushToConversation(request.id, {
      title: automated ? "رد آلي من مساعد الموقع" : "وصلك رد من مروان",
      body: `على طلبك ${reference}. افتح محادثتك لقراءته.`,
      path: `c/${request.accessToken}`,
      tag: `mz-${reference}`,
    }).then(
      (result) => {
        if (result.sent || result.removed || result.failed) {
          log.info({ requestId: request.id, ...result }, "Client push sent");
        }
      },
      (err: unknown) => log.error({ err, requestId: request.id }, "Client push failed"),
    ),
  ];
  if (unread === 1 && request.email) {
    tasks.push(
      notifyClientOfReply(request, origin, automated).then(
        (messageId) => log.info({ requestId: request.id, messageId }, "Client emailed about reply"),
        (err: unknown) => log.error({ err, requestId: request.id }, "Client reply email failed"),
      ),
    );
  }
  await Promise.all(tasks);
}

/**
 * Emails the owner about a client message: only the first one he hasn't
 * opened, and not while he has the conversation open. Never throws.
 */
export async function alertOwnerOfMessage(
  log: Logger,
  request: ProjectRequestRow,
  message: RequestMessageRow,
  origin: string | undefined,
  needsReview = false,
): Promise<void> {
  if (isPresent(request.ownerLastSeenAt)) return;
  try {
    const unread = await unreadSince(request.id, "client", request.ownerLastReadAt);
    if (unread !== 1) return;
    const messageId = await notifyOwnerOfClientMessage(
      request,
      message,
      origin,
      needsReview,
    );
    log.info({ requestId: request.id, messageId }, "Owner emailed about client message");
  } catch (err) {
    log.error({ err, requestId: request.id }, "Owner message email failed");
  }
}
