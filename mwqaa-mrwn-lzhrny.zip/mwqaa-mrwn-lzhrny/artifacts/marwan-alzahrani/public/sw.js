self.addEventListener('push', (event) => {
  let payload = {};
  try {
    payload = event.data ? event.data.json() : {};
  } catch {
    payload = {};
  }

  const title = typeof payload.title === 'string' ? payload.title : 'مروان الزهراني';
  const path = typeof payload.path === 'string' ? payload.path : '';
  const tag = typeof payload.tag === 'string' ? payload.tag : undefined;
  const destination = new URL(path, self.registration.scope);
  const safePath = destination.origin === self.location.origin &&
    destination.href.startsWith(self.registration.scope)
    ? destination.href
    : self.registration.scope;

  event.waitUntil(self.registration.showNotification(title, {
    body: typeof payload.body === 'string' ? payload.body : '',
    icon: new URL('icon-192.png', self.registration.scope).href,
    tag,
    dir: 'rtl',
    data: { path: safePath },
  }));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const path = event.notification.data?.path;
  const destination = new URL(typeof path === 'string' ? path : '', self.registration.scope);
  const url = destination.origin === self.location.origin &&
    destination.href.startsWith(self.registration.scope)
    ? destination.href
    : self.registration.scope;

  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of windows) {
      if (new URL(client.url).origin !== self.location.origin) continue;
      if ('navigate' in client) await client.navigate(url);
      return client.focus();
    }
    return self.clients.openWindow(url);
  })());
});