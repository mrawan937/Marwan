import { Link } from 'wouter';
import { AlertTriangle, MessageCircle, MessageSquareText } from 'lucide-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { SERVICE_LABEL, STATUS_LABEL, STATUS_TONE } from '@/lib/content';
import { useConversationSummaries } from '@/lib/conversations';
import { SiteShell } from '@/components/site-shell';
import { Page } from '@/components/motion';
import { StatusPill } from '@/components/admin-shell';
import { fmtDate, relTime } from '@/lib/format';
import { Skeleton } from '@/components/ui/skeleton';

export default function ConversationsPage() {
  const { t, lang } = useLang();
  useDocTitle({ ar: 'محادثاتي — مروان الزهراني', en: 'My conversations — Marwan Alzahrani' });
  const { saved, summaries, unread, isLoading, error, refetch } = useConversationSummaries();
  const summaryByToken = new Map((summaries ?? []).map((item) => [item.token, item]));

  return (
    <SiteShell>
      <Page className="mx-auto max-w-4xl px-5 pb-16 pt-8 md:px-8">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-primary">{t({ ar: 'مساحة العميل', en: 'Client space' })}</p>
            <h1 className="mt-1 font-display text-3xl font-extrabold sm:text-4xl">{t({ ar: 'محادثاتي', en: 'My conversations' })}</h1>
            <p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">{t({ ar: 'تُحفظ روابط محادثاتك على هذا الجهاز، ويمكنك منها الاطلاع على طلباتك وردود مروان.', en: 'Conversation links are saved on this device so you can return to your requests and Marwan’s replies.' })}</p>
          </div>
          {unread > 0 && <span className="rounded-full bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground">{t({ ar: `رسائل غير مقروءة: ${unread}`, en: `Unread messages: ${unread}` })}</span>}
        </div>

        {isLoading ? (
          <div className="space-y-3">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}</div>
        ) : error ? (
          <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
            <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
            <p className="mt-3 font-semibold">{t({ ar: 'تعذّر تحميل المحادثات', en: 'Couldn’t load conversations' })}</p>
            <button type="button" onClick={() => refetch()} className="mt-4 rounded-full bg-foreground px-5 py-2 text-sm font-semibold text-background">{t({ ar: 'إعادة المحاولة', en: 'Try again' })}</button>
          </div>
        ) : saved.length === 0 ? (
          <div className="rounded-[1.75rem] border border-dashed border-border bg-card p-10 text-center">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-muted"><MessageSquareText className="h-8 w-8 text-primary" /></div>
            <h2 className="mt-5 font-display text-xl font-bold">{t({ ar: 'لا توجد محادثات محفوظة على هذا الجهاز.', en: 'There are no saved conversations on this device.' })}</h2>
            <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted-foreground">{t({ ar: 'إذا أرسلت طلبًا من جهاز آخر، افتح رابط محادثتك على هذا الجهاز لعرضها هنا.', en: 'If you sent a request on another device, open your private conversation link here.' })}</p>
            <Link href="/request" className="mt-6 inline-flex h-11 items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground">{t({ ar: 'أرسل طلبك', en: 'Send a project request' })}</Link>
          </div>
        ) : (
          <ul className="space-y-3">
            {saved.map((item) => {
              const summary = summaryByToken.get(item.token);
              return (
                <li key={item.token}>
                  <Link href={`/c/${item.token}`} className="group block rounded-2xl border border-card-border bg-card p-5 transition-all hover:-translate-y-0.5 hover:shadow-md" data-testid={`link-conversation-${item.reference}`}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="num font-semibold text-primary">{summary?.reference ?? item.reference}</span>
                          {summary && <StatusPill className={STATUS_TONE[summary.status]}>{t(STATUS_LABEL[summary.status])}</StatusPill>}
                        </div>
                        <p className="mt-2 truncate font-semibold">{summary ? t(SERVICE_LABEL[summary.service]) : t({ ar: 'طلب مشروع', en: 'Project request' })}</p>
                        <p className="mt-1 text-xs text-muted-foreground">{t({ ar: 'أُرسل', en: 'Sent' })} {fmtDate(item.createdAt, lang, false)}{summary?.lastMessageAt ? ` · ${relTime(summary.lastMessageAt, lang)}` : ''}</p>
                      </div>
                      <div className="flex shrink-0 items-center gap-2 text-primary">
                        {summary?.unreadCount ? <span className="inline-flex items-center gap-1 rounded-full bg-primary px-2.5 py-1 text-xs font-semibold text-primary-foreground"><MessageCircle className="h-3.5 w-3.5" />{summary.unreadCount}</span> : null}
                        <span className="text-sm font-semibold">{t({ ar: 'افتح', en: 'Open' })}</span>
                      </div>
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </Page>
    </SiteShell>
  );
}