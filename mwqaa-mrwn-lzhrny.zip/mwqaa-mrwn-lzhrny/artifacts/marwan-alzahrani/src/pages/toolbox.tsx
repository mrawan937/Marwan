import { useMemo, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import {
  ArrowDownToLine, ArrowLeft, ArrowRight, ArrowUpRight, Clipboard,
  ClipboardCheck, ExternalLink, FileText, Gauge, Globe2, Layers3, ListChecks,
  LockKeyhole, RotateCcw, ShieldCheck, SquareCheckBig, WandSparkles,
} from 'lucide-react';
import { Link } from 'wouter';
import { useDocTitle, useLang } from '@/lib/i18n';
import { SiteShell } from '@/components/site-shell';

type Bilingual = { ar: string; en: string };
const tx = (ar: string, en: string): Bilingual => ({ ar, en });

const projectTypes = [
  { id: 'business', ar: 'موقع تعريفي لشركة', en: 'Business website' },
  { id: 'store', ar: 'متجر إلكتروني', en: 'Online store' },
  { id: 'platform', ar: 'منصة أو تطبيق ويب', en: 'Web platform or app' },
  { id: 'portfolio', ar: 'معرض أعمال شخصي', en: 'Personal portfolio' },
  { id: 'other', ar: 'فكرة أخرى', en: 'Something else' },
];

const goals = [
  { id: 'presence', ar: 'تعريف الناس بالنشاط', en: 'Introduce the business' },
  { id: 'leads', ar: 'استقبال استفسارات العملاء', en: 'Receive customer enquiries' },
  { id: 'sales', ar: 'بيع المنتجات أو الخدمات', en: 'Sell products or services' },
  { id: 'content', ar: 'نشر محتوى أو أخبار', en: 'Publish content or news' },
  { id: 'workflow', ar: 'تسهيل إجراء أو عملية', en: 'Simplify a process or workflow' },
];

const pages = [
  { id: 'home', ar: 'الرئيسية', en: 'Home' },
  { id: 'about', ar: 'من نحن', en: 'About' },
  { id: 'services', ar: 'الخدمات', en: 'Services' },
  { id: 'work', ar: 'الأعمال', en: 'Work / portfolio' },
  { id: 'contact', ar: 'تواصل معنا', en: 'Contact' },
  { id: 'faq', ar: 'الأسئلة الشائعة', en: 'FAQ' },
  { id: 'policy', ar: 'سياسات المتجر', en: 'Store policies' },
];

const features = [
  { id: 'arabic', ar: 'واجهة عربية من اليمين لليسار', en: 'Arabic right-to-left interface' },
  { id: 'english', ar: 'واجهة إنجليزية', en: 'English interface' },
  { id: 'forms', ar: 'نماذج تواصل أو طلب', en: 'Contact or request forms' },
  { id: 'cms', ar: 'إدارة محتوى سهلة', en: 'Easy content management' },
  { id: 'payments', ar: 'دفع إلكتروني', en: 'Online payments' },
  { id: 'search', ar: 'بحث أو تصفية', en: 'Search or filtering' },
  { id: 'accounts', ar: 'حسابات للمستخدمين', en: 'User accounts' },
  { id: 'analytics', ar: 'قياس الزيارات', en: 'Traffic analytics' },
];

const checklistGroups = [
  {
    id: 'content',
    ar: 'المحتوى والوضوح',
    en: 'Content & clarity',
    icon: FileText,
    items: [
      { id: 'content-purpose', ar: 'رسالة الصفحة الرئيسية واضحة من أول نظرة.', en: 'The homepage purpose is clear at a glance.' },
      { id: 'content-links', ar: 'النصوص والأزرار والروابط خالية من أخطاء ظاهرة.', en: 'Visible copy, buttons and links have been reviewed.' },
      { id: 'content-images', ar: 'للصور المهمة وصف بديل مناسب.', en: 'Important images have useful alternative text.' },
    ],
  },
  {
    id: 'experience',
    ar: 'التجربة وإمكانية الوصول',
    en: 'Experience & accessibility',
    icon: SquareCheckBig,
    items: [
      { id: 'experience-keyboard', ar: 'يمكن التنقل بين العناصر واستخدامها بلوحة المفاتيح.', en: 'Interactive elements work with a keyboard.' },
      { id: 'experience-focus', ar: 'مؤشر التركيز ظاهر، وترتيب التنقل منطقي.', en: 'Focus is visible and navigation order makes sense.' },
      { id: 'experience-mobile', ar: 'اختبرت الصفحات على شاشة جوال ضيقة.', en: 'Pages have been checked at a narrow mobile width.' },
      { id: 'experience-contrast', ar: 'النصوص المهمة واضحة التباين وسهلة القراءة.', en: 'Important text has readable contrast.' },
    ],
  },
  {
    id: 'technical',
    ar: 'الأداء والتقنية',
    en: 'Performance & technical',
    icon: Gauge,
    items: [
      { id: 'technical-speed', ar: 'الصور مضغوطة ولا توجد ملفات كبيرة بلا حاجة.', en: 'Images are optimized and oversized assets removed.' },
      { id: 'technical-links', ar: 'الروابط الداخلية والخارجية تفتح الوجهة الصحيحة.', en: 'Internal and external links lead to the right place.' },
      { id: 'technical-errors', ar: 'راجعت الصفحة بحثًا عن أخطاء ظاهرة في المتصفح.', en: 'The page has been checked for visible browser errors.' },
    ],
  },
  {
    id: 'forms',
    ar: 'النماذج والإطلاق',
    en: 'Forms & launch',
    icon: ShieldCheck,
    items: [
      { id: 'forms-submit', ar: 'أرسلت نموذجًا تجريبيًا وتأكدت من ظهور النتيجة.', en: 'A test form was submitted and its result confirmed.' },
      { id: 'forms-validation', ar: 'رسائل التحقق من المدخلات مفهومة للمستخدم.', en: 'Form validation messages are understandable.' },
      { id: 'launch-domain', ar: 'النطاق و HTTPS يعملان كما ينبغي.', en: 'The domain and HTTPS are working as expected.' },
      { id: 'launch-backup', ar: 'هناك نسخة احتياطية وخطة للرجوع عند الحاجة.', en: 'A backup and rollback plan are ready.' },
    ],
  },
];

function ToolboxIllustration() {
  return (
    <svg viewBox="0 0 520 340" role="img" aria-labelledby="toolbox-svg-title" className="h-full w-full">
      <title id="toolbox-svg-title">A local project brief and launch checklist</title>
      <defs>
        <pattern id="tool-grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M20 0H0V20" fill="none" stroke="currentColor" strokeOpacity=".12" />
        </pattern>
      </defs>
      <rect width="520" height="340" fill="url(#tool-grid)" />
      <circle cx="380" cy="170" r="114" fill="none" stroke="#e7af3f" strokeWidth="1.5" strokeDasharray="4 8" />
      <circle cx="380" cy="170" r="78" fill="#eee4ce" />
      <g transform="translate(265 76) rotate(7 100 110)">
        <rect width="174" height="215" rx="16" fill="#28305e" />
        <path d="M27 35h105M27 52h70" stroke="#f6f0e3" strokeOpacity=".35" strokeWidth="5" strokeLinecap="round" />
        <g fill="none" stroke="#8ed3bb" strokeWidth="2">
          <rect x="26" y="76" width="14" height="14" rx="4" /><path d="m29 83 4 4 7-9" />
          <rect x="26" y="111" width="14" height="14" rx="4" /><path d="m29 118 4 4 7-9" />
          <rect x="26" y="146" width="14" height="14" rx="4" />
        </g>
        <path d="M51 83h88M51 118h74M51 153h59" stroke="#f6f0e3" strokeOpacity=".55" strokeWidth="4" strokeLinecap="round" />
        <path d="M28 184h112" stroke="#e7af3f" strokeWidth="4" strokeLinecap="round" />
      </g>
      <g transform="translate(42 84) rotate(-7 115 75)">
        <rect width="226" height="150" rx="18" fill="#f6f0e3" stroke="#28305e" strokeOpacity=".18" />
        <path d="M0 42h226" stroke="#28305e" strokeOpacity=".15" />
        <circle cx="22" cy="21" r="4" fill="#d8664f" /><circle cx="37" cy="21" r="4" fill="#e7af3f" /><circle cx="52" cy="21" r="4" fill="#3a9b83" />
        <path d="M22 69h46m-46 19h118m-118 19h88" stroke="#28305e" strokeOpacity=".68" strokeWidth="5" strokeLinecap="round" />
        <rect x="22" y="120" width="71" height="16" rx="8" fill="#d8664f" />
        <circle cx="174" cy="83" r="22" fill="#e7af3f" />
        <path d="m164 83 7 7 14-16" fill="none" stroke="#28305e" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </g>
      <path d="M60 286h126m-63-23v23m-24 0 24 24 24-24" fill="none" stroke="#d8664f" strokeWidth="2.5" />
      <text x="383" y="294" textAnchor="middle" fill="#28305e" fontFamily="monospace" fontSize="12">PLAN / CHECK / LAUNCH</text>
    </svg>
  );
}

function SectionHeading({ number, title, subtitle }: { number: string; title: string; subtitle: string }) {
  return (
    <div className="mb-6 flex items-start gap-3">
      <span className="num grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[hsl(var(--ink))] text-xs font-bold text-[hsl(var(--saffron))]">{number}</span>
      <div><h2 className="font-display text-2xl font-bold sm:text-3xl">{title}</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">{subtitle}</p></div>
    </div>
  );
}

function downloadText(filename: string, content: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function copyText(content: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(content);
      return true;
    }
    const field = document.createElement('textarea');
    field.value = content;
    field.setAttribute('readonly', '');
    field.style.position = 'fixed';
    field.style.opacity = '0';
    document.body.appendChild(field);
    field.select();
    const copied = document.execCommand('copy');
    field.remove();
    return copied;
  } catch {
    return false;
  }
}

export default function Toolbox() {
  const { t, dir } = useLang();
  const reduceMotion = useReducedMotion();
  const [projectType, setProjectType] = useState('business');
  const [selectedGoals, setSelectedGoals] = useState<string[]>(['presence']);
  const [selectedPages, setSelectedPages] = useState<string[]>(['home', 'about', 'contact']);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>(['arabic']);
  const [checked, setChecked] = useState<string[]>([]);
  const [briefNotice, setBriefNotice] = useState('');
  const [checklistNotice, setChecklistNotice] = useState('');

  useDocTitle(tx('صندوق الأدوات — مروان الزهراني', 'Toolbox — Marwan Alzahrani'));
  const BackIcon = dir === 'rtl' ? ArrowRight : ArrowLeft;
  const completed = checklistGroups.flatMap((group) => group.items).filter((item) => checked.includes(item.id)).length;
  const total = checklistGroups.reduce((sum, group) => sum + group.items.length, 0);
  const progress = total ? Math.round((completed / total) * 100) : 0;

  const brief = useMemo(() => {
    const pick = (items: { id: string; ar: string; en: string }[], ids: string[]) => {
      const selected = items.filter((item) => ids.includes(item.id));
      return selected.length ? selected.map((item) => t(tx(item.ar, item.en))).join('، ') : t(tx('لم تُحدّد بعد', 'Not selected yet'));
    };
    const type = projectTypes.find((item) => item.id === projectType) ?? projectTypes[0];
    return [
      t(tx('ملخص نطاق المشروع', 'Project scope brief')),
      '—'.repeat(28),
      `${t(tx('نوع المشروع', 'Project type'))}: ${t(tx(type.ar, type.en))}`,
      `${t(tx('الأهداف', 'Goals'))}: ${pick(goals, selectedGoals)}`,
      `${t(tx('الصفحات المطلوبة', 'Pages'))}: ${pick(pages, selectedPages)}`,
      `${t(tx('الخصائص المطلوبة', 'Needed features'))}: ${pick(features, selectedFeatures)}`,
      '',
      t(tx('مسودة أولية للنقاش، وليست عرض سعر أو التزامًا بالتنفيذ.', 'A starting point for discussion, not a quote or delivery commitment.')),
    ].join('\n');
  }, [projectType, selectedGoals, selectedPages, selectedFeatures, t]);

  const checklistSummary = useMemo(() => {
    const lines = [t(tx('ملخص قائمة الإطلاق اليدوية', 'Manual launch checklist summary')), '—'.repeat(28), `${completed}/${total} · ${progress}%`];
    checklistGroups.forEach((group) => {
      lines.push('', t(tx(group.ar, group.en)));
      group.items.forEach((item) => lines.push(`${checked.includes(item.id) ? '[✓]' : '[ ]'} ${t(tx(item.ar, item.en))}`));
    });
    lines.push('', t(tx('الحالة من إدخال المستخدم فقط؛ لم يُفحص أي موقع تلقائيًا.', 'Status is user-entered only; no website was scanned automatically.')));
    return lines.join('\n');
  }, [checked, completed, total, progress, t]);

  const toggle = (id: string, values: string[], setValues: (next: string[]) => void) => {
    setValues(values.includes(id) ? values.filter((value) => value !== id) : [...values, id]);
  };

  const onCopy = async (content: string, setNotice: (message: string) => void) => {
    setNotice(t(tx('جارٍ النسخ…', 'Copying…')));
    const success = await copyText(content);
    setNotice(success ? t(tx('نُسخ إلى الحافظة.', 'Copied to clipboard.')) : t(tx('تعذّر النسخ. يمكنك تنزيل الملف بدلًا من ذلك.', 'Copy was blocked. You can download the file instead.')));
  };

  return (
    <SiteShell>
      <div className="overflow-hidden">
        <section className="relative isolate overflow-hidden bg-[hsl(var(--ink))] text-[hsl(var(--wool))]">
          <div className="sadu-diamonds absolute inset-0 opacity-60" />
          <div className="relative mx-auto grid max-w-7xl items-center gap-8 px-5 pb-14 pt-7 md:px-8 md:pb-20 md:pt-10 lg:grid-cols-[1.05fr_.95fr]">
            <div>
              <Link href="/" data-testid="link-toolbox-home" className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-white/75 transition-colors hover:bg-white/10 hover:text-white">
                <BackIcon className="h-4 w-4" />{t(tx('العودة للرئيسية', 'Back to homepage'))}
              </Link>
              <motion.div initial={reduceMotion ? false : { opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .5 }} className="mt-10 inline-flex items-center gap-2 rounded-full border border-[hsl(var(--saffron)/.38)] bg-[hsl(var(--saffron)/.1)] px-3 py-1.5 text-xs font-bold text-[hsl(var(--saffron))]">
                <WandSparkles className="h-3.5 w-3.5" />{t(tx('أدوات صغيرة، بقرارك أنت', 'Small tools, entirely yours'))}
              </motion.div>
              <motion.h1 initial={reduceMotion ? false : { opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .06, duration: .6 }} className="mt-5 max-w-2xl font-display text-4xl font-extrabold leading-[1.3] sm:text-6xl">
                {t(tx('رتّب فكرتك. ثم أطلقها بثقة.', 'Shape the idea. Launch with confidence.'))}
              </motion.h1>
              <motion.p initial={reduceMotion ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .18 }} className="mt-5 max-w-xl text-base leading-8 text-[hsl(var(--wool)/.72)] sm:text-lg">
                {t(tx('مساحة عملية لتحديد نطاق موقعك ومراجعة ما قبل الإطلاق — بهدوء، ومن دون أن تغادر بياناتك جهازك.', 'A practical space to shape a website scope and review launch day — calmly, without your information leaving your device.'))}
              </motion.p>
              <div className="mt-7 flex flex-wrap gap-2">
                {[tx('محلي بالكامل', 'Browser-only'), tx('لا حساب مطلوب', 'No account'), tx('أنت من يقرر', 'You stay in control')].map((tag) => <span key={tag.en} className="num rounded-full border border-white/15 px-3 py-1.5 text-xs text-white/80">{t(tag)}</span>)}
              </div>
            </div>
            <motion.div initial={reduceMotion ? false : { opacity: 0, y: 12, rotate: 1 }} animate={{ opacity: 1, y: 0, rotate: 0 }} transition={{ delay: .12, duration: .7 }} className="mx-auto w-full max-w-[510px] rounded-[2rem] border border-white/10 bg-[hsl(var(--wool)/.04)] p-3 text-[hsl(var(--wool))] sm:p-5">
              <ToolboxIllustration />
            </motion.div>
          </div>
          <div className="sadu-band relative" />
        </section>

        <main className="mx-auto max-w-7xl px-5 pb-16 pt-9 md:px-8 md:pt-14">
          <section data-testid="notice-toolbox-privacy" aria-labelledby="privacy-title" className="mx-auto max-w-5xl rounded-[1.5rem] border border-primary/25 bg-primary/[.045] p-5 sm:p-6">
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><LockKeyhole className="h-5 w-5" aria-hidden="true" /></span>
              <div>
                <h2 id="privacy-title" className="font-display font-bold">{t(tx('قبل التفاعل — اقرأ هذا أولًا', 'Before you interact — please read'))}</h2>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{t(tx('هذان أداتان تجريبيتان محليتان، وليستا مشروعين لعملاء ولا خدمات جاهزة. تعمل اختياراتك داخل هذه الصفحة فقط، ولا تُرسل أي طلبات API، ولا تُحفظ بعد إعادة تحميل الصفحة. لا تطلب الأدوات اسمًا أو بريدًا أو رقمًا أو أي بيانات تعريفية. يمكنك نسخ النتيجة أو تنزيلها بنفسك. قائمة الإطلاق يدوية بالكامل؛ لا تفحص موقعك ولا تتحقق منه تلقائيًا.', 'These are two local demo tools—not client projects or production services. Your choices live only in this page, no API requests are sent, and nothing is retained after a reload. The tools never ask for your name, email, phone, or other identifying details. You may copy or download your own result. The launch checklist is entirely manual; it does not scan or automatically verify a website.'))}</p>
              </div>
            </div>
          </section>

          <div className="mx-auto mt-12 max-w-5xl">
            <SectionHeading number="01" title={t(tx('ابنِ ملخص نطاق مشروعك', 'Build a project scope brief'))} subtitle={t(tx('اختيارات بسيطة تتحول إلى مسودة مختصرة يمكنك أخذها معك.', 'A few practical choices become a concise draft you can take with you.'))} />
            <div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr]">
              <section className="rounded-[1.6rem] border border-card-border bg-card p-5 shadow-sm sm:p-7" aria-label={t(tx('منشئ نطاق المشروع', 'Project scope builder'))}>
                <fieldset>
                  <legend className="mb-3 text-sm font-bold">{t(tx('ما نوع المشروع؟', 'What kind of project?'))}</legend>
                  <div className="grid gap-2 sm:grid-cols-2" role="group" aria-label={t(tx('نوع المشروع', 'Project type'))}>
                    {projectTypes.map((item) => <button key={item.id} type="button" aria-pressed={projectType === item.id} data-testid={`button-scope-type-${item.id}`} onClick={() => setProjectType(item.id)} className={`min-h-11 rounded-xl border px-3 py-2.5 text-start text-sm font-medium transition-colors ${projectType === item.id ? 'border-primary/50 bg-primary/[.07] text-foreground' : 'border-border bg-background hover:border-primary/35'}`}>
                      <span className={`me-2 inline-grid h-4 w-4 place-items-center rounded-full border align-middle ${projectType === item.id ? 'border-primary' : 'border-muted-foreground/40'}`}>{projectType === item.id && <span className="h-2 w-2 rounded-full bg-primary" />}</span>{t(tx(item.ar, item.en))}
                    </button>)}
                  </div>
                </fieldset>

                {[
                  { id: 'goal', title: tx('ما الهدف الأهم؟', 'What matters most?'), entries: goals, values: selectedGoals, set: setSelectedGoals },
                  { id: 'page', title: tx('ما الصفحات التي تتوقعها؟', 'Which pages do you expect?'), entries: pages, values: selectedPages, set: setSelectedPages },
                  { id: 'feature', title: tx('ما الخصائص التي تحتاجها؟', 'Which features do you need?'), entries: features, values: selectedFeatures, set: setSelectedFeatures },
                ].map((group) => <fieldset key={group.id} className="mt-6 border-t border-border/80 pt-5">
                  <legend className="mb-3 text-sm font-bold">{t(group.title)}</legend>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {group.entries.map((item) => {
                      const active = group.values.includes(item.id);
                      return <label key={item.id} data-testid={`label-scope-${group.id}-${item.id}`} className={`flex min-h-11 cursor-pointer items-center gap-3 rounded-xl border px-3 py-2.5 text-sm transition-colors ${active ? 'border-primary/40 bg-primary/[.055]' : 'border-border bg-background hover:border-primary/30'}`}>
                        <input type="checkbox" data-testid={`input-scope-${group.id}-${item.id}`} checked={active} onChange={() => toggle(item.id, group.values, group.set)} className="h-4 w-4 shrink-0 accent-[hsl(var(--primary))]" />
                        <span>{t(tx(item.ar, item.en))}</span>
                      </label>;
                    })}
                  </div>
                </fieldset>)}
              </section>

              <aside className="flex flex-col rounded-[1.6rem] bg-[hsl(var(--ink))] p-5 text-[hsl(var(--wool))] shadow-sm sm:p-6" aria-labelledby="brief-preview-title">
                <div className="flex items-center justify-between gap-3">
                  <div><p className="num text-[10px] tracking-wider text-[hsl(var(--saffron))]">LOCAL DRAFT / 01</p><h3 id="brief-preview-title" className="mt-1 font-display text-lg font-bold">{t(tx('المسودة تتشكل هنا', 'Your draft takes shape here'))}</h3></div>
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/10 text-[hsl(var(--saffron))]"><FileText className="h-5 w-5" aria-hidden="true" /></span>
                </div>
                <pre data-testid="text-scope-brief" dir={dir} aria-live="polite" className="mt-5 min-h-52 flex-1 whitespace-pre-wrap rounded-xl border border-white/10 bg-white/[.055] p-4 font-sans text-sm leading-7 text-white/85">{brief}</pre>
                <div className="mt-4 flex flex-wrap gap-2">
                  <button type="button" data-testid="button-scope-copy" onClick={() => void onCopy(brief, setBriefNotice)} className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full bg-[hsl(var(--saffron))] px-4 text-sm font-bold text-[hsl(var(--ink))] transition-transform hover:-translate-y-0.5"><Clipboard className="h-4 w-4" />{t(tx('انسخ الملخص', 'Copy brief'))}</button>
                  <button type="button" data-testid="button-scope-download" onClick={() => downloadText('project-scope-brief.txt', brief)} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-white/20 px-4 text-sm font-semibold text-white transition-colors hover:bg-white/10"><ArrowDownToLine className="h-4 w-4" />{t(tx('تنزيل', 'Download'))}</button>
                </div>
                <p data-testid="status-scope-copy" aria-live="polite" className="mt-3 min-h-5 text-xs text-[hsl(var(--wool)/.68)]">{briefNotice}</p>
              </aside>
            </div>
          </div>

          <section className="mx-auto mt-16 max-w-5xl" aria-labelledby="checklist-heading">
            <SectionHeading number="02" title={t(tx('قائمة مراجعة ما قبل الإطلاق', 'A pre-launch review checklist'))} subtitle={t(tx('راجع كل نقطة بنفسك، وعلّم ما تحقق. هذه القائمة تنظّم مراجعتك فقط — وليست فحصًا آليًا للموقع.', 'Review each point yourself and mark what you have verified. This checklist organizes your review—it is not an automated website scan.'))} />
            <div className="grid gap-5 lg:grid-cols-[1fr_290px]">
              <div className="space-y-4">
                {checklistGroups.map((group, groupIndex) => {
                  const Icon = group.icon;
                  return <section key={group.id} data-testid={`section-checklist-group-${group.id}`} className="rounded-[1.4rem] border border-card-border bg-card p-5 shadow-sm sm:p-6">
                    <div className="mb-3 flex items-center gap-3">
                      <span className="grid h-10 w-10 place-items-center rounded-xl bg-muted text-primary"><Icon className="h-5 w-5" aria-hidden="true" /></span>
                      <div><p className="num text-[10px] text-muted-foreground">0{groupIndex + 1} / MANUAL REVIEW</p><h3 className="font-display font-bold">{t(tx(group.ar, group.en))}</h3></div>
                    </div>
                    <ul className="divide-y divide-border/70">
                      {group.items.map((item, itemIndex) => {
                        const isChecked = checked.includes(item.id);
                        return <li key={item.id}>
                          <label data-testid={`label-checklist-${item.id}`} className="flex cursor-pointer items-start gap-3 py-3.5">
                            <input type="checkbox" data-testid={`input-checklist-${item.id}`} checked={isChecked} onChange={() => toggle(item.id, checked, setChecked)} className="mt-1 h-4 w-4 shrink-0 accent-[hsl(var(--primary))]" />
                            <span className={`flex-1 text-sm leading-6 ${isChecked ? 'text-muted-foreground' : 'text-foreground'}`}>{t(tx(item.ar, item.en))}</span>
                            <span className="num text-[10px] text-muted-foreground">{String(itemIndex + 1).padStart(2, '0')}</span>
                          </label>
                        </li>;
                      })}
                    </ul>
                  </section>;
                })}
              </div>
              <aside className="h-fit rounded-[1.5rem] border border-card-border bg-card p-5 shadow-sm lg:sticky lg:top-24">
                <div className="flex items-center justify-between gap-3">
                  <div><p className="num text-[10px] text-muted-foreground">YOUR REVIEW</p><h3 className="mt-1 font-display text-lg font-bold">{t(tx('تقدّم المراجعة', 'Review progress'))}</h3></div>
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#e8f5f2] text-[#16816e]"><ListChecks className="h-5 w-5" /></span>
                </div>
                <div className="mt-5 flex items-end justify-between">
                  <p data-testid="text-checklist-count" className="num text-3xl font-bold text-primary">{completed}<span className="text-base text-muted-foreground"> / {total}</span></p>
                  <span data-testid="text-checklist-percent" className="num text-sm font-semibold text-muted-foreground">{progress}%</span>
                </div>
                <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-muted" role="progressbar" aria-label={t(tx('نسبة إكمال القائمة اليدوية', 'Manual checklist completion'))} aria-valuemin={0} aria-valuemax={total} aria-valuenow={completed}>
                  <div className="h-full rounded-full bg-[#3a9b83]" style={{ width: `${progress}%` }} />
                </div>
                <p className="mt-3 text-xs leading-5 text-muted-foreground">{t(tx('التقدّم محسوب من مربعات الاختيار فقط، ولا يؤكد سلامة الموقع.', 'Progress reflects checkboxes only and does not certify the website.'))}</p>
                <div className="mt-5 grid gap-2">
                  <button type="button" data-testid="button-checklist-copy" onClick={() => void onCopy(checklistSummary, setChecklistNotice)} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-primary px-4 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5"><ClipboardCheck className="h-4 w-4" />{t(tx('انسخ الملخص', 'Copy summary'))}</button>
                  <button type="button" data-testid="button-checklist-download" onClick={() => downloadText('manual-launch-checklist.txt', checklistSummary)} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-border bg-background px-4 text-sm font-semibold transition-colors hover:border-primary/40 hover:bg-muted"><ArrowDownToLine className="h-4 w-4" />{t(tx('تنزيل القائمة', 'Download checklist'))}</button>
                  <button type="button" data-testid="button-checklist-reset" onClick={() => { setChecked([]); setChecklistNotice(''); }} className="inline-flex min-h-10 items-center justify-center gap-2 rounded-full px-4 text-xs font-semibold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"><RotateCcw className="h-3.5 w-3.5" />{t(tx('إلغاء جميع العلامات', 'Clear all checks'))}</button>
                </div>
                <p data-testid="status-checklist-copy" aria-live="polite" className="mt-2 min-h-5 text-xs text-muted-foreground">{checklistNotice}</p>
              </aside>
            </div>
          </section>

          <section className="mx-auto mt-16 max-w-5xl rounded-[1.75rem] bg-muted/70 p-6 sm:p-8" aria-labelledby="references-title">
            <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--ink))] text-[hsl(var(--saffron))]"><Globe2 className="h-5 w-5" /></span><div><h2 id="references-title" className="font-display text-xl font-bold">{t(tx('مراجع رسمية للمراجعة', 'Official references for your review'))}</h2><p className="mt-1 text-sm text-muted-foreground">{t(tx('مصادر موثوقة للتعمق في الوصول والأداء والنماذج.', 'Reliable sources for accessibility, performance and forms.'))}</p></div></div>
            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              {[
                { id: 'wcag', href: 'https://www.w3.org/WAI/standards-guidelines/wcag/', title: tx('إرشادات WCAG', 'WCAG guidelines'), desc: tx('إمكانية الوصول', 'Accessibility'), icon: ShieldCheck },
                { id: 'performance', href: 'https://web.dev/learn/performance/', title: tx('تعلّم أداء الويب', 'Learn web performance'), desc: tx('الأداء والسرعة', 'Performance & speed'), icon: Gauge },
                { id: 'forms', href: 'https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms', title: tx('تعلّم نماذج الويب', 'Learn web forms'), desc: tx('النماذج والتحقق', 'Forms & validation'), icon: Layers3 },
              ].map((reference) => <a key={reference.href} href={reference.href} target="_blank" rel="noreferrer" data-testid={`link-reference-${reference.id}`} className="group flex min-h-[92px] items-center gap-3 rounded-xl border border-border bg-card px-4 py-4 transition-transform hover:-translate-y-0.5 hover:border-primary/40">
                <reference.icon className="h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
                <span className="min-w-0 flex-1"><span className="block text-sm font-semibold">{t(reference.title)}</span><span className="mt-1 block text-xs text-muted-foreground">{t(reference.desc)}</span></span>
                <ExternalLink className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
              </a>)}
            </div>
          </section>

          <div className="mx-auto mt-10 flex max-w-5xl flex-col items-start justify-between gap-4 border-t border-border pt-6 sm:flex-row sm:items-center">
            <p className="max-w-xl text-sm leading-6 text-muted-foreground">{t(tx('أدوات للتفكير والمراجعة؛ لا تحفظ شيئًا ولا تحل محل الاختبار الفعلي أو المراجعة المتخصصة.', 'Tools for thinking and reviewing. They save nothing and do not replace real testing or expert review.'))}</p>
            <Link href="/" data-testid="link-toolbox-work" className="group inline-flex shrink-0 items-center gap-2 text-sm font-semibold text-primary">{t(tx('اكتشف أعمال العملاء', 'Explore client work'))}<ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></Link>
          </div>
        </main>
      </div>
    </SiteShell>
  );
}
