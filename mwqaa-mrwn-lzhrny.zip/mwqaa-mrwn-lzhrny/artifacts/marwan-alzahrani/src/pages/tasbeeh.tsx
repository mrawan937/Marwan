import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { RotateCcw, Check, CalendarDays } from 'lucide-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { Page } from '@/components/motion';
import { SiteShell } from '@/components/site-shell';
import { TasbeehRecitationLibrary } from '@/components/tasbeeh-recitation-library';
import { cn } from '@/lib/utils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const ADHKAR = [
  { id: 'subhan', ar: 'سبحان الله', tr: 'Subḥān Allāh', en: 'Glory be to Allah' },
  { id: 'hamd', ar: 'الحمد لله', tr: 'Al-ḥamdu lillāh', en: 'All praise is due to Allah' },
  { id: 'akbar', ar: 'الله أكبر', tr: 'Allāhu akbar', en: 'Allah is the Greatest' },
  { id: 'tahleel', ar: 'لا إله إلا الله', tr: 'Lā ilāha illā Allāh', en: 'There is no god but Allah' },
  { id: 'istighfar', ar: 'أستغفر الله', tr: 'Astaghfiru Allāh', en: 'I seek Allah’s forgiveness' },
  { id: 'hawqala', ar: 'لا حول ولا قوة إلا بالله', tr: 'Lā ḥawla wa lā quwwata illā billāh', en: 'There is no might nor power except with Allah' },
  { id: 'subhan-azeem', ar: 'سبحان الله وبحمده، سبحان الله العظيم', tr: 'Subḥān Allāhi wa biḥamdih, subḥān Allāhil-ʿaẓīm', en: 'Glory and praise be to Allah; glory be to Allah the Almighty' },
  { id: 'salawat', ar: 'اللهم صلِّ وسلم على نبينا محمد', tr: 'Allāhumma ṣalli wa sallim ʿalā nabiyyinā Muḥammad', en: 'O Allah, send blessings and peace upon our Prophet Muhammad' },
];
const ADHKAR_IDS = new Set(ADHKAR.map(({ id }) => id));
interface State {
  dhikr: string;
  target: number;
  counts: Record<string, number>;
  total: number;
  daily: Record<string, { total: number; counts: Record<string, number> }>;
}
const KEY = 'mz-tasbeeh-v1';
function localDayKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw) as Partial<State>;
      const storedCounts = p.counts && typeof p.counts === 'object' && !Array.isArray(p.counts) ? p.counts : {};
      const counts = Object.fromEntries(
        Object.entries(storedCounts).filter(([id, value]) => ADHKAR_IDS.has(id) && Number.isSafeInteger(value) && value >= 0),
      ) as Record<string, number>;
      const daily: State['daily'] = {};
      if (p.daily && typeof p.daily === 'object' && !Array.isArray(p.daily)) {
        for (const [date, entry] of Object.entries(p.daily)) {
          if (!/^\d{4}-\d{2}-\d{2}$/u.test(date) || !entry || typeof entry !== 'object' || !Number.isSafeInteger(entry.total) || entry.total < 0) continue;
          const rawDailyCounts = entry.counts && typeof entry.counts === 'object' && !Array.isArray(entry.counts) ? entry.counts : {};
          const dailyCounts = Object.fromEntries(
            Object.entries(rawDailyCounts).filter(([id, value]) => ADHKAR_IDS.has(id) && Number.isSafeInteger(value) && value >= 0),
          ) as Record<string, number>;
          daily[date] = { total: entry.total, counts: dailyCounts };
        }
      }
      const recentDaily = Object.fromEntries(Object.entries(daily).sort(([a], [b]) => a.localeCompare(b)).slice(-30));
      return {
        dhikr: typeof p.dhikr === 'string' && ADHKAR_IDS.has(p.dhikr) ? p.dhikr : 'subhan',
        target: Number.isSafeInteger(p.target) && p.target! > 0 && p.target! <= 100000 ? p.target! : 33,
        counts,
        total: Number.isSafeInteger(p.total) && p.total! >= 0 ? p.total! : 0,
        daily: recentDaily,
      };
    }
  } catch {
    /* ignore */
  }
  return { dhikr: 'subhan', target: 33, counts: {}, total: 0, daily: {} };
}

export default function Tasbeeh() {
  const { t, lang } = useLang();
  const reduce = useReducedMotion();
  useDocTitle({ ar: 'السبحة الذكية — مروان الزهراني', en: 'Smart Tasbeeh — Marwan Alzahrani' });
  const [s, setS] = useState<State>(load);
  const [custom, setCustom] = useState('');
  const [burst, setBurst] = useState(0);
  const [done, setDone] = useState(false);
  const [confirmAll, setConfirmAll] = useState(false);
  const doneTimer = useRef<number | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(s));
    } catch {
      /* ignore */
    }
  }, [s]);

  const current = ADHKAR.find((a) => a.id === s.dhikr) ?? ADHKAR[0];
  const count = s.counts[current.id] ?? 0;
  const todayKey = localDayKey();
  const today = s.daily[todayKey] ?? { total: 0, counts: {} };
  const recentDays = Array.from({ length: 7 }, (_, index) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - index));
    const key = localDayKey(date);
    return { key, total: s.daily[key]?.total ?? 0 };
  });
  const inRound = count % s.target;
  const rounds = Math.floor(count / s.target);
  const progress = count > 0 && inRound === 0 ? 1 : inRound / s.target;

  const tap = useCallback(() => {
    setS((p) => {
      const c = (p.counts[p.dhikr] ?? 0) + 1;
      const day = localDayKey();
      const previousDay = p.daily[day] ?? { total: 0, counts: {} };
      const daily = Object.fromEntries(
        Object.entries({
          ...p.daily,
          [day]: { total: previousDay.total + 1, counts: { ...previousDay.counts, [p.dhikr]: (previousDay.counts[p.dhikr] ?? 0) + 1 } },
        }).sort(([a], [b]) => a.localeCompare(b)).slice(-30),
      );
      if (c % p.target === 0) {
        if ('vibrate' in navigator) navigator.vibrate?.([80, 60, 160]);
        setDone(true);
        if (doneTimer.current) window.clearTimeout(doneTimer.current);
        doneTimer.current = window.setTimeout(() => setDone(false), 1800);
      } else if ('vibrate' in navigator) {
        navigator.vibrate?.(8);
      }
      return { ...p, counts: { ...p.counts, [p.dhikr]: c }, total: p.total + 1, daily };
    });
    setBurst((b) => b + 1);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== 'Space' && e.code !== 'Enter') return;
      const target = e.target;
      if (
        target instanceof HTMLElement &&
        (target.isContentEditable || target.closest('button, a, input, textarea, select, [role="button"], [contenteditable="true"]'))
      ) return;
      e.preventDefault();
      tap();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [tap]);

  useEffect(() => () => {
    if (doneTimer.current) window.clearTimeout(doneTimer.current);
  }, []);

  const resetCurrent = () => setS((p) => ({ ...p, counts: { ...p.counts, [p.dhikr]: 0 } }));
  const resetAll = () => setS((p) => ({ ...p, counts: {}, total: 0, daily: {} }));
  const setTarget = (n: number) => setS((p) => ({ ...p, target: n }));

  const R = 140;
  const C = 2 * Math.PI * R;

  return (
    <SiteShell>
      <Page className="mx-auto max-w-6xl px-5 pb-10 pt-4 md:px-8">
        <header className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/[.05] px-3 py-1.5 text-xs font-bold text-primary">{t({ ar: 'ذكر • تلاوة • مصادر', en: 'Dhikr • Recitation • Sources' })}</span>
          <h1 className="mt-3 font-display text-4xl font-extrabold sm:text-5xl">{t({ ar: 'السبحة الذكية', en: 'Smart Tasbeeh' })}</h1>
          <p className="mt-3 leading-7 text-muted-foreground">{t({ ar: 'مساحة مرتبة للعدّ والتلاوة المسجّلة ونصوص الأذكار مع مراجعها، مع بقاء بيانات العدّ على جهازك.', en: 'A clear space for counting, recorded recitation, and sourced dhikr texts, with your counts kept on this device.' })}</p>
        </header>

        <nav aria-label={t({ ar: 'أقسام السبحة الذكية', en: 'Smart Tasbeeh sections' })} className="sticky top-[4.25rem] z-20 mx-auto mt-6 flex max-w-3xl gap-2 overflow-x-auto rounded-full border border-border bg-background/95 p-2 shadow-sm backdrop-blur [scrollbar-width:none]">
          {[
            ['#tasbeeh-counter', { ar: 'السبحة والعداد', en: 'Counter' }],
            ['#verified-recitation', { ar: 'التلاوة', en: 'Recitation' }],
            ['#religious-sources', { ar: 'الأذكار والمصادر', en: 'Dhikr & sources' }],
          ].map(([href, label]) => (
            <a key={href as string} href={href as string} className="shrink-0 rounded-full px-4 py-2 text-sm font-semibold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">{t(label as { ar: string; en: string })}</a>
          ))}
        </nav>

        <p className="mx-auto mt-4 max-w-3xl rounded-xl border border-border bg-card px-4 py-3 text-center text-xs leading-6 text-muted-foreground">
          {t({ ar: 'اختيار الذكر للعدّ لا يعني تخصيص عدد تعبدي له. الأذكار التي نذكر لها فضلًا أو عددًا موثقًا تظهر مع مرجعها؛ ولا تُعامل الأداة كفتوى.', en: 'Choosing a phrase to count does not assign it a prescribed devotional number. Dhikr with a cited virtue or count appears with its source; this tool is not a religious ruling.' })}
        </p>

        <div className="mt-8 flex gap-2 overflow-x-auto pb-2 [scrollbar-width:none] sm:flex-wrap sm:justify-center">
          {ADHKAR.map((a) => (
            <button
              key={a.id}
              type="button"
              onClick={() => {
                setS((p) => ({ ...p, dhikr: a.id }));
              }}
              data-testid={`button-dhikr-${a.id}`}
              aria-pressed={s.dhikr === a.id}
              className={cn(
                'shrink-0 rounded-full border px-4 py-2.5 text-sm font-medium transition-all',
                s.dhikr === a.id ? 'border-foreground bg-foreground text-background' : 'border-border bg-card hover:border-foreground/40',
              )}
              dir="rtl"
              lang="ar"
            >
              {a.ar}
            </button>
          ))}
        </div>

        <div id="tasbeeh-counter" className="mt-8 scroll-mt-28 grid items-start gap-8 lg:grid-cols-[1fr_320px]">
          <div className="flex flex-col items-center">
            <div className="min-h-[7rem] text-center">
              <AnimatePresence mode="wait">
                <motion.div key={current.id} initial={reduce ? false : { opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                  <p lang="ar" dir="rtl" className="font-display text-3xl font-bold leading-snug sm:text-4xl">{current.ar}</p>
                  {lang === 'en' && (
                    <>
                      <p className="mt-2 italic text-muted-foreground">{current.tr}</p>
                      <p className="text-sm text-muted-foreground">{current.en}</p>
                    </>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>

            <motion.button
              type="button"
              onClick={tap}
              whileTap={reduce ? undefined : { scale: 0.96 }}
              data-testid="button-tasbeeh-tap"
              aria-label={t({ ar: 'اضغط لإضافة ذكر', en: 'Tap to count' })}
              className="relative mt-4 grid h-[300px] w-[300px] touch-manipulation select-none place-items-center rounded-full bg-[hsl(var(--ink))] text-[hsl(var(--wool))] shadow-2xl outline-none focus-visible:ring-4 focus-visible:ring-accent sm:h-[340px] sm:w-[340px]"
            >
              <svg viewBox="0 0 320 320" className="absolute inset-0 h-full w-full -rotate-90">
                <circle cx="160" cy="160" r={R} fill="none" stroke="hsl(var(--wool) / 0.1)" strokeWidth="10" />
                <motion.circle
                  cx="160"
                  cy="160"
                  r={R}
                  fill="none"
                  stroke={done ? 'hsl(var(--saffron))' : 'hsl(var(--sadu))'}
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={C}
                  animate={{ strokeDashoffset: C * (1 - progress) }}
                  transition={{ type: 'spring', stiffness: 120, damping: 20 }}
                />
                {Array.from({ length: 33 }).map((_, i) => {
                  const a = (i / 33) * Math.PI * 2;
                  return <circle key={i} cx={160 + Math.cos(a) * 122} cy={160 + Math.sin(a) * 122} r="2.5" fill="hsl(var(--wool) / 0.18)" />;
                })}
              </svg>
              <AnimatePresence>
                {!reduce && (
                  <motion.span key={burst} initial={{ scale: 0.6, opacity: 0.35 }} animate={{ scale: 1.15, opacity: 0 }} transition={{ duration: 0.6 }} className="absolute inset-8 rounded-full bg-primary" />
                )}
              </AnimatePresence>
              <div className="relative text-center">
                <AnimatePresence mode="popLayout">
                  <motion.div key={done ? 'done' : inRound} initial={reduce ? false : { y: 16, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -16, opacity: 0 }} transition={{ duration: 0.18 }} className="num font-display text-8xl font-extrabold" data-testid="text-tasbeeh-count">
                    {done ? <Check className="mx-auto h-20 w-20 text-[hsl(var(--saffron))]" /> : inRound}
                  </motion.div>
                </AnimatePresence>
                <div className="num mt-1 text-sm text-[hsl(var(--wool)/0.6)]">/ {s.target}</div>
                <div className="mt-3 text-xs text-[hsl(var(--wool)/0.5)]">{t({ ar: 'اضغط للتسبيح', en: 'Tap to count' })}</div>
              </div>
            </motion.button>

            <div className="mt-6 flex items-center gap-3">
              <button type="button" onClick={resetCurrent} data-testid="button-tasbeeh-reset" className="inline-flex h-11 items-center gap-2 rounded-full border border-border bg-card px-5 text-sm font-medium">
                <RotateCcw className="h-4 w-4" />
                {t({ ar: 'إعادة ضبط هذا الذكر', en: 'Reset this dhikr' })}
              </button>
            </div>
          </div>

          <aside className="space-y-4">
            <div className="rounded-[1.5rem] border border-card-border bg-card p-5">
              <div className="text-sm font-semibold">{t({ ar: 'الهدف', en: 'Target' })}</div>
              <div className="mt-3 grid grid-cols-3 gap-2">
                {[33, 99, 100].map((n) => (
                  <button key={n} type="button" onClick={() => setTarget(n)} data-testid={`button-target-${n}`} aria-pressed={s.target === n} className={cn('num rounded-xl border py-2.5 text-sm font-semibold', s.target === n ? 'border-primary bg-primary text-primary-foreground' : 'border-border')}>
                    {n}
                  </button>
                ))}
              </div>
              <form
                className="mt-2 flex gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  const n = parseInt(custom, 10);
                  if (n > 0 && n <= 100000) {
                    setTarget(n);
                    setCustom('');
                  }
                }}
              >
                <input value={custom} onChange={(e) => setCustom(e.target.value.replace(/\D/g, ''))} inputMode="numeric" placeholder={t({ ar: 'هدف مخصص', en: 'Custom target' })} data-testid="input-custom-target" className="num min-w-0 flex-1 rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary" />
                <button type="submit" data-testid="button-set-custom" className="rounded-xl bg-foreground px-4 text-sm font-semibold text-background">{t({ ar: 'تعيين', en: 'Set' })}</button>
              </form>
            </div>
            <section aria-labelledby="daily-history-heading" data-testid="section-daily-history" className="rounded-[1.5rem] border border-card-border bg-card p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="inline-flex items-center gap-2 text-sm font-semibold"><CalendarDays className="h-4 w-4 text-primary" aria-hidden="true" />{t({ ar: 'عدد ضغطاتك اليوم', en: 'Your taps today' })}</p>
                  <p className="num mt-1 font-display text-3xl font-extrabold text-primary" data-testid="text-daily-total">{today.total.toLocaleString('en-US')}</p>
                </div>
                <span className="rounded-full bg-primary/10 px-3 py-1.5 text-xs font-semibold text-primary">{t({ ar: 'محلي على جهازك', en: 'Stored on this device' })}</span>
              </div>
              <p className="mt-2 text-xs leading-5 text-muted-foreground">
                {t({ ar: `من الذكر المحدد الآن (${current.ar}): ${today.counts[current.id] ?? 0} ضغطة اليوم.`, en: `For the selected phrase (${current.en}): ${today.counts[current.id] ?? 0} taps today.` })}
              </p>
              <div className="mt-4 border-t border-border pt-3">
                <h2 id="daily-history-heading" className="text-xs font-bold text-muted-foreground">{t({ ar: 'آخر سبعة أيام', en: 'Last seven days' })}</h2>
                <ul className="mt-2 list-none space-y-1.5 p-0">
                  {recentDays.map(({ key, total }) => {
                    const date = new Date(`${key}T12:00:00`);
                    const label = new Intl.DateTimeFormat(lang === 'ar' ? 'ar-SA' : 'en-SA', { weekday: 'short', day: 'numeric', month: 'short' }).format(date);
                    return <li key={key} className="flex items-center justify-between gap-3 text-xs"><span className="text-muted-foreground">{label}{key === todayKey ? ` · ${t({ ar: 'اليوم', en: 'Today' })}` : ''}</span><span className="num font-semibold">{total.toLocaleString('en-US')}</span></li>;
                  })}
                </ul>
              </div>
              <p className="mt-3 text-[11px] leading-5 text-muted-foreground">{t({ ar: 'هذا سجل للضغطات فقط؛ لا يحدد وردًا أو فضلًا شرعيًا. يحتفظ الجهاز بآخر ٣٠ يومًا.', en: 'This records taps only; it does not prescribe a devotional routine or virtue. This device keeps the latest 30 days.' })}</p>
            </section>
            <div className="rounded-[1.5rem] bg-[hsl(var(--ink))] p-5 text-[hsl(var(--wool))]">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-[hsl(var(--wool)/0.6)]">{t({ ar: 'عدد مرات الذكر', en: 'This dhikr' })}</div>
                  <div className="num mt-1 font-display text-3xl font-bold">{count}</div>
                </div>
                <div>
                  <div className="text-xs text-[hsl(var(--wool)/0.6)]">{t({ ar: 'الدورات المكتملة', en: 'Completed rounds' })}</div>
                  <div className="num mt-1 font-display text-3xl font-bold text-[hsl(var(--saffron))]">{rounds}</div>
                </div>
              </div>
              <div className="mt-5 border-t border-[hsl(var(--wool)/0.1)] pt-4">
                <div className="text-xs text-[hsl(var(--wool)/0.6)]">{t({ ar: 'إجمالي الأذكار', en: 'Lifetime total' })}</div>
                <div className="num mt-1 font-display text-4xl font-extrabold" data-testid="text-lifetime-total">{s.total.toLocaleString('en-US')}</div>
              </div>
              <button type="button" onClick={() => setConfirmAll(true)} data-testid="button-reset-all" className="mt-4 text-xs text-[hsl(var(--wool)/0.6)] underline underline-offset-4 hover:text-[hsl(var(--wool))]">
                {t({ ar: 'إعادة ضبط جميع العدادات', en: 'Reset all counters' })}
              </button>
            </div>
            <p className="text-xs leading-6 text-muted-foreground">{t({ ar: 'تُحفظ العدّادات وسجل آخر ٣٠ يومًا على جهازك فقط. يمكنك أيضًا استخدام مفتاح المسافة على الكمبيوتر.', en: 'Counters and the latest 30 days are saved on your device only. On desktop you can also use the space bar.' })}</p>
          </aside>
        </div>

        <TasbeehRecitationLibrary />

        <AlertDialog open={confirmAll} onOpenChange={setConfirmAll}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>{t({ ar: 'إعادة ضبط جميع العدادات؟', en: 'Reset all counters?' })}</AlertDialogTitle>
              <AlertDialogDescription>{t({ ar: 'سيُمسح عدد مرات جميع الأذكار والإجمالي وسجل آخر الأيام المحفوظ على هذا الجهاز. لا يمكن التراجع عن ذلك.', en: 'This clears every dhikr count, lifetime total, and recent daily history saved on this device. It can’t be undone.' })}</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>{t({ ar: 'إلغاء', en: 'Cancel' })}</AlertDialogCancel>
              <AlertDialogAction onClick={resetAll} data-testid="button-confirm-reset-all">{t({ ar: 'إعادة الضبط', en: 'Reset' })}</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </Page>
    </SiteShell>
  );
}
