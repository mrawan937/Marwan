import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useParams } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, ArrowRight, Trash2, AlertTriangle, Loader2, Check, RefreshCw, Send, MessageCircle } from 'lucide-react';
import {
  useGetProjectRequest,
  getGetProjectRequestQueryKey,
  useUpdateProjectRequest,
  useDeleteProjectRequest,
  getListProjectRequestsQueryKey,
  getGetAdminSummaryQueryKey,
  useGetAdminConversation,
  getGetAdminConversationQueryKey,
  useSendOwnerMessage,
  RequestStatus,
} from '@workspace/api-client-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { BUDGET_LABEL, SERVICE_LABEL, STATUS_LABEL, STATUS_TONE, TIMELINE_LABEL } from '@/lib/content';
import { fmtDate, relTime } from '@/lib/format';
import { AdminGate, StatusPill } from '@/components/admin-shell';
import { ServiceIcon } from '@/components/brand';
import { Page } from '@/components/motion';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';

const STATUSES = Object.values(RequestStatus);

function Detail() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const valid = Number.isInteger(id) && id > 0;
  const { t, lang, dir } = useLang();
  const [, setLocation] = useLocation();
  const qc = useQueryClient();
  const { toast } = useToast();
  const q = useGetProjectRequest(id, { query: { enabled: valid, queryKey: getGetProjectRequestQueryKey(id) } });
  const thread = useGetAdminConversation(id, {
    query: {
      enabled: valid,
      queryKey: getGetAdminConversationQueryKey(id),
      refetchInterval: 10_000,
      refetchIntervalInBackground: false,
      refetchOnWindowFocus: true,
    },
  });
  const update = useUpdateProjectRequest();
  const del = useDeleteProjectRequest();
  const send = useSendOwnerMessage();
  const r = q.data;
  useDocTitle({ ar: r ? `${r.reference} — لوحة مروان` : 'طلب — لوحة مروان', en: r ? `${r.reference} — Marwan’s dashboard` : 'Request — Marwan’s dashboard' });

  const [notes, setNotes] = useState('');
  const [reply, setReply] = useState('');
  const [revealedMessages, setRevealedMessages] = useState<Record<number, boolean>>({});
  const initFor = useRef<number | null>(null);
  useEffect(() => {
    if (r && initFor.current !== r.id) {
      initFor.current = r.id;
      setNotes(r.adminNotes ?? '');
    }
  }, [r]);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: getListProjectRequestsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetProjectRequestQueryKey(id) });
    qc.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() });
  };

  const sendReply = () => {
    const body = reply.trim();
    if (!body || body.length > 2000) return;
    send.mutate(
      { id, data: { body } },
      {
        onSuccess: () => {
          setReply('');
          qc.invalidateQueries({ queryKey: getGetAdminConversationQueryKey(id) });
          invalidate();
        },
        onError: () => toast({ title: t({ ar: 'تعذّر إرسال الرد', en: 'Couldn’t send the reply' }), variant: 'destructive' }),
      },
    );
  };

  const setStatus = (status: RequestStatus) =>
    update.mutate(
      { id, data: { status } },
      {
        onSuccess: () => {
          invalidate();
          toast({ title: t({ ar: 'تم تحديث الحالة', en: 'Status updated' }), description: t(STATUS_LABEL[status]) });
        },
        onError: () => toast({ title: t({ ar: 'تعذّر التحديث', en: 'Update failed' }), variant: 'destructive' }),
      },
    );

  const saveNotes = () =>
    update.mutate(
      { id, data: { adminNotes: notes.trim() ? notes : null } },
      {
        onSuccess: () => {
          invalidate();
          toast({ title: t({ ar: 'تم حفظ الملاحظات', en: 'Notes saved' }) });
        },
        onError: () => toast({ title: t({ ar: 'تعذّر الحفظ', en: 'Save failed' }), variant: 'destructive' }),
      },
    );

  const remove = () =>
    del.mutate(
      { id },
      {
        onSuccess: () => {
          qc.removeQueries({ queryKey: getGetProjectRequestQueryKey(id) });
          invalidate();
          toast({ title: t({ ar: 'تم حذف الطلب', en: 'Request deleted' }) });
          setLocation('/admin/requests');
        },
        onError: () => toast({ title: t({ ar: 'تعذّر الحذف', en: 'Delete failed' }), variant: 'destructive' }),
      },
    );

  const Back = dir === 'rtl' ? ArrowRight : ArrowLeft;
  const backLink = (
    <Link href="/admin/requests" data-testid="link-back-requests" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground">
      <Back className="h-4 w-4" />
      {t({ ar: 'كل الطلبات', en: 'All requests' })}
    </Link>
  );

  if (!valid || (q.isError && (q.error as { status?: number })?.status === 404))
    return (
      <div className="space-y-6">
        {backLink}
        <div className="rounded-[1.75rem] border border-dashed border-border bg-card p-12 text-center">
          <h1 className="font-display text-2xl font-bold">{t({ ar: 'الطلب غير موجود', en: 'Request not found' })}</h1>
          <p className="mt-2 text-sm text-muted-foreground">{t({ ar: 'ربما تم حذفه.', en: 'It may have been deleted.' })}</p>
        </div>
      </div>
    );
  if (q.isLoading)
    return (
      <div className="space-y-4">
        <Skeleton className="h-5 w-32" />
        <Skeleton className="h-32 rounded-2xl" />
        <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]"><Skeleton className="h-80 rounded-2xl" /><Skeleton className="h-80 rounded-2xl" /></div>
      </div>
    );
  if (q.isError || !r)
    return (
      <div className="space-y-6">
        {backLink}
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
          <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
          <p className="mt-3 font-semibold">{t({ ar: 'تعذّر تحميل الطلب', en: 'Couldn’t load the request' })}</p>
          <button type="button" onClick={() => q.refetch()} className="mt-4 inline-flex h-10 items-center gap-2 rounded-full bg-foreground px-5 text-sm font-semibold text-background">
            <RefreshCw className="h-4 w-4" />
            {t({ ar: 'إعادة المحاولة', en: 'Retry' })}
          </button>
        </div>
      </div>
    );

  const notesDirty = (r.adminNotes ?? '') !== notes;

  const info: [string, string][] = [
    [t({ ar: 'الخدمة', en: 'Service' }), t(SERVICE_LABEL[r.service])],
    [t({ ar: 'الميزانية', en: 'Budget' }), t(BUDGET_LABEL[r.budget])],
    [t({ ar: 'المدة', en: 'Timeline' }), t(TIMELINE_LABEL[r.timeline])],
    [t({ ar: 'الجهة', en: 'Organisation' }), r.organization ?? '—'],
    [t({ ar: 'تاريخ الإرسال', en: 'Received' }), fmtDate(r.createdAt, lang)],
    [t({ ar: 'آخر تحديث', en: 'Updated' }), fmtDate(r.updatedAt, lang)],
  ];

  return (
    <Page className="space-y-5">
      {backLink}
      <div className="overflow-hidden rounded-[1.75rem] bg-[hsl(var(--ink))] text-[hsl(var(--wool))]">
        <div className="sadu-diamonds flex flex-col gap-6 p-6 md:flex-row md:items-center md:justify-between md:p-8">
          <div className="flex items-center gap-4">
            <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-primary"><ServiceIcon type={r.service} className="h-8 w-8" /></span>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="num text-sm text-[hsl(var(--saffron))]" data-testid="text-reference">{r.reference}</span>
                <StatusPill className={STATUS_TONE[r.status]}>{t(STATUS_LABEL[r.status])}</StatusPill>
              </div>
              <h1 className="mt-1 truncate font-display text-2xl font-bold sm:text-3xl" data-testid="text-client-name">{r.name}</h1>
            </div>
          </div>
        </div>
        {r.email && <div className="border-t border-[hsl(var(--wool)/0.1)] px-6 py-3 text-sm md:px-8"><span>{t({ ar: 'التنبيهات تصل إلى', en: 'Alerts go to' })} </span><span className="num" dir="ltr" data-testid="text-client-email">{r.email}</span></div>}
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.5fr_1fr]">
        <div className="space-y-5">
          <section className="rounded-2xl border border-card-border bg-card p-6">
            <h2 className="text-sm font-semibold text-muted-foreground">{t({ ar: 'وصف المشروع', en: 'Project description' })}</h2>
            <p className="mt-3 whitespace-pre-wrap text-[1.02rem] leading-8" data-testid="text-description" dir="auto">{r.description}</p>
          </section>
          <section className="rounded-2xl border border-card-border bg-card p-6" data-testid="admin-conversation">
            <div className="flex items-center justify-between gap-3">
              <h2 className="flex items-center gap-2 font-display text-lg font-bold"><MessageCircle className="h-5 w-5 text-primary" />{t({ ar: 'المحادثة مع العميل', en: 'Client conversation' })}</h2>
              {thread.data?.pushEnabled && <span className="text-xs text-muted-foreground">{t({ ar: 'تنبيهات المتصفح مفعّلة', en: 'Browser notifications enabled' })}</span>}
            </div>
            {thread.isLoading ? (
              <Skeleton className="mt-4 h-28 rounded-xl" />
            ) : thread.isError ? (
              <div className="mt-4 flex items-center justify-between gap-3 rounded-xl bg-destructive/5 p-4 text-sm">
                <span>{t({ ar: 'تعذّر تحميل المحادثة', en: 'Couldn’t load conversation' })}</span>
                <button type="button" onClick={() => thread.refetch()} className="font-semibold underline">{t({ ar: 'إعادة المحاولة', en: 'Retry' })}</button>
              </div>
            ) : (
              <>
                {thread.data?.assistantPaused && (
                  <div className="mt-4 flex items-start gap-2 rounded-xl border border-emerald-600/20 bg-emerald-600/5 p-3 text-sm leading-6 text-foreground">
                    <Check className="mt-1 h-4 w-4 shrink-0 text-emerald-700" />
                    <span>{t({ ar: 'توقّف المساعد الآلي عند فتحك للمحادثة. المتابعة والردود الجديدة الآن عليك.', en: 'The assistant paused when you opened this conversation. New replies are now yours to handle.' })}</span>
                  </div>
                )}
                <div className="mt-4 max-h-[28rem] space-y-3 overflow-y-auto rounded-xl bg-muted/50 p-4">
                  {[{ id: 0, sender: 'client' as const, body: r.description, createdAt: r.createdAt, moderationStatus: 'clear' as const }, ...(thread.data?.messages ?? [])].map((m) => {
                    const owner = m.sender !== 'client';
                    const flagged = m.moderationStatus === 'needs_review';
                    const revealed = revealedMessages[m.id] === true;
                    const seen = owner && thread.data?.clientLastReadAt && new Date(thread.data.clientLastReadAt).getTime() >= new Date(m.createdAt).getTime();
                    return (
                      <div key={`${m.id}-${m.createdAt}`} className={cn('flex', owner ? 'justify-end' : 'justify-start')}>
                        <div className={cn('max-w-[88%] rounded-2xl px-4 py-3', owner ? 'bg-primary text-primary-foreground' : 'bg-card')}>
                          <div className="mb-1 flex items-center gap-2 text-[11px] opacity-70">
                            <span>{m.sender === 'assistant' ? t({ ar: 'مساعد آلي ثابت', en: 'Automated FAQ assistant' }) : owner ? t({ ar: 'مروان', en: 'Marwan' }) : t({ ar: 'العميل', en: 'Client' })}</span>
                            <span>{relTime(m.createdAt, lang)}</span>
                          </div>
                          {flagged && <div className="mb-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-2 text-xs leading-5">
                            <div className="font-semibold">{t({ ar: 'قد يحتوي هذا النص على إساءة — الفلتر قد يخطئ', en: 'This message may contain abuse — the filter can be wrong' })}</div>
                            <button type="button" className="mt-1 underline" onClick={() => setRevealedMessages((state) => ({ ...state, [m.id]: !state[m.id] }))}>
                              {revealed ? t({ ar: 'إخفاء النص', en: 'Hide message' }) : t({ ar: 'إظهار النص للمراجعة', en: 'Reveal for review' })}
                            </button>
                          </div>}
                          {(!flagged || revealed) && <p className="whitespace-pre-wrap text-sm leading-6" dir="auto">{m.body}</p>}
                          {seen && <div className="mt-1 text-[11px] opacity-70">{t({ ar: 'اطّلع العميل على الرسالة', en: 'Seen by client' })}</div>}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <form className="mt-4 space-y-2" onSubmit={(e) => { e.preventDefault(); sendReply(); }}>
                  <textarea value={reply} onChange={(e) => setReply(e.target.value.slice(0, 2000))} rows={3} maxLength={2000} placeholder={t({ ar: 'اكتب ردك للعميل هنا…', en: 'Write your reply to the client…' })} className="w-full resize-y rounded-xl border border-input bg-background p-3 text-sm leading-6 outline-none focus:border-primary" disabled={r.status === 'archived'} />
                  <div className="flex items-center justify-between gap-3">
                    <span className="num text-xs text-muted-foreground">{reply.length} / 2000{r.status === 'archived' ? ` · ${t({ ar: 'الطلب مؤرشف', en: 'Request archived' })}` : ''}</span>
                    <button type="submit" disabled={!reply.trim() || send.isPending || r.status === 'archived'} className="inline-flex h-10 items-center gap-2 rounded-full bg-foreground px-5 text-sm font-semibold text-background disabled:opacity-40">
                      {send.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                      {t({ ar: 'إرسال الرد', en: 'Send reply' })}
                    </button>
                  </div>
                </form>
              </>
            )}
          </section>
          <section className="rounded-2xl border border-card-border bg-card p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-muted-foreground">{t({ ar: 'ملاحظات خاصة', en: 'Private notes' })}</h2>
              <span className="num text-xs text-muted-foreground">{notes.length} / 5000</span>
            </div>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value.slice(0, 5000))}
              rows={6}
              data-testid="input-admin-notes"
              placeholder={t({ ar: 'مثال: يحتاج العميل إلى عرض سعر لموقع من 5 صفحات…', en: 'For example: The client needs a quote for a 5-page website…' })}
              className="mt-3 w-full resize-y rounded-xl border border-input bg-background p-4 text-sm leading-7 outline-none focus:border-primary focus:ring-4 focus:ring-primary/10"
            />
            <div className="mt-3 flex items-center justify-end gap-3">
              {!notesDirty && r.adminNotes && <span className="flex items-center gap-1 text-xs text-muted-foreground"><Check className="h-3.5 w-3.5" />{t({ ar: 'محفوظة', en: 'Saved' })}</span>}
              <button type="button" disabled={!notesDirty || update.isPending} onClick={saveNotes} data-testid="button-save-notes" className="inline-flex h-10 items-center gap-2 rounded-full bg-foreground px-5 text-sm font-semibold text-background disabled:opacity-40">
                {update.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                {t({ ar: 'حفظ الملاحظات', en: 'Save notes' })}
              </button>
            </div>
          </section>
        </div>

        <div className="space-y-5">
          <section className="rounded-2xl border border-card-border bg-card p-6">
            <h2 className="text-sm font-semibold text-muted-foreground">{t({ ar: 'الحالة', en: 'Status' })}</h2>
            <div className="mt-3 grid gap-2">
              {STATUSES.map((s, i) => (
                <button
                  key={s}
                  type="button"
                  disabled={update.isPending}
                  onClick={() => s !== r.status && setStatus(s)}
                  data-testid={`button-set-status-${s}`}
                  className={cn('flex items-center justify-between rounded-xl border px-4 py-3 text-sm font-medium transition-all', s === r.status ? 'border-foreground bg-foreground text-background' : 'border-border hover:border-foreground/40')}
                >
                  <span className="flex items-center gap-3">
                    <span className="num text-xs opacity-50">{i + 1}</span>
                    {t(STATUS_LABEL[s])}
                  </span>
                  {s === r.status && <Check className="h-4 w-4" />}
                </button>
              ))}
            </div>
          </section>
          <section className="rounded-2xl border border-card-border bg-card p-6">
            <dl className="space-y-3 text-sm">
              {info.map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4">
                  <dt className="text-muted-foreground">{k}</dt>
                  <dd className="text-end font-medium">{v}</dd>
                </div>
              ))}
            </dl>
          </section>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button type="button" data-testid="button-delete-request" className="flex w-full items-center justify-center gap-2 rounded-xl border border-destructive/30 py-3 text-sm font-semibold text-destructive hover:bg-destructive/5">
                <Trash2 className="h-4 w-4" />
                {t({ ar: 'حذف الطلب', en: 'Delete request' })}
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>{t({ ar: `حذف الطلب ${r.reference}؟`, en: `Delete ${r.reference}?` })}</AlertDialogTitle>
                <AlertDialogDescription>{t({ ar: 'سيُحذف الطلب ومحادثته ورسائله وملاحظاتك نهائيًا، ولا يمكن التراجع عن ذلك.', en: 'The request, its conversation and messages, and your notes will be permanently deleted. This can’t be undone.' })}</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>{t({ ar: 'إلغاء', en: 'Cancel' })}</AlertDialogCancel>
                <AlertDialogAction onClick={remove} data-testid="button-confirm-delete" className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  {del.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                  {t({ ar: 'حذف نهائي', en: 'Delete permanently' })}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </Page>
  );
}

export default function AdminRequestDetail() {
  return (
    <AdminGate>
      <Detail />
    </AdminGate>
  );
}
