import { Link } from 'wouter';
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { AlertTriangle, RefreshCw, Inbox } from 'lucide-react';
import { useGetAdminSummary } from '@workspace/api-client-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { SERVICE_LABEL, STATUS_LABEL, STATUS_TONE } from '@/lib/content';
import { fmtDay, relTime } from '@/lib/format';
import { AdminGate, StatusPill } from '@/components/admin-shell';
import { ServiceIcon } from '@/components/brand';
import { Arrow } from '@/components/site-shell';
import { Page } from '@/components/motion';
import { Skeleton } from '@/components/ui/skeleton';

function Stat({ label, value, tone, sub }: { label: string; value: number; tone?: string; sub?: string }) {
  return (
    <div className={`rounded-2xl border border-card-border p-5 ${tone ?? 'bg-card'}`}>
      <div className="text-xs font-semibold opacity-75">{label}</div>
      <div className="num mt-2 font-display text-4xl font-extrabold">{value}</div>
      {sub && <div className="mt-1 text-xs opacity-70">{sub}</div>}
    </div>
  );
}

function Overview() {
  const { t, lang } = useLang();
  useDocTitle({ ar: 'نظرة عامة — لوحة مروان', en: 'Overview — Marwan’s dashboard' });
  const q = useGetAdminSummary();

  if (q.isLoading)
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}</div>
        <Skeleton className="h-72 rounded-2xl" />
      </div>
    );
  if (q.isError || !q.data)
    return (
      <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
        <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
        <p className="mt-3 font-semibold">{t({ ar: 'تعذّر تحميل الملخص', en: 'Couldn’t load the summary' })}</p>
        <button type="button" onClick={() => q.refetch()} className="mt-4 inline-flex h-10 items-center gap-2 rounded-full bg-foreground px-5 text-sm font-semibold text-background">
          <RefreshCw className="h-4 w-4" />
          {t({ ar: 'إعادة المحاولة', en: 'Retry' })}
        </button>
      </div>
    );

  const d = q.data;
  const maxService = Math.max(1, ...d.byService.map((s) => s.count));
  const chart = d.daily.map((x) => ({ ...x, label: fmtDay(x.date, lang) }));
  const greeting = (() => {
    const h = Number(new Intl.DateTimeFormat('en-US', { hour: 'numeric', hour12: false, timeZone: 'Asia/Riyadh' }).format(new Date()));
    if (h < 12) return t({ ar: 'صباح الخير يا مروان', en: 'Good morning, Marwan' });
    return t({ ar: 'مساء الخير يا مروان', en: 'Good evening, Marwan' });
  })();

  return (
    <Page className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold">{greeting}</h1>
          <p className="mt-1 text-muted-foreground">
             {d.unreadConversations > 0
               ? t({ ar: `محادثات تتضمن رسائل جديدة من العملاء: ${d.unreadConversations}.`, en: `Conversations with unread client messages: ${d.unreadConversations}.` })
               : d.newCount > 0
              ? t({ ar: `طلبات جديدة تنتظر ردك: ${d.newCount}.`, en: `New requests waiting for a reply: ${d.newCount}.` })
              : t({ ar: 'لا توجد طلبات تنتظر ردك الآن.', en: 'No requests are waiting for a reply right now.' })}
          </p>
        </div>
        <Link href="/admin/requests" data-testid="link-all-requests" className="inline-flex h-11 items-center gap-2 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground">
          {t({ ar: 'كل الطلبات', en: 'All requests' })}
          <Arrow className="h-4 w-4" />
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <Stat label={t({ ar: 'جديد — يحتاج رد', en: 'New — needs reply' })} value={d.newCount} tone="bg-primary text-primary-foreground border-transparent" />
        <Stat label={t({ ar: 'محادثات غير مقروءة', en: 'Unread conversations' })} value={d.unreadConversations} tone={d.unreadConversations > 0 ? 'bg-accent text-accent-foreground border-transparent' : undefined} />
        <Stat label={t({ ar: 'قيد المتابعة', en: 'Active' })} value={d.activeCount} />
        <Stat label={t({ ar: 'مكتمل', en: 'Completed' })} value={d.completedCount} />
        <Stat label={t({ ar: 'الإجمالي', en: 'Total' })} value={d.total} tone="bg-[hsl(var(--ink))] text-[hsl(var(--wool))] border-transparent" sub={t({ ar: `خلال آخر 7 أيام: ${d.last7Days} · خلال آخر 30 يومًا: ${d.last30Days}`, en: `${d.last7Days} in the last 7 days · ${d.last30Days} in the last 30 days` })} />
      </div>

      {d.total === 0 ? (
        <div className="overflow-hidden rounded-[1.75rem] border border-dashed border-border bg-card p-10 text-center">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-muted"><Inbox className="h-8 w-8 text-primary" /></div>
          <h2 className="mt-5 font-display text-2xl font-bold">{t({ ar: 'لوحة التحكم جاهزة لاستقبال أول طلب.', en: 'Your dashboard is ready for the first request.' })}</h2>
          <p className="mx-auto mt-2 max-w-md text-sm leading-7 text-muted-foreground">
            {t({ ar: 'شارك رابط الموقع مع أصحاب المشاريع. سيظهر كل طلب هنا مع رقمه المرجعي، ويمكنك الرد على العميل من لوحة التحكم.', en: 'Share your site link with business owners. Each request appears here with a reference, and you can reply from the dashboard.' })}
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link href="/" className="inline-flex h-11 items-center rounded-full bg-foreground px-5 text-sm font-semibold text-background">{t({ ar: 'افتح الموقع العام', en: 'Open public site' })}</Link>
          </div>
        </div>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        <div className="rounded-2xl border border-card-border bg-card p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold">{t({ ar: 'الطلبات خلال 30 يوماً', en: 'Requests, last 30 days' })}</h2>
            <span className="num text-sm text-muted-foreground">{d.last30Days}</span>
          </div>
          <div className="mt-4 h-56" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              {/* The Y axis sits on the reading-start side; only that side gets the negative margin, otherwise the newest days are clipped. */}
              <AreaChart
                data={chart}
                margin={lang === 'ar' ? { top: 8, right: -24, left: 12, bottom: 0 } : { top: 8, right: 12, left: -24, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} interval={6} reversed={lang === 'ar'} />
                <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} orientation={lang === 'ar' ? 'right' : 'left'} />
                <Tooltip contentStyle={{ background: 'hsl(var(--ink))', border: 'none', borderRadius: 12, color: 'hsl(var(--wool))', fontSize: 12 }} labelStyle={{ color: 'hsl(var(--saffron))' }} formatter={(v: number) => [v, t({ ar: 'طلبات', en: 'requests' })]} />
                <Area type="monotone" dataKey="count" stroke="hsl(var(--primary))" strokeWidth={2.5} fill="url(#g)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-2xl border border-card-border bg-card p-5">
          <h2 className="font-display font-bold">{t({ ar: 'حسب الحالة', en: 'By status' })}</h2>
          <div className="mt-4 space-y-2.5">
            {d.byStatus.map((s) => (
              <Link key={s.status} href={`/admin/requests?status=${s.status}`} className="flex items-center justify-between rounded-xl px-2 py-1.5 hover:bg-muted">
                <StatusPill className={STATUS_TONE[s.status]}>{t(STATUS_LABEL[s.status])}</StatusPill>
                <span className="num font-semibold">{s.count}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1.6fr]">
        <div className="rounded-2xl border border-card-border bg-card p-5">
          <h2 className="font-display font-bold">{t({ ar: 'حسب الخدمة', en: 'By service' })}</h2>
          <div className="mt-4 space-y-3">
            {d.byService.map((s) => (
              <div key={s.service}>
                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2"><ServiceIcon type={s.service} className="h-5 w-5 text-muted-foreground" />{t(SERVICE_LABEL[s.service])}</span>
                  <span className="num font-semibold">{s.count}</span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-muted">
                  <div className="h-full rounded-full bg-primary transition-all duration-700" style={{ width: `${(s.count / maxService) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-2xl border border-card-border bg-card p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold">{t({ ar: 'أحدث الطلبات', en: 'Latest requests' })}</h2>
            <Link href="/admin/requests" className="text-sm font-semibold text-primary">{t({ ar: 'عرض الكل', en: 'View all' })}</Link>
          </div>
          {d.recent.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">{t({ ar: 'ستظهر هنا أحدث 5 طلبات.', en: 'Your 5 latest requests will show up here.' })}</p>
          ) : (
            <ul className="mt-3 divide-y divide-border">
              {d.recent.map((r) => (
                <li key={r.id}>
                  <Link href={`/admin/requests/${r.id}`} data-testid={`row-recent-${r.id}`} className="flex items-center gap-3 py-3 hover:opacity-80">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-muted"><ServiceIcon type={r.service} className="h-6 w-6" /></span>
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-semibold">{r.name}</div>
                      <div className="text-xs text-muted-foreground"><span className="num">{r.reference}</span> · {relTime(r.createdAt, lang)}</div>
                    </div>
                    <StatusPill className={STATUS_TONE[r.status]}>{t(STATUS_LABEL[r.status])}</StatusPill>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </Page>
  );
}

export default function AdminOverview() {
  return (
    <AdminGate>
      <Overview />
    </AdminGate>
  );
}
