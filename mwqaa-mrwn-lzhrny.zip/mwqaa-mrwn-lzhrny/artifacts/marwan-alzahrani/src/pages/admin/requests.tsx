import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearch } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { Search, X, AlertTriangle, RefreshCw, Inbox, MessageCircle, Trash2, Loader2 } from 'lucide-react';
import {
  useListProjectRequests,
  getListProjectRequestsQueryKey,
  getGetAdminSummaryQueryKey,
  useDeleteProjectRequest,
  RequestStatus,
  ServiceType,
  type ListProjectRequestsParams,
} from '@workspace/api-client-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { SERVICE_LABEL, STATUS_LABEL, STATUS_TONE } from '@/lib/content';
import { fmtDate, relTime } from '@/lib/format';
import { AdminGate, StatusPill } from '@/components/admin-shell';
import { ServiceIcon } from '@/components/brand';
import { Page } from '@/components/motion';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const STATUSES = Object.values(RequestStatus);
const SERVICES = Object.values(ServiceType);

function RequestsList() {
  const { t, lang } = useLang();
  useDocTitle({ ar: 'الطلبات — لوحة مروان', en: 'Requests — Marwan’s dashboard' });
  const qc = useQueryClient();
  const { toast } = useToast();
  const deleteRequest = useDeleteProjectRequest();
  const [deleteTarget, setDeleteTarget] = useState<{ id: number; reference: string } | null>(null);
  const search = useSearch();
  const initialStatus = useMemo(() => {
    const v = new URLSearchParams(search).get('status');
    return v && (STATUSES as string[]).includes(v) ? (v as RequestStatus) : undefined;
  }, [search]);

  const [status, setStatus] = useState<RequestStatus | undefined>(initialStatus);
  const [service, setService] = useState<ServiceType | undefined>();
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [text, setText] = useState('');
  const [debounced, setDebounced] = useState('');
  const timer = useRef<number | null>(null);

  useEffect(() => setStatus(initialStatus), [initialStatus]);
  useEffect(() => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setDebounced(text.trim().slice(0, 100)), 300);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [text]);

  const params: ListProjectRequestsParams = {};
  if (status) params.status = status;
  if (service) params.service = service;
  if (debounced) params.search = debounced;
  const hasFilters = !!(status || service || debounced || unreadOnly);

  const q = useListProjectRequests(params, { query: { queryKey: getListProjectRequestsQueryKey(params), placeholderData: (prev) => prev } });
  const unreadConversationCount = q.data?.filter((request) => request.unreadCount > 0).length ?? 0;
  const visibleRequests = unreadOnly
    ? (q.data ?? []).filter((request) => request.unreadCount > 0)
    : q.data ?? [];

  const confirmDelete = () => {
    if (!deleteTarget || deleteRequest.isPending) return;
    deleteRequest.mutate(
      { id: deleteTarget.id },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListProjectRequestsQueryKey() });
          qc.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() });
          setDeleteTarget(null);
          toast({ title: t({ ar: 'تم حذف الطلب ومحادثته', en: 'Request and conversation deleted' }) });
        },
        onError: () =>
          toast({
            title: t({ ar: 'تعذّر حذف الطلب', en: 'Couldn’t delete the request' }),
            variant: 'destructive',
          }),
      },
    );
  };

  return (
    <Page className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">{t({ ar: 'الطلبات', en: 'Requests' })}</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {q.data ? t({ ar: `الطلبات المعروضة: ${visibleRequests.length}`, en: `Requests shown: ${visibleRequests.length}` }) : '\u00a0'}
          </p>
        </div>
      </div>

      <div className="space-y-3 rounded-2xl border border-card-border bg-card p-3">
        <div className="flex flex-col gap-2 sm:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={100}
              data-testid="input-search"
              placeholder={t({ ar: 'ابحث بالاسم أو الرقم المرجعي (MZ-0007)…', en: 'Search name or reference (MZ-0007)…' })}
              className="h-11 w-full rounded-xl border border-input bg-background pe-10 ps-10 text-sm outline-none focus:border-primary"
            />
            {text && (
              <button type="button" onClick={() => setText('')} aria-label={t({ ar: 'مسح البحث', en: 'Clear search' })} className="absolute end-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <Select value={service ?? 'all'} onValueChange={(v) => setService(v === 'all' ? undefined : (v as ServiceType))}>
            <SelectTrigger className="h-11 rounded-xl sm:w-56" data-testid="select-service">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t({ ar: 'كل الخدمات', en: 'All services' })}</SelectItem>
              {SERVICES.map((s) => (
                <SelectItem key={s} value={s}>{t(SERVICE_LABEL[s])}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex gap-1.5 overflow-x-auto [scrollbar-width:none]">
          <button
            type="button"
            onClick={() => setUnreadOnly((current) => !current)}
            aria-pressed={unreadOnly}
            data-testid="button-unread-only"
            className={cn('inline-flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium', unreadOnly ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted')}
          >
            <MessageCircle className="h-3.5 w-3.5" />
            {t({ ar: 'محادثات غير مقروءة', en: 'Unread conversations' })}
            <span className="num rounded-full bg-background/20 px-1.5">{unreadConversationCount}</span>
          </button>
          <button type="button" onClick={() => setStatus(undefined)} data-testid="button-status-all" className={cn('shrink-0 rounded-lg px-3 py-1.5 text-sm font-medium', !status ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-muted')}>
            {t({ ar: 'كل الحالات', en: 'All statuses' })}
          </button>
          {STATUSES.map((s) => (
            <button key={s} type="button" onClick={() => setStatus(s)} data-testid={`button-status-${s}`} className={cn('shrink-0 rounded-lg px-3 py-1.5 text-sm font-medium', status === s ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-muted')}>
              {t(STATUS_LABEL[s])}
            </button>
          ))}
        </div>
      </div>

      {q.isLoading ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-2xl" />)}</div>
      ) : q.isError ? (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
          <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
          <p className="mt-3 font-semibold">{t({ ar: 'تعذّر تحميل الطلبات', en: 'Couldn’t load requests' })}</p>
          <button type="button" onClick={() => q.refetch()} className="mt-4 inline-flex h-10 items-center gap-2 rounded-full bg-foreground px-5 text-sm font-semibold text-background">
            <RefreshCw className="h-4 w-4" />
            {t({ ar: 'إعادة المحاولة', en: 'Retry' })}
          </button>
        </div>
      ) : visibleRequests.length === 0 ? (
        <div className="rounded-[1.75rem] border border-dashed border-border bg-card p-12 text-center">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-muted"><Inbox className="h-8 w-8 text-primary" /></div>
          <h2 className="mt-5 font-display text-xl font-bold">
            {hasFilters ? t({ ar: 'لم نعثر على طلبات مطابقة.', en: 'No matching requests found.' }) : t({ ar: 'لا توجد طلبات حتى الآن.', en: 'No requests yet.' })}
          </h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            {hasFilters ? t({ ar: 'غيّر عوامل التصفية أو كلمة البحث، ثم أعد المحاولة.', en: 'Change the filters or search term, then try again.' }) : t({ ar: 'ستظهر الطلبات هنا عند إرسالها عبر الموقع.', en: 'Requests will appear here when they’re sent through the site.' })}
          </p>
          {hasFilters && (
            <button type="button" onClick={() => { setStatus(undefined); setService(undefined); setUnreadOnly(false); setText(''); }} className="mt-5 rounded-full border border-border px-5 py-2 text-sm font-semibold">
              {t({ ar: 'مسح عوامل التصفية', en: 'Clear filters' })}
            </button>
          )}
        </div>
      ) : (
        <ul className={cn('space-y-2 transition-opacity', q.isFetching && 'opacity-70')}>
          {visibleRequests.map((r) => (
            <li key={r.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-stretch gap-2">
              <Link href={`/admin/requests/${r.id}`} data-testid={`row-request-${r.id}`} className="group grid min-w-0 grid-cols-[auto_1fr_auto] items-center gap-4 rounded-2xl border border-card-border bg-card p-4 transition-all hover:-translate-y-0.5 hover:shadow-md md:grid-cols-[auto_1.3fr_1fr_auto_auto]">
                  <span className={cn('grid h-11 w-11 place-items-center rounded-xl', r.status === 'new' ? 'bg-primary text-primary-foreground' : 'bg-muted')}>
                    <ServiceIcon type={r.service} className="h-6 w-6" />
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="truncate font-semibold">{r.name}</span>
                      {r.organization && <span className="hidden truncate text-xs text-muted-foreground sm:inline">· {r.organization}</span>}
                      {r.unreadCount > 0 && <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-[11px] font-semibold text-primary-foreground"><MessageCircle className="h-3 w-3" /><span>{r.unreadCount}</span></span>}
                    </div>
                    <div className="mt-0.5 truncate text-xs text-muted-foreground">
                      <span className="num">{r.reference}</span> · {t(SERVICE_LABEL[r.service])}
                    </div>
                  </div>
                  <p className="hidden truncate text-sm text-muted-foreground md:block">{r.description}</p>
                  <div className="hidden text-end text-xs text-muted-foreground md:block" title={fmtDate(r.createdAt, lang)}>
                    <div>{relTime(r.createdAt, lang)}</div>
                    {r.email && <div className="max-w-36 truncate" dir="ltr">{r.email}</div>}
                  </div>
                  <StatusPill className={STATUS_TONE[r.status]}>{t(STATUS_LABEL[r.status])}</StatusPill>
              </Link>
              <button
                type="button"
                data-testid={`button-delete-request-${r.id}`}
                aria-label={t({ ar: `حذف الطلب ${r.reference}`, en: `Delete request ${r.reference}` })}
                title={t({ ar: 'حذف الطلب', en: 'Delete request' })}
                onClick={() => setDeleteTarget({ id: r.id, reference: r.reference })}
                className="grid w-11 place-items-center self-center rounded-xl border border-destructive/30 text-destructive transition-colors hover:bg-destructive/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && !deleteRequest.isPending && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {t({ ar: `حذف الطلب ${deleteTarget?.reference ?? ''}؟`, en: `Delete ${deleteTarget?.reference ?? ''}?` })}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {t({
                ar: 'سيُحذف الطلب ومحادثته ورسائله وملاحظاتك نهائيًا، ولا يمكن التراجع عن ذلك.',
                en: 'This permanently deletes the request, its conversation and messages, and your notes. This can’t be undone.',
              })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteRequest.isPending}>{t({ ar: 'إلغاء', en: 'Cancel' })}</AlertDialogCancel>
            <AlertDialogAction
              onClick={(event) => {
                event.preventDefault();
                confirmDelete();
              }}
              disabled={deleteRequest.isPending}
              data-testid="button-confirm-delete-request"
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteRequest.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              {t({ ar: 'حذف نهائي', en: 'Delete permanently' })}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Page>
  );
}

export default function AdminRequests() {
  return (
    <AdminGate>
      <RequestsList />
    </AdminGate>
  );
}
