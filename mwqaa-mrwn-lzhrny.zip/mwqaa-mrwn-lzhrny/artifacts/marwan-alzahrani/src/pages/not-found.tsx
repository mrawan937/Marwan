import { Link } from 'wouter';
import { useLang, useDocTitle } from '@/lib/i18n';
import { SaduBand } from '@/components/brand';
import { SiteShell } from '@/components/site-shell';

export default function NotFound() {
  const { t } = useLang();
  useDocTitle({ ar: 'الصفحة غير موجودة', en: 'Page not found' });
  return (
    <SiteShell>
      <section className="mx-auto flex max-w-3xl flex-col items-center px-5 py-20 text-center">
        <div className="relative">
          <span className="num font-display text-[9rem] font-extrabold leading-none text-foreground sm:text-[12rem]">404</span>
          <SaduBand className="absolute inset-x-0 top-1/2 -translate-y-1/2 -rotate-3 opacity-90" />
        </div>
        <h1 className="mt-8 font-display text-3xl font-bold">{t({ ar: 'يبدو أن الصفحة غير موجودة.', en: 'This page could not be found.' })}</h1>
        <p className="mt-3 max-w-md text-muted-foreground">{t({ ar: 'الصفحة التي تبحث عنها غير موجودة أو تغيّر رابطها. يمكنك العودة إلى الصفحة الرئيسية.', en: 'The page you’re looking for doesn’t exist or has moved. You can return to the home page.' })}</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/" data-testid="link-404-home" className="inline-flex h-12 items-center rounded-full bg-primary px-6 font-semibold text-primary-foreground">{t({ ar: 'الصفحة الرئيسية', en: 'Home' })}</Link>
          <Link href="/request" className="inline-flex h-12 items-center rounded-full border-2 border-foreground px-6 font-semibold">{t({ ar: 'ابدأ مشروعك', en: 'Start a project' })}</Link>
        </div>
      </section>
    </SiteShell>
  );
}
