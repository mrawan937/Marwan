import { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { ArrowLeft, ArrowRight, Check, Coffee, Croissant, Minus, Plus, RotateCcw, ShoppingBag, Soup } from 'lucide-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { SiteShell } from '@/components/site-shell';
import { asset } from '@/components/brand';

const products = [
  { id: 'coffee', category: { ar: 'مشروبات', en: 'Drinks' }, name: { ar: 'قهوة اليوم', en: 'Coffee of the day' }, description: { ar: 'تحميص متوسط، تُقدّم ساخنة.', en: 'A medium roast, served hot.' }, image: 'images/cafe-coffee.jpg', imageAlt: { ar: 'فنجان قهوة اليوم مع حبوب البن والهيل', en: 'Coffee of the day with coffee beans and cardamom' }, price: 16, Icon: Coffee },
  { id: 'latte', category: { ar: 'مشروبات', en: 'Drinks' }, name: { ar: 'لاتيه الهيل', en: 'Cardamom latte' }, description: { ar: 'إسبريسو وحليب ولمسة هيل.', en: 'Espresso, milk and a hint of cardamom.' }, image: 'images/cafe-latte.jpg', imageAlt: { ar: 'كوب لاتيه مع حبوب الهيل', en: 'Cardamom latte with cardamom pods' }, price: 22, Icon: Coffee },
  { id: 'croissant', category: { ar: 'مخبوزات', en: 'Bakery' }, name: { ar: 'كرواسون الزعتر', en: 'Za’atar croissant' }, description: { ar: 'مخبوز طازج بحشوة الزعتر.', en: 'Freshly baked with a za’atar filling.' }, image: 'images/cafe-croissant.jpg', imageAlt: { ar: 'كرواسون ذهبي محشو بالزعتر', en: 'Golden za’atar-filled croissant' }, price: 18, Icon: Croissant },
  { id: 'soup', category: { ar: 'خفيف', en: 'Light bites' }, name: { ar: 'شوربة العدس', en: 'Lentil soup' }, description: { ar: 'شوربة يومية مع خبز جانبي.', en: 'A daily soup with a side of bread.' }, image: 'images/cafe-soup.jpg', imageAlt: { ar: 'شوربة عدس مع خبز جانبي', en: 'Lentil soup served with flatbread' }, price: 24, Icon: Soup },
];

export default function CafeDemo() {
  const { t, lang, dir } = useLang();
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [ordered, setOrdered] = useState(false);
  const BackIcon = dir === 'rtl' ? ArrowRight : ArrowLeft;
  useDocTitle({ ar: 'تجربة المقهى — مروان الزهراني', en: 'Café demo — Marwan Alzahrani' });
  const cart = useMemo(() => products.reduce((sum, product) => sum + (quantities[product.id] || 0), 0), [quantities]);
  const subtotal = useMemo(() => products.reduce((sum, product) => sum + product.price * (quantities[product.id] || 0), 0), [quantities]);
  const price = (value: number) => new Intl.NumberFormat(lang === 'ar' ? 'ar-SA' : 'en-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 2 }).format(value);
  const changeQuantity = (id: string, change: number) => {
    setQuantities((current) => {
      const next = Math.max(0, (current[id] || 0) + change);
      return { ...current, [id]: next };
    });
  };
  const reset = () => {
    setQuantities({});
    setOrdered(false);
  };

  return (
    <SiteShell>
      <div className="mx-auto min-h-[70vh] max-w-7xl px-5 pb-20 pt-7 md:px-8 md:pt-12">
        <Link href="/" data-testid="link-demo-home" className="inline-flex items-center gap-2 rounded-full py-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground">
          <BackIcon className="h-4 w-4" />
          {t({ ar: 'العودة إلى الصفحة الرئيسية', en: 'Back to homepage' })}
        </Link>
        <div className="mt-8 flex flex-col justify-between gap-5 border-b border-border pb-7 sm:flex-row sm:items-end">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs font-bold text-primary">
              <span className="h-2 w-2 rounded-full bg-primary" />
              {t({ ar: 'عرض تجريبي تفاعلي', en: 'Interactive demo' })}
            </div>
            <h1 className="mt-5 font-display text-4xl font-extrabold sm:text-5xl">{t({ ar: 'ركن ورق — مقهى للتجربة', en: 'Waraq Corner — a café demo' })}</h1>
            <p className="mt-3 max-w-2xl text-lg leading-8 text-muted-foreground">{t({ ar: 'قائمة صغيرة، وسلة واضحة. أضف ما يعجبك وشاهد الإجمالي يتغير.', en: 'A small menu and a clear cart. Add what sounds good and watch the total update.' })}</p>
            <p className="mt-4 max-w-2xl rounded-2xl border border-primary/20 bg-primary/5 px-4 py-3 text-sm leading-6 text-foreground/80" role="note" data-testid="notice-cafe-demo-intro">
              {t({ ar: 'تجربة توضيحية فقط: المنتجات والأسعار والصور أمثلة، ولا يتم إرسال أو حفظ أي طلب أو بيانات.', en: 'Illustrative demo only: products, prices and images are samples; no order or data is sent or saved.' })}
            </p>
          </div>
          <div className="inline-flex w-fit items-center gap-2 rounded-full bg-[hsl(var(--ink))] px-4 py-2.5 text-sm font-semibold text-[hsl(var(--wool))]" data-testid="status-cart-count">
            <ShoppingBag className="h-4 w-4 text-[hsl(var(--saffron))]" />
            <span>{cart}</span>
            <span>{t({ ar: 'في السلة', en: 'in your bag' })}</span>
          </div>
        </div>

        <div className="mt-9 grid gap-10 lg:grid-cols-[1fr_350px]">
          <section aria-labelledby="menu-title">
            <div className="mb-5 flex items-center justify-between">
              <h2 id="menu-title" className="font-display text-2xl font-bold">{t({ ar: 'قائمة اليوم', en: 'Today’s menu' })}</h2>
              <span className="text-sm text-muted-foreground">{t({ ar: 'قائمة توضيحية', en: 'Sample menu' })}</span>
            </div>
            <ul className="grid gap-4 sm:grid-cols-2">
              {products.map(({ Icon, ...product }) => {
                const quantity = quantities[product.id] || 0;
                return (
                  <li key={product.id} className={`relative overflow-hidden rounded-[1.5rem] border border-card-border bg-card p-5 transition-colors ${quantity ? 'border-primary/50' : ''}`} data-testid={`card-cafe-product-${product.id}`}>
                    <div className="relative -mx-5 -mt-5 mb-5 aspect-[16/10] overflow-hidden bg-muted">
                      <img src={asset(product.image)} alt={t(product.imageAlt)} loading="lazy" className="h-full w-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--ink)/0.22)] to-transparent" aria-hidden="true" />
                      <span className="absolute start-4 top-4 grid h-11 w-11 place-items-center rounded-2xl bg-card/95 text-foreground shadow-sm" aria-hidden="true">
                        <Icon className="h-5 w-5" strokeWidth={1.8} />
                      </span>
                      <span className="absolute end-4 top-4 rounded-full border border-white/50 bg-card/95 px-3 py-1 text-xs text-foreground shadow-sm">{t(product.category)}</span>
                    </div>
                    <h3 className="mt-5 font-display text-xl font-bold" data-testid={`text-cafe-product-name-${product.id}`}>{t(product.name)}</h3>
                    <p className="mt-1 min-h-12 text-sm leading-6 text-muted-foreground">{t(product.description)}</p>
                    <div className="mt-5 flex items-center justify-between gap-3">
                      <span className="font-semibold" data-testid={`text-cafe-product-price-${product.id}`}>{price(product.price)}</span>
                      {quantity === 0 ? (
                        <button type="button" onClick={() => changeQuantity(product.id, 1)} disabled={ordered} data-testid={`button-cafe-add-${product.id}`} className="inline-flex h-10 items-center gap-2 rounded-full bg-[hsl(var(--ink))] px-4 text-sm font-semibold text-[hsl(var(--wool))] transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:opacity-50">
                          <Plus className="h-4 w-4" />{t({ ar: 'أضف', en: 'Add' })}
                        </button>
                      ) : (
                        <div className="inline-flex items-center gap-3 rounded-full border border-border bg-background px-2 py-1">
                          <button type="button" onClick={() => changeQuantity(product.id, -1)} disabled={ordered} aria-label={t({ ar: `تقليل ${product.name.ar}`, en: `Remove one ${product.name.en}` })} data-testid={`button-cafe-decrease-${product.id}`} className="grid h-8 w-8 place-items-center rounded-full transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:opacity-50"><Minus className="h-4 w-4" /></button>
                          <span className="num min-w-5 text-center font-semibold" data-testid={`text-cafe-quantity-${product.id}`} aria-live="polite">{quantity}</span>
                          <button type="button" onClick={() => changeQuantity(product.id, 1)} disabled={ordered} aria-label={t({ ar: `زيادة ${product.name.ar}`, en: `Add one ${product.name.en}` })} data-testid={`button-cafe-increase-${product.id}`} className="grid h-8 w-8 place-items-center rounded-full transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:opacity-50"><Plus className="h-4 w-4" /></button>
                        </div>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          </section>

          <aside className="h-fit rounded-[1.75rem] border border-card-border bg-card p-6 lg:sticky lg:top-24" aria-label={t({ ar: 'ملخص الطلب', en: 'Order summary' })}>
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-[hsl(var(--ink))] text-[hsl(var(--saffron))]"><ShoppingBag className="h-5 w-5" /></span>
              <div>
                <p className="text-xs font-bold text-primary">{t({ ar: 'ركن ورق', en: 'Waraq Corner' })}</p>
                <h2 className="font-display text-xl font-bold">{t({ ar: 'سلتك', en: 'Your order' })}</h2>
              </div>
            </div>
            {ordered ? (
              <div className="mt-6 rounded-2xl bg-[hsl(168_38%_95%)] p-5" role="status" aria-live="polite" data-testid="status-cafe-order-success">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-[hsl(168_40%_34%)] text-[hsl(var(--wool))]"><Check className="h-5 w-5" /></span>
                <h3 className="mt-4 font-display text-xl font-bold">{t({ ar: 'اكتمل طلبك التجريبي', en: 'Demo order complete' })}</h3>
                <p className="mt-2 text-sm leading-6 text-foreground/75">{t({ ar: 'تم إنشاء هذا التأكيد محليًا لهذه الجلسة فقط. لا يوجد طلب حقيقي.', en: 'This confirmation was created locally for this session only. No real order was placed.' })}</p>
                <button type="button" onClick={reset} data-testid="button-cafe-reset-success" className="mt-4 inline-flex items-center gap-2 rounded-full bg-[hsl(var(--ink))] px-4 py-2.5 text-sm font-semibold text-[hsl(var(--wool))] transition-transform hover:-translate-y-0.5">
                  <RotateCcw className="h-4 w-4" />{t({ ar: 'ابدأ من جديد', en: 'Start over' })}
                </button>
              </div>
            ) : (
              <>
                {cart > 0 ? (
                  <ul className="mt-5 space-y-3" data-testid="list-cafe-cart">
                    {products.filter((product) => quantities[product.id]).map((product) => (
                      <li key={product.id} className="flex items-start justify-between gap-3 text-sm">
                        <span className="min-w-0">
                          <span className="block font-semibold">{t(product.name)}</span>
                          <span className="num mt-1 block text-xs text-muted-foreground">{quantities[product.id]} × {price(product.price)}</span>
                        </span>
                        <span className="num font-semibold" data-testid={`text-cafe-line-total-${product.id}`}>{price(product.price * quantities[product.id])}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="mt-5 rounded-2xl border border-dashed border-border bg-muted/50 px-4 py-7 text-center" data-testid="status-cafe-cart-empty">
                    <ShoppingBag className="mx-auto h-6 w-6 text-muted-foreground" />
                    <p className="mt-3 text-sm font-semibold">{t({ ar: 'سلتك فارغة حتى الآن', en: 'Your bag is empty for now' })}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{t({ ar: 'اختر صنفًا من القائمة للبدء.', en: 'Choose something from the menu to begin.' })}</p>
                  </div>
                )}
                <div className="mt-5 border-t border-border pt-4">
                  <div className="flex items-center justify-between gap-3 font-display text-lg font-bold">
                    <span>{t({ ar: 'الإجمالي (المجموع الفرعي)', en: 'Total (subtotal)' })}</span>
                    <span className="num" data-testid="text-cafe-subtotal">{price(subtotal)}</span>
                  </div>
                  <p className="mt-2 text-xs leading-5 text-muted-foreground">{t({ ar: 'لا توجد رسوم إضافية في هذا المثال؛ الإجمالي يساوي مجموع الأصناف.', en: 'No extra fees in this example; the total is the sum of the selected items.' })}</p>
                </div>
                <button type="button" onClick={() => setOrdered(true)} disabled={cart === 0} data-testid="button-cafe-complete-order" className="mt-5 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-primary px-5 font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45">
                  {t({ ar: 'إكمال الطلب التجريبي', en: 'Complete demo order' })}
                </button>
                {cart > 0 && <button type="button" onClick={reset} data-testid="button-cafe-clear-cart" className="mt-3 inline-flex w-full items-center justify-center gap-2 py-2 text-sm font-semibold text-muted-foreground hover:text-foreground"><RotateCcw className="h-4 w-4" />{t({ ar: 'إفراغ السلة', en: 'Clear bag' })}</button>}
              </>
            )}
            <div className="mt-5 rounded-2xl bg-muted/70 p-4 text-xs leading-6 text-muted-foreground" data-testid="notice-cafe-demo">
              {t({ ar: 'المنتجات والأسعار والصور المعروضة أمثلة توضيحية فقط، وليست صور متجر حقيقي. لا يتم إرسال طلب حقيقي أو أي شيء إلى API أو البريد الإلكتروني. لا تحتاج إلى بيانات شخصية أو بيانات تواصل، ولا تُحفظ السلة أو الطلب.', en: 'Products, prices and photos are illustrative samples, not photos from a real shop. No real order is submitted, and nothing is sent to an API or email. No personal or contact details are needed, and the cart and order are not saved.' })}
            </div>
          </aside>
        </div>
      </div>
    </SiteShell>
  );
}
