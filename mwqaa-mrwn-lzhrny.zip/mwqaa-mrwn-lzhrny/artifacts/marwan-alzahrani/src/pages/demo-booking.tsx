import { useState } from 'react';
import { Link } from 'wouter';
import { ArrowLeft, ArrowRight, CalendarDays, Check, Clock3, RotateCcw } from 'lucide-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { SiteShell } from '@/components/site-shell';

const services = [
  { id: 'consult', ar: 'استشارة أولية', en: 'First consultation', duration: 30, price: 0 },
  { id: 'review', ar: 'مراجعة موقع', en: 'Website review', duration: 45, price: 80 },
  { id: 'planning', ar: 'جلسة تخطيط', en: 'Planning session', duration: 60, price: 120 },
];
const days = Array.from({ length: 5 }, (_, index) => {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() + index + 1);
  const id = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  return {
    id,
    ar: new Intl.DateTimeFormat('ar-SA-u-ca-gregory', { weekday: 'short' }).format(date),
    en: new Intl.DateTimeFormat('en-US', { weekday: 'short' }).format(date),
    date: String(date.getDate()),
    month: {
      ar: new Intl.DateTimeFormat('ar-SA-u-ca-gregory', { month: 'long' }).format(date),
      en: new Intl.DateTimeFormat('en-US', { month: 'short' }).format(date),
    },
  };
});
const times = ['09:30', '11:00', '13:30', '15:00', '17:30', '19:00'];

export default function BookingDemo() {
  const { t, lang, dir } = useLang();
  const [service, setService] = useState('');
  const [day, setDay] = useState('');
  const [time, setTime] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const BackIcon = dir === 'rtl' ? ArrowRight : ArrowLeft;
  useDocTitle({ ar: 'تجربة الحجز — مروان الزهراني', en: 'Booking demo — Marwan Alzahrani' });

  const reset = () => {
    setService('');
    setDay('');
    setTime('');
    setConfirmed(false);
  };
  const chosenService = services.find((item) => item.id === service);
  const chosenDay = days.find((item) => item.id === day);

  return (
    <SiteShell>
      <div className="mx-auto min-h-[70vh] max-w-6xl px-5 pb-20 pt-7 md:px-8 md:pt-12">
        <Link href="/" data-testid="link-demo-home" className="inline-flex items-center gap-2 rounded-full py-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground">
          <BackIcon className="h-4 w-4" />
          {t({ ar: 'العودة إلى الصفحة الرئيسية', en: 'Back to homepage' })}
        </Link>
        <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_330px] lg:items-start">
          <section>
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs font-bold text-primary">
              <span className="h-2 w-2 rounded-full bg-primary" />
              {t({ ar: 'عرض تجريبي تفاعلي', en: 'Interactive demo' })}
            </div>
            <h1 className="mt-5 font-display text-4xl font-extrabold leading-tight sm:text-5xl">
              {t({ ar: 'موعدك، بخطوات واضحة.', en: 'An appointment, without the back-and-forth.' })}
            </h1>
            <p className="mt-4 max-w-2xl text-lg leading-8 text-muted-foreground">
              {t({ ar: 'جرّب رحلة حجز بسيطة كما قد يراها عميل مشروع صغير.', en: 'Try a simple booking journey from the point of view of a small-business customer.' })}
            </p>
            <p className="mt-5 rounded-2xl border border-primary/20 bg-primary/5 px-4 py-3 text-sm leading-6 text-foreground/80" role="note" data-testid="notice-booking-demo-intro">
              {t({ ar: 'تجربة توضيحية فقط: لا يتم حجز موعد حقيقي أو إرسال أو حفظ أي بيانات.', en: 'Illustrative demo only: no real appointment is booked, and no data is sent or saved.' })}
            </p>

            {confirmed ? (
              <div className="mt-9 rounded-[1.75rem] border border-[hsl(168_35%_65%)] bg-[hsl(168_38%_95%)] p-7 sm:p-9" role="status" aria-live="polite" data-testid="status-booking-success">
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[hsl(168_40%_34%)] text-[hsl(var(--wool))]"><Check className="h-7 w-7" /></span>
                <p className="mt-6 text-sm font-bold text-[hsl(168_40%_28%)]">{t({ ar: 'تم التأكيد في هذه التجربة', en: 'Confirmed in this demo' })}</p>
                <h2 className="mt-2 font-display text-2xl font-bold">{t({ ar: 'حجز تجريبي مكتمل', en: 'Demo booking complete' })}</h2>
                <p className="mt-3 leading-7 text-foreground/75">
                  {t({ ar: `${chosenService?.ar} · ${chosenDay?.ar} ${chosenDay?.date} ${chosenDay?.month.ar} · ${time}`, en: `${chosenService?.en} · ${chosenDay?.en} ${chosenDay?.date} ${chosenDay?.month.en} · ${time}` })}
                </p>
                <p className="mt-5 border-t border-[hsl(168_35%_65%)]/60 pt-4 text-sm leading-6 text-foreground/70">
                  {t({ ar: 'هذا تأكيد محلي للعرض فقط؛ لا يوجد موعد حقيقي.', en: 'This is a local demo confirmation only; no real appointment exists.' })}
                </p>
                <button type="button" onClick={reset} data-testid="button-booking-reset-success" className="mt-6 inline-flex h-11 items-center gap-2 rounded-full bg-[hsl(var(--ink))] px-5 text-sm font-semibold text-[hsl(var(--wool))] transition-transform hover:-translate-y-0.5">
                  <RotateCcw className="h-4 w-4" />{t({ ar: 'ابدأ من جديد', en: 'Start over' })}
                </button>
              </div>
            ) : (
              <div className="mt-9 space-y-8">
                <fieldset>
                  <legend className="flex items-center gap-3 font-display text-xl font-bold">
                    <span className="num grid h-9 w-9 place-items-center rounded-xl bg-[hsl(var(--ink))] text-sm text-[hsl(var(--saffron))]">01</span>
                    {t({ ar: 'اختر الخدمة', en: 'Choose a service' })}
                  </legend>
                  <div className="mt-4 grid gap-3 sm:grid-cols-3">
                    {services.map((item) => (
                      <button key={item.id} type="button" onClick={() => setService(item.id)} aria-pressed={service === item.id} data-testid={`button-booking-service-${item.id}`} className={`rounded-2xl border p-4 text-start transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary ${service === item.id ? 'border-primary bg-primary/5 ring-1 ring-primary' : 'border-border bg-card hover:border-primary/50'}`}>
                        <span className="block font-semibold">{lang === 'ar' ? item.ar : item.en}</span>
                        <span className="mt-2 flex items-center justify-between gap-2 text-xs text-muted-foreground">
                          <span className="inline-flex items-center gap-1"><Clock3 className="h-3.5 w-3.5" />{item.duration} {t({ ar: 'دقيقة', en: 'min' })}</span>
                          <span>{item.price ? `${item.price} ${t({ ar: 'ر.س', en: 'SAR' })}` : t({ ar: 'مجانية', en: 'Free' })}</span>
                        </span>
                      </button>
                    ))}
                  </div>
                </fieldset>

                <fieldset>
                  <legend className="flex items-center gap-3 font-display text-xl font-bold">
                    <span className="num grid h-9 w-9 place-items-center rounded-xl bg-[hsl(var(--ink))] text-sm text-[hsl(var(--saffron))]">02</span>
                    {t({ ar: 'اختر اليوم', en: 'Choose a day' })}
                  </legend>
                  <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-5">
                    {days.map((item) => (
                      <button key={item.id} type="button" onClick={() => { setDay(item.id); setTime(''); }} aria-pressed={day === item.id} data-testid={`button-booking-day-${item.id}`} className={`rounded-2xl border px-2 py-3 text-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary ${day === item.id ? 'border-[hsl(var(--ink))] bg-[hsl(var(--ink))] text-[hsl(var(--wool))]' : 'border-border bg-card hover:border-primary/50'}`}>
                        <span className="block text-xs opacity-75">{lang === 'ar' ? item.ar : item.en}</span>
                        <span className="num mt-1 block text-2xl font-bold">{item.date}</span>
                        <span className="block text-xs opacity-75">{t(item.month)}</span>
                      </button>
                    ))}
                  </div>
                </fieldset>

                <fieldset>
                  <legend className="flex items-center gap-3 font-display text-xl font-bold">
                    <span className="num grid h-9 w-9 place-items-center rounded-xl bg-[hsl(var(--ink))] text-sm text-[hsl(var(--saffron))]">03</span>
                    {t({ ar: 'اختر الوقت', en: 'Choose a time' })}
                  </legend>
                  <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-6">
                    {times.map((slot) => (
                      <button key={slot} type="button" onClick={() => setTime(slot)} aria-pressed={time === slot} disabled={!day} data-testid={`button-booking-time-${slot.replace(':', '')}`} className={`num h-11 rounded-xl border text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:cursor-not-allowed disabled:opacity-40 ${time === slot ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card hover:border-primary/50'}`}>
                        {slot}
                      </button>
                    ))}
                  </div>
                  {!day && <p className="mt-2 text-xs text-muted-foreground">{t({ ar: 'اختر يومًا أولًا لعرض الأوقات.', en: 'Choose a day first to select a time.' })}</p>}
                </fieldset>

                <button type="button" onClick={() => setConfirmed(true)} disabled={!service || !day || !time} data-testid="button-booking-confirm" className="inline-flex h-14 w-full items-center justify-center gap-2 rounded-full bg-primary px-7 font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45 sm:w-auto">
                  <CalendarDays className="h-5 w-5" />{t({ ar: 'تأكيد الحجز التجريبي', en: 'Confirm demo booking' })}
                </button>
              </div>
            )}
          </section>

          <aside className="rounded-[1.75rem] bg-[hsl(var(--ink))] p-6 text-[hsl(var(--wool))] lg:sticky lg:top-24" aria-label={t({ ar: 'ملخص الحجز', en: 'Booking summary' })}>
            <div className="sadu-band -mx-6 -mt-6 mb-6 rounded-t-[1.75rem]" />
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-[hsl(var(--saffron))]">{t({ ar: 'ملخص التجربة', en: 'Your demo summary' })}</p>
            <h2 className="mt-2 font-display text-2xl font-bold">{t({ ar: 'تفاصيل الموعد', en: 'Appointment details' })}</h2>
            <div className="mt-6 divide-y divide-[hsl(var(--wool)/0.15)]">
              <div className="py-4">
                <span className="text-xs text-[hsl(var(--wool)/0.62)]">{t({ ar: 'الخدمة', en: 'Service' })}</span>
                <p className="mt-1 font-semibold" data-testid="text-booking-selected-service">{chosenService ? (lang === 'ar' ? chosenService.ar : chosenService.en) : t({ ar: 'لم تُحدد بعد', en: 'Not selected' })}</p>
              </div>
              <div className="py-4">
                <span className="text-xs text-[hsl(var(--wool)/0.62)]">{t({ ar: 'التاريخ', en: 'Date' })}</span>
                <p className="mt-1 font-semibold" data-testid="text-booking-selected-day">{chosenDay ? t({ ar: `${chosenDay.ar} ${chosenDay.date} ${chosenDay.month.ar}`, en: `${chosenDay.en}, ${chosenDay.month.en} ${chosenDay.date}` }) : t({ ar: 'لم يُحدد بعد', en: 'Not selected' })}</p>
              </div>
              <div className="py-4">
                <span className="text-xs text-[hsl(var(--wool)/0.62)]">{t({ ar: 'الوقت', en: 'Time' })}</span>
                <p className="num mt-1 font-semibold" data-testid="text-booking-selected-time">{time || t({ ar: 'لم يُحدد بعد', en: 'Not selected' })}</p>
              </div>
            </div>
            <div className="mt-2 rounded-2xl bg-[hsl(var(--wool)/0.08)] p-4 text-sm leading-6 text-[hsl(var(--wool)/0.8)]" data-testid="notice-booking-demo">
              {t({ ar: 'الخدمات والمواعيد المعروضة أمثلة توضيحية. لا يتم حجز موعد حقيقي أو إرسال أي شيء إلى API أو البريد الإلكتروني. لا تحتاج إلى إدخال بيانات شخصية أو بيانات تواصل، ولا تُحفظ اختياراتك.', en: 'The sample services and times are illustrative. No real booking is made, and nothing is sent to an API or email. No personal or contact details are needed, and your selections are not saved.' })}
            </div>
            {confirmed && <button type="button" onClick={reset} data-testid="button-booking-reset" className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-[hsl(var(--saffron))] hover:underline"><RotateCcw className="h-4 w-4" />{t({ ar: 'إعادة التجربة', en: 'Reset demo' })}</button>}
          </aside>
        </div>
      </div>
    </SiteShell>
  );
}
