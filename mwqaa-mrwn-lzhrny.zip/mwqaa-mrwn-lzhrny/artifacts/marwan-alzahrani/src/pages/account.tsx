import { useClerk, useUser, SignInButton, SignUpButton } from '@clerk/react';
import { Link } from 'wouter';
import {
  getListCustomerProjectRequestsQueryKey,
  useListCustomerProjectRequests,
} from '@workspace/api-client-react';
import { ArrowUpLeft, Loader2, MessageCircle, RefreshCw } from 'lucide-react';
import { Page } from '@/components/motion';
import { SiteShell } from '@/components/site-shell';
import { STATUS_LABEL, SERVICE_LABEL } from '@/lib/content';
import { useDocTitle, useLang } from '@/lib/i18n';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const accountUrl = `${basePath}/account`;

export default function CustomerAccount() {
  const { lang, t } = useLang();
  const { isLoaded, isSignedIn, user } = useUser();
  const { signOut } = useClerk();
  useDocTitle({ ar: 'حساب العميل — مروان الزهراني', en: 'Customer account — Marwan Alzahrani' });
  const requests = useListCustomerProjectRequests({
    query: {
      enabled: isLoaded && isSignedIn === true,
      queryKey: getListCustomerProjectRequestsQueryKey(),
    },
  });

  return (
    <SiteShell>
      <Page className="mx-auto min-h-[65vh] max-w-5xl px-5 pb-16 pt-10 md:px-8">
        {!isLoaded ? (
          <div className="grid min-h-64 place-items-center" role="status" aria-live="polite">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : !isSignedIn ? (
          <section className="mx-auto max-w-2xl rounded-[2rem] border border-card-border bg-card p-7 text-center shadow-sm sm:p-12">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-primary/10 text-primary">
              <MessageCircle className="h-8 w-8" />
            </div>
            <h1 className="mt-6 font-display text-3xl font-extrabold sm:text-4xl">
              {t({ ar: 'تابع طلبات مشروعك', en: 'Follow your project requests' })}
            </h1>
            <p className="mx-auto mt-4 max-w-lg leading-7 text-muted-foreground">
              {t({
                ar: 'أنشئ حسابًا أو سجّل الدخول لمشاهدة تحديثات طلباتك والانتقال إلى محادثتك الخاصة. يمكنك متابعة إرسال الطلبات دون حساب أيضًا.',
                en: 'Create an account or sign in to view request updates and open your private conversations. You can still submit requests without an account.',
              })}
            </p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <SignUpButton mode="redirect" forceRedirectUrl={accountUrl} signInForceRedirectUrl={accountUrl}>
                <button type="button" data-testid="button-customer-sign-up" className="inline-flex h-12 items-center justify-center rounded-full bg-primary px-7 font-semibold text-primary-foreground">
                  {t({ ar: 'إنشاء حساب', en: 'Create account' })}
                </button>
              </SignUpButton>
              <SignInButton mode="redirect" forceRedirectUrl={accountUrl} signUpForceRedirectUrl={accountUrl}>
                <button type="button" data-testid="button-customer-sign-in" className="inline-flex h-12 items-center justify-center rounded-full border border-border bg-background px-7 font-semibold">
                  {t({ ar: 'تسجيل الدخول', en: 'Sign in' })}
                </button>
              </SignInButton>
            </div>
            <Link href="/request" className="mt-6 inline-block text-sm font-semibold text-primary underline-offset-4 hover:underline">
              {t({ ar: 'إرسال طلب جديد دون حساب', en: 'Submit a request without an account' })}
            </Link>
          </section>
        ) : (
          <section>
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="text-sm font-semibold text-primary">{t({ ar: 'حساب العميل', en: 'Customer account' })}</p>
                <h1 className="mt-2 font-display text-3xl font-extrabold sm:text-4xl">
                  {t({ ar: `مرحبًا ${user?.firstName || ''}`, en: `Welcome ${user?.firstName || ''}` }).trim()}
                </h1>
                <p className="mt-2 text-sm text-muted-foreground">{user?.primaryEmailAddress?.emailAddress}</p>
              </div>
              <button
                type="button"
                onClick={() => signOut({ redirectUrl: basePath || '/' })}
                data-testid="button-customer-sign-out"
                className="h-10 rounded-full border border-border px-4 text-sm font-semibold hover:bg-muted"
              >
                {t({ ar: 'تسجيل الخروج', en: 'Sign out' })}
              </button>
            </div>

            <div className="mt-9 flex items-center justify-between gap-3">
              <h2 className="font-display text-xl font-bold sm:text-2xl">
                {t({ ar: 'طلبات مشاريعي', en: 'My project requests' })}
              </h2>
              <button
                type="button"
                onClick={() => void requests.refetch()}
                data-testid="button-refresh-customer-requests"
                aria-label={t({ ar: 'تحديث الطلبات', en: 'Refresh requests' })}
                className="grid h-10 w-10 place-items-center rounded-full border border-border hover:bg-muted"
              >
                <RefreshCw className={`h-4 w-4 ${requests.isFetching ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {requests.isLoading ? (
              <div className="grid min-h-48 place-items-center" role="status" aria-live="polite">
                <Loader2 className="h-7 w-7 animate-spin text-primary" />
              </div>
            ) : requests.isError ? (
              <div className="mt-5 rounded-2xl border border-destructive/30 bg-destructive/5 p-5" role="alert">
                <p className="font-semibold">{t({ ar: 'تعذّر تحميل طلباتك.', en: 'Could not load your requests.' })}</p>
                <button type="button" onClick={() => void requests.refetch()} className="mt-3 text-sm font-semibold text-primary underline">
                  {t({ ar: 'أعد المحاولة', en: 'Try again' })}
                </button>
              </div>
            ) : requests.data?.length ? (
              <div className="mt-5 grid gap-4">
                {requests.data.map((request) => (
                  <Link
                    key={request.reference}
                    href={`/c/${request.token}`}
                    data-testid={`link-customer-request-${request.reference}`}
                    className="group flex flex-col gap-4 rounded-2xl border border-card-border bg-card p-5 transition-shadow hover:shadow-md sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs font-bold text-muted-foreground" dir="ltr">{request.reference}</span>
                        <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">{t(STATUS_LABEL[request.status])}</span>
                        {request.unreadCount > 0 && (
                          <span className="rounded-full bg-accent px-3 py-1 text-xs font-bold text-accent-foreground">
                            {t({ ar: `رد جديد (${request.unreadCount})`, en: `New reply (${request.unreadCount})` })}
                          </span>
                        )}
                      </div>
                      <h3 className="mt-3 font-display text-lg font-bold">{t(SERVICE_LABEL[request.service])}</h3>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {t({ ar: 'أُرسل في', en: 'Submitted' })} {new Intl.DateTimeFormat(lang === 'ar' ? 'ar-SA' : 'en', { dateStyle: 'medium' }).format(new Date(request.createdAt))}
                      </p>
                    </div>
                    <span className="inline-flex items-center gap-2 text-sm font-semibold text-primary">
                      {t({ ar: 'عرض المحادثة والتحديثات', en: 'View conversation and updates' })}
                      <ArrowUpLeft className="h-4 w-4" />
                    </span>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="mt-5 rounded-2xl border border-dashed border-border bg-card/50 p-8 text-center">
                <h3 className="font-display text-lg font-bold">{t({ ar: 'لا توجد طلبات مرتبطة بهذا الحساب بعد.', en: 'No requests are linked to this account yet.' })}</h3>
                <p className="mx-auto mt-2 max-w-lg text-sm leading-6 text-muted-foreground">
                  {t({ ar: 'الطلبات التي أرسلتها دون تسجيل دخول تبقى متاحة عبر رابط المحادثة الخاص بها.', en: 'Requests submitted while signed out remain available through their private conversation links.' })}
                </p>
                <Link href="/request" className="mt-5 inline-flex h-11 items-center justify-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground">
                  {t({ ar: 'إرسال طلب مشروع', en: 'Submit a project request' })}
                </Link>
              </div>
            )}
          </section>
        )}
      </Page>
    </SiteShell>
  );
}
