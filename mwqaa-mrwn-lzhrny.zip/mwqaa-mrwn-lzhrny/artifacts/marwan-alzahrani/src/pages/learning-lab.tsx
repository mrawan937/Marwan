import { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { motion, useReducedMotion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, ArrowUpRight, Check, Code2, ExternalLink, GitBranch,
  Layers3, ListChecks, Server, ShieldCheck, Sparkles, Waypoints,
} from 'lucide-react';
import { SiLaravel, SiReact } from 'react-icons/si';
import { useLang, useDocTitle } from '@/lib/i18n';
import { SiteShell } from '@/components/site-shell';

type LocalText = { ar: string; en: string };
const copy = (ar: string, en: string): LocalText => ({ ar, en });

const starterTasks = [
  { id: 1, ar: 'أفهم تحديث الحالة في React', en: 'Understand state updates in React', done: true },
  { id: 2, ar: 'أجرّب فلترة قائمة صغيرة', en: 'Try filtering a small list', done: false },
  { id: 3, ar: 'أربط الواجهة بمسار REST تجريبي', en: 'Connect a view to a sample REST route', done: false },
];

const routes = [
  { id: 'index', method: 'GET', path: '/api/notes', ar: 'عرض الملاحظات', en: 'List notes', status: '200 OK', body: '[{"id": 1, "title": "ملاحظة محلية"}]' },
  { id: 'show', method: 'GET', path: '/api/notes/1', ar: 'عرض ملاحظة واحدة', en: 'Show one note', status: '200 OK', body: '{"id": 1, "title": "ملاحظة محلية"}' },
  { id: 'store', method: 'POST', path: '/api/notes', ar: 'إنشاء ملاحظة', en: 'Create a note', status: '201 Created', body: '{"id": 2, "title": "مثال تجريبي"}' },
];

const methods = [
  { id: 'GET', color: 'text-[hsl(168_40%_34%)]' },
  { id: 'POST', color: 'text-primary' },
  { id: 'PUT', color: 'text-[hsl(32_75%_40%)]' },
  { id: 'DELETE', color: 'text-destructive' },
];

function LearningIllustration() {
  return (
    <svg viewBox="0 0 520 390" role="img" aria-label="Abstract local code experiments" className="h-full w-full">
      <defs>
        <pattern id="lab-grid" width="22" height="22" patternUnits="userSpaceOnUse">
          <path d="M22 0H0V22" fill="none" stroke="currentColor" strokeOpacity=".12" />
        </pattern>
      </defs>
      <rect width="520" height="390" fill="url(#lab-grid)" />
      <circle cx="365" cy="145" r="113" fill="none" stroke="#e7af3f" strokeWidth="1" strokeDasharray="5 8" />
      <circle cx="365" cy="145" r="77" fill="#eee4ce" />
      <path d="M338 91c-29 11-43 43-32 72l59 71c18 22 53 25 75 5l12-11-98-121c-4-5-10-10-16-13Z" fill="#d8664f" />
      <path d="M355 84c27-11 58 3 67 30l31 88c8 23-4 49-27 57l-14 5-55-151c-2-7-3-17-2-29Z" fill="#28305e" />
      <circle cx="365" cy="145" r="7" fill="#e7af3f" />
      <g transform="translate(65 88) rotate(-6)">
        <rect width="247" height="176" rx="18" fill="#f6f0e3" stroke="#28305e" strokeOpacity=".18" />
        <path d="M0 47h247" stroke="#28305e" strokeOpacity=".15" />
        <circle cx="23" cy="24" r="4" fill="#d8664f" /><circle cx="38" cy="24" r="4" fill="#e7af3f" /><circle cx="53" cy="24" r="4" fill="#3a9b83" />
        <text x="23" y="79" fill="#d8664f" fontFamily="monospace" fontSize="13">const</text>
        <text x="68" y="79" fill="#28305e" fontFamily="monospace" fontSize="13">learning = true;</text>
        <text x="23" y="108" fill="#77748a" fontFamily="monospace" fontSize="12">// small steps, real practice</text>
        <path d="M23 133h58M23 149h105" stroke="#3a9b83" strokeWidth="5" strokeLinecap="round" />
      </g>
      <path d="M93 298h125m-62-36v36m-28 0 28 28 28-28" fill="none" stroke="#e7af3f" strokeWidth="2" />
      <rect x="315" y="270" width="127" height="57" rx="14" fill="#28305e" />
      <text x="378" y="305" textAnchor="middle" fill="#f6f0e3" fontFamily="monospace" fontSize="14">TRY / LEARN</text>
    </svg>
  );
}

function SectionLabel({ number, title }: { number: string; title: string }) {
  return <div className="mb-5 flex items-center gap-3"><span className="num grid h-9 w-9 place-items-center rounded-xl bg-[hsl(var(--ink))] text-xs font-bold text-[hsl(var(--saffron))]">{number}</span><h2 className="font-display text-2xl font-bold sm:text-3xl">{title}</h2></div>;
}

function ConceptIllustration({ kind }: { kind: 'react' | 'laravel' | 'rest' }) {
  return (
    <svg viewBox="0 0 128 76" aria-hidden="true" className="h-16 w-24 shrink-0 sm:h-[4.5rem] sm:w-32">
      <rect x="1" y="1" width="126" height="74" rx="15" fill="#f5efe3" />
      {kind === 'react' && (
        <>
          <ellipse cx="64" cy="38" rx="37" ry="14" fill="none" stroke="#15967e" strokeWidth="2.5" />
          <ellipse cx="64" cy="38" rx="37" ry="14" fill="none" stroke="#15967e" strokeWidth="2.5" transform="rotate(60 64 38)" />
          <ellipse cx="64" cy="38" rx="37" ry="14" fill="none" stroke="#15967e" strokeWidth="2.5" transform="rotate(120 64 38)" />
          <circle cx="64" cy="38" r="5" fill="#d8664f" />
        </>
      )}
      {kind === 'laravel' && (
        <>
          <path d="M29 38h25m20 0h25M64 22v32" stroke="#28305e" strokeWidth="2.5" strokeLinecap="round" />
          <rect x="12" y="27" width="30" height="22" rx="6" fill="#f05340" />
          <rect x="49" y="13" width="30" height="22" rx="6" fill="#28305e" />
          <rect x="86" y="27" width="30" height="22" rx="6" fill="#3a9b83" />
          <circle cx="64" cy="57" r="5" fill="#e7af3f" />
        </>
      )}
      {kind === 'rest' && (
        <>
          <rect x="11" y="23" width="30" height="30" rx="8" fill="#28305e" />
          <rect x="87" y="23" width="30" height="30" rx="8" fill="#3a9b83" />
          <path d="M44 32h34l-7-7m7 7-7 7M84 45H50l7-7m-7 7 7 7" fill="none" stroke="#d8664f" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="26" cy="38" r="3" fill="#e7af3f" />
          <circle cx="102" cy="38" r="3" fill="#f5efe3" />
        </>
      )}
    </svg>
  );
}

function ReactPractice({ t }: { t: (value: LocalText) => string }) {
  const [items, setItems] = useState(starterTasks);
  const [filter, setFilter] = useState<'all' | 'open' | 'done'>('all');
  const visible = useMemo(() => items.filter((item) => filter === 'all' || (filter === 'done' ? item.done : !item.done)), [items, filter]);
  const completed = items.filter((item) => item.done).length;
  const filters = [
    { id: 'all' as const, label: copy('الكل', 'All') },
    { id: 'open' as const, label: copy('قيد التعلّم', 'In progress') },
    { id: 'done' as const, label: copy('تمّت', 'Learned') },
  ];
  return (
    <div className="rounded-[1.6rem] border border-card-border bg-card p-5 shadow-sm sm:p-7">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div><p className="num text-xs text-muted-foreground">01 / REACT.JS</p><h3 className="mt-2 font-display text-xl font-bold">{t(copy('قائمة تتذكّر حالتها', 'A list that remembers its state'))}</h3><p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">{t(copy('بدّل حالة عنصر أو غيّر الفلتر. الواجهة تُعاد صياغتها من الحالة المحلية فقط.', 'Toggle an item or change the filter. The interface is rendered from local state only.'))}</p></div>
        <div className="flex items-center gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e8f5f2] text-[#14957c]"><SiReact className="h-6 w-6" aria-label="React" /></span><ConceptIllustration kind="react" /></div>
      </div>
      <div className="mt-6 rounded-2xl bg-background p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-1.5" role="group" aria-label={t(copy('تصفية المهام', 'Filter tasks'))}>
            {filters.map((option) => <button key={option.id} type="button" data-testid={`button-react-filter-${option.id}`} aria-pressed={filter === option.id} onClick={() => setFilter(option.id)} className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${filter === option.id ? 'bg-[hsl(var(--ink))] text-[hsl(var(--wool))]' : 'text-muted-foreground hover:bg-muted'}`}>{t(option.label)}</button>)}
          </div>
          <span className="num text-xs text-muted-foreground">{completed}/{items.length} {t(copy('مكتمل', 'complete'))}</span>
        </div>
        <ul className="mt-4 divide-y divide-border/70">
          {visible.map((item) => <li key={item.id} data-testid={`item-learning-task-${item.id}`} className="flex items-center gap-3 py-3">
            <button type="button" data-testid={`button-react-toggle-${item.id}`} aria-pressed={item.done} aria-label={t(item.done ? copy(`إلغاء إكمال: ${item.ar}`, `Mark incomplete: ${item.en}`) : copy(`إكمال: ${item.ar}`, `Mark complete: ${item.en}`))} onClick={() => setItems((current) => current.map((row) => row.id === item.id ? { ...row, done: !row.done } : row))} className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border transition-colors ${item.done ? 'border-[#3a9b83] bg-[#3a9b83] text-white' : 'border-border hover:border-primary'}`}>{item.done && <Check className="h-3.5 w-3.5" />}</button>
            <span className={`flex-1 text-sm ${item.done ? 'text-muted-foreground line-through' : 'font-medium'}`}>{t(copy(item.ar, item.en))}</span>
            <span className="num text-[10px] text-muted-foreground">#{String(item.id).padStart(2, '0')}</span>
          </li>)}
          {visible.length === 0 && <li className="py-5 text-center text-sm text-muted-foreground">{t(copy('لا عناصر في هذا العرض بعد.', 'Nothing in this view yet.'))}</li>}
        </ul>
      </div>
      <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground"><ListChecks className="h-4 w-4 text-primary" />{t(copy('جرّب التبويبات ومربعات الاختيار — لا شيء يغادر هذه الصفحة.', 'Try the tabs and checkboxes — nothing leaves this page.'))}</p>
    </div>
  );
}

function LaravelPractice({ t }: { t: (value: LocalText) => string }) {
  const [selected, setSelected] = useState(routes[0].id);
  const [ran, setRan] = useState(false);
  const active = routes.find((route) => route.id === selected) ?? routes[0];
  return (
    <div className="rounded-[1.6rem] border border-card-border bg-card p-5 shadow-sm sm:p-7">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div><p className="num text-xs text-muted-foreground">02 / LARAVEL</p><h3 className="mt-2 font-display text-xl font-bold">{t(copy('مسارات على طاولة العمل', 'Routes on the workbench'))}</h3><p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">{t(copy('اختر مسارًا لتقرأ شكل طلبه واستجابته كما لو كنت تتتبّع موردًا بسيطًا.', 'Select a route to inspect its request and response, like tracing a small resource.'))}</p></div>
        <div className="flex items-center gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#fff0ec] text-[#f05340]"><SiLaravel className="h-6 w-6" aria-label="Laravel" /></span><ConceptIllustration kind="laravel" /></div>
      </div>
      <div className="mt-6 grid gap-4 lg:grid-cols-[.8fr_1.2fr]">
        <div className="space-y-2" role="group" aria-label={t(copy('مسارات تجريبية', 'Sample routes'))}>
          {routes.map((route) => <button key={route.id} type="button" data-testid={`button-laravel-route-${route.id}`} aria-pressed={selected === route.id} onClick={() => { setSelected(route.id); setRan(false); }} className={`w-full rounded-xl border p-3 text-start transition-colors ${selected === route.id ? 'border-primary/60 bg-primary/5' : 'border-border bg-background hover:border-primary/40'}`}>
            <span className={`num inline-flex rounded-md px-2 py-1 text-[10px] font-bold ${route.method === 'POST' ? 'bg-primary/10 text-primary' : 'bg-[#e8f5f2] text-[#16816e]'}`}>{route.method}</span><span className="num ms-2 text-xs">{route.path}</span>
            <span className="mt-2 block text-xs text-muted-foreground">{t(copy(route.ar, route.en))}</span>
          </button>)}
        </div>
        <div className="overflow-hidden rounded-2xl bg-[hsl(var(--ink))] text-[hsl(var(--wool))]">
          <div className="flex items-center justify-between border-b border-white/10 px-4 py-3"><span className="flex items-center gap-2 text-xs font-semibold"><Server className="h-4 w-4 text-[hsl(var(--saffron))]" />{t(copy('محاكاة محلية', 'Local simulation'))}</span><span className="num text-[10px] text-white/50">routes/web.php</span></div>
          <div className="space-y-4 p-4">
            <div><p className="mb-2 text-[10px] uppercase tracking-wider text-white/50">{t(copy('تعريف المسار', 'Route definition'))}</p><code className="block overflow-x-auto rounded-lg bg-white/[0.07] p-3 text-xs leading-6 text-[#f3c96b]"><span className="text-[#8ed3bb]">Route::</span>{active.method.toLowerCase()}(<span className="text-[#e89480]">'{active.path}'</span>, [NoteController::<span className="text-[#c4b4ee]">{active.id === 'index' ? 'index' : active.id === 'show' ? 'show' : 'store'}</span>]);</code></div>
            <div className="flex flex-wrap items-center justify-between gap-2"><p className="text-[10px] uppercase tracking-wider text-white/50">{t(copy('استجابة نموذجية', 'Sample response'))}</p><button type="button" data-testid="button-run-laravel-simulation" onClick={() => setRan(true)} className="inline-flex items-center gap-1.5 rounded-full bg-[hsl(var(--saffron))] px-3 py-1.5 text-xs font-bold text-[hsl(var(--ink))] transition-transform hover:-translate-y-0.5"><GitBranch className="h-3.5 w-3.5" />{t(copy('شغّل المحاكاة', 'Run simulation'))}</button></div>
            {ran ? <div className="rounded-lg border border-[#8ed3bb]/30 bg-[#8ed3bb]/10 p-3" role="status"><span className="num text-xs font-bold text-[#8ed3bb]">{active.status}</span><pre dir="ltr" className="mt-2 overflow-x-auto whitespace-pre-wrap font-mono text-xs leading-5 text-white/80">{active.body}</pre></div> : <div className="rounded-lg border border-dashed border-white/20 px-3 py-4 text-xs text-white/55">{t(copy('اضغط «شغّل المحاكاة» لعرض استجابة ثابتة داخل المتصفح.', 'Press “Run simulation” to reveal a fixed response in the browser.'))}</div>}
          </div>
        </div>
      </div>
      <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground"><ShieldCheck className="h-4 w-4 text-primary" />{t(copy('لا يوجد خادم Laravel خلف هذا المثال ولا تُرسل طلبات.', 'There is no Laravel server behind this example, and no requests are sent.'))}</p>
    </div>
  );
}

function RestPractice({ t }: { t: (value: LocalText) => string }) {
  const [method, setMethod] = useState('GET');
  const [response, setResponse] = useState(false);
  const code = method === 'POST' ? '201 Created' : '200 OK';
  const result = method === 'DELETE' ? '{ "deleted": true }' : method === 'POST' ? '{ "id": 4, "title": "فكرة محلية" }' : method === 'PUT' ? '{ "id": 1, "title": "عنوان محدّث" }' : '{ "id": 1, "title": "ملاحظة" }';
  return (
    <div className="rounded-[1.6rem] border border-card-border bg-card p-5 shadow-sm sm:p-7">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div><p className="num text-xs text-muted-foreground">03 / REST + HTTP</p><h3 className="mt-2 font-display text-xl font-bold">{t(copy('مجرّب طلبات بلا شبكة', 'A request workbench with no network'))}</h3><p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">{t(copy('غيّر طريقة HTTP ثم اعرض استجابة توضيحية ثابتة. شاهد كيف يتبدّل معنى الطلب.', 'Switch the HTTP method and reveal a fixed illustrative response. See how the request’s meaning changes.'))}</p></div>
        <div className="flex items-center gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#fff6dc] text-[#9c6e12]"><Waypoints className="h-6 w-6" /></span><ConceptIllustration kind="rest" /></div>
      </div>
      <div className="mt-6 overflow-hidden rounded-2xl border border-border">
        <div className="flex flex-wrap gap-2 border-b border-border bg-background p-3" role="group" aria-label={t(copy('طريقة الطلب', 'Request method'))}>
          {methods.map((item) => <button key={item.id} type="button" data-testid={`button-rest-method-${item.id.toLowerCase()}`} aria-pressed={method === item.id} onClick={() => { setMethod(item.id); setResponse(false); }} className={`num rounded-lg px-3 py-2 text-xs font-bold transition-colors ${method === item.id ? 'bg-[hsl(var(--ink))] text-[hsl(var(--wool))]' : `bg-card ${item.color} hover:bg-muted`}`}>{item.id}</button>)}
        </div>
        <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
          <div className="flex min-w-0 flex-1 items-center gap-3 rounded-xl bg-muted/70 px-4 py-3" dir="ltr"><span className="num text-xs font-bold text-primary">{method}</span><span className="num truncate text-sm text-foreground/75">/api/notes{method === 'GET' || method === 'PUT' || method === 'DELETE' ? '/1' : ''}</span></div>
          <button type="button" data-testid="button-rest-response" onClick={() => setResponse(true)} className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5"><Code2 className="h-4 w-4" />{t(copy('عرض الاستجابة', 'Show response'))}</button>
        </div>
        {response && <div className="mx-4 mb-4 rounded-xl border border-[#3a9b83]/30 bg-[#eaf5f0] p-4" role="status" aria-live="polite"><div className="flex items-center justify-between"><span className="text-xs font-semibold text-[#246d5d]">{t(copy('رد تجريبي محلي', 'Local sample response'))}</span><span className="num text-xs font-bold text-[#246d5d]">{code}</span></div><pre dir="ltr" className="mt-3 overflow-x-auto font-mono text-xs leading-6 text-[hsl(var(--ink))]">{result}</pre></div>}
      </div>
      <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground"><Layers3 className="h-4 w-4 text-primary" />{t(copy('هذا عرض لمفاهيم HTTP فقط؛ لا توجد واجهة API أو بيانات خارجية.', 'This illustrates HTTP concepts only; there is no API or external data.'))}</p>
    </div>
  );
}

export default function LearningLab() {
  const { t, lang, dir } = useLang();
  const reduce = useReducedMotion();
  useDocTitle({ ar: 'مختبر التعلّم — مروان الزهراني', en: 'Learning lab — Marwan Alzahrani' });
  const BackIcon = dir === 'rtl' ? ArrowRight : ArrowLeft;
  return (
    <SiteShell>
      <div className="overflow-hidden">
        <section className="relative isolate overflow-hidden bg-[hsl(var(--ink))] text-[hsl(var(--wool))]">
          <div className="sadu-diamonds absolute inset-0 opacity-60" />
          <div className="relative mx-auto grid max-w-7xl items-center gap-5 px-5 pb-14 pt-7 md:px-8 md:pb-20 md:pt-10 lg:grid-cols-[1fr_.9fr]">
            <div>
              <Link href="/" data-testid="link-learning-home" className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-white/75 transition-colors hover:bg-white/10 hover:text-white"><BackIcon className="h-4 w-4" />{t(copy('العودة للرئيسية', 'Back to homepage'))}</Link>
              <motion.div initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .6 }} className="mt-10 inline-flex items-center gap-2 rounded-full border border-[hsl(var(--saffron)/.38)] bg-[hsl(var(--saffron)/.1)] px-3 py-1.5 text-xs font-bold text-[hsl(var(--saffron))]">
                <Sparkles className="h-3.5 w-3.5" />{t(copy('دفتر مفتوح للتعلّم', 'An open notebook for learning'))}
              </motion.div>
              <motion.h1 initial={reduce ? false : { opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .08, duration: .65 }} className="mt-5 max-w-2xl font-display text-4xl font-extrabold leading-[1.3] sm:text-6xl">
                {t(copy('أتعلم، أجرّب، ثم أتعلم أكثر.', 'Learning by making. Then learning more.'))}
              </motion.h1>
              <motion.p initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .2 }} className="mt-5 max-w-xl text-base leading-8 text-[hsl(var(--wool)/.72)] sm:text-lg">
                {t(copy('أنا مروان. أوسّع أدواتي الآن في React.js وLaravel وواجهات REST — وهذه مساحة صغيرة أشارك فيها ما أكتشفه خطوة بخطوة.', 'I’m Marwan. I’m expanding my toolkit with React.js, Laravel and REST APIs — this is a small space to share what I discover, one step at a time.'))}
              </motion.p>
              <div className="mt-7 flex flex-wrap gap-2">
                {['React.js', 'Laravel', 'REST / HTTP'].map((tag) => <span key={tag} className="num rounded-full border border-white/15 px-3 py-1.5 text-xs text-white/80">{tag}</span>)}
              </div>
            </div>
            <motion.div initial={reduce ? false : { opacity: 0, y: 12, rotate: 2 }} animate={{ opacity: 1, y: 0, rotate: 0 }} transition={{ delay: .16, duration: .8 }} className="mx-auto w-full max-w-[520px] rounded-[2rem] border border-white/10 bg-[hsl(var(--wool)/.04)] p-3 text-[hsl(var(--wool))] sm:p-5">
              <LearningIllustration />
            </motion.div>
          </div>
          <div className="sadu-band relative" />
        </section>

        <main className="mx-auto max-w-7xl px-5 pb-16 pt-10 md:px-8 md:pt-16">
          <div className="mx-auto max-w-4xl rounded-[1.5rem] border border-primary/25 bg-primary/[.045] p-5 sm:p-6" role="note" data-testid="notice-learning-local">
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><ShieldCheck className="h-5 w-5" /></span>
              <div><p className="font-display font-bold">{t(copy('قبل أن تجرّب — توضيح مهم', 'Before you try anything — a clear note'))}</p>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{t(copy('هذه تمارين تعلّم محلية من عملي الشخصي، وليست أعمالًا لعملاء أو خدمات إنتاجية. كل التفاعلات تعمل داخل المتصفح ببيانات تجريبية؛ لا تُرسل رسائل أو حجوزات أو طلبات API، ولا تحفظ بيانات ولا تطلب أي معلومات شخصية.', 'These are local learning exercises from my personal practice—not client work or production services. Every interaction runs in your browser with sample data; nothing sends messages, bookings or API requests, nothing is saved, and no personal information is requested.'))}</p>
              </div>
            </div>
          </div>

          <div className="mx-auto mt-12 max-w-4xl">
            <SectionLabel number="01" title={t(copy('التعلّم عبر ثلاث تجارب', 'Three ways to explore'))} />
            <p className="mb-7 text-sm leading-7 text-muted-foreground">{t(copy('نماذج صغيرة، لكل منها فكرة واحدة يمكنك لمسها بنفسك. لا توجد نتيجة مثالية مطلوبة — الفضول يكفي.', 'Small demos, each with one idea you can explore. There is no perfect result expected; curiosity is enough.'))}</p>
            <div className="space-y-6">
              <ReactPractice t={t} />
              <LaravelPractice t={t} />
              <RestPractice t={t} />
            </div>
          </div>

          <section className="mx-auto mt-16 max-w-4xl rounded-[1.75rem] bg-muted/70 p-6 sm:p-8">
            <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--ink))] text-[hsl(var(--saffron))]"><Code2 className="h-5 w-5" /></span><h2 className="font-display text-xl font-bold">{t(copy('مراجع أرجع إليها', 'References I’m learning from'))}</h2></div>
            <p className="mt-3 text-sm leading-6 text-muted-foreground">{t(copy('المراجع الرسمية هي نقطة البداية؛ هذه النماذج محاولتي لفهم بعض الأفكار عمليًا.', 'Official documentation is the starting point; these demos are my attempt to understand a few ideas hands-on.'))}</p>
            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              {[
                { href: 'https://react.dev/learn', icon: SiReact, ar: 'تعلّم React', en: 'Learn React', color: 'text-[#14957c]' },
                { href: 'https://laravel.com/docs', icon: SiLaravel, ar: 'توثيق Laravel', en: 'Laravel documentation', color: 'text-[#f05340]' },
                { href: 'https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview', icon: Waypoints, ar: 'نظرة عامة على HTTP', en: 'HTTP overview', color: 'text-[#9c6e12]' },
              ].map((resource) => <a key={resource.href} href={resource.href} target="_blank" rel="noreferrer" className="group flex min-h-16 items-center gap-3 rounded-xl border border-border bg-card px-4 py-3 transition-transform hover:-translate-y-0.5 hover:border-primary/40" data-testid={`link-reference-${resource.en.toLowerCase().replaceAll(' ', '-')}`}>
                <resource.icon className={`h-5 w-5 shrink-0 ${resource.color}`} aria-hidden="true" />
                <span className="flex-1 text-sm font-semibold">{t(copy(resource.ar, resource.en))}</span>
                <ExternalLink className="h-4 w-4 text-muted-foreground transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
              </a>)}
            </div>
          </section>

          <div className="mx-auto mt-10 flex max-w-4xl flex-col items-start justify-between gap-4 border-t border-border pt-6 sm:flex-row sm:items-center">
            <p className="max-w-xl text-sm leading-6 text-muted-foreground">{t(copy('أشارك ما أتعلمه كما هو: تجارب صغيرة، أسئلة مفتوحة، ومساحة دائمًا للتحسّن.', 'I share the learning as it is: small experiments, open questions, and room to keep improving.'))}</p>
            <Link href="/" data-testid="link-learning-client-work" className="group inline-flex shrink-0 items-center gap-2 text-sm font-semibold text-primary">{t(copy('اكتشف أعمال العملاء', 'Explore client work'))}<ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></Link>
          </div>
        </main>
      </div>
    </SiteShell>
  );
}
