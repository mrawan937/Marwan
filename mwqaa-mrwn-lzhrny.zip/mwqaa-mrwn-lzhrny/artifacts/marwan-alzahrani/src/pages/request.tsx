import { useMemo, useRef, useState } from 'react';
import { useLocation, useSearch } from 'wouter';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, AlertTriangle, MessagesSquare } from 'lucide-react';
import {
  useCreateProjectRequest,
  ServiceType,
  BudgetRange,
  ProjectTimeline,
  type ProjectRequestInput,
} from '@workspace/api-client-react';
import { useLang, useDocTitle, type L } from '@/lib/i18n';
import { BUDGET_LABEL, SERVICE_LABEL, TIMELINE_LABEL } from '@/lib/content';
import { ServiceIcon } from '@/components/brand';
import { markWelcome, saveConversation } from '@/lib/conversations';
import { Page } from '@/components/motion';
import { SiteShell } from '@/components/site-shell';
import { cn } from '@/lib/utils';

const SERVICE_VALUES = Object.values(ServiceType) as [ServiceType, ...ServiceType[]];
const BUDGET_VALUES = Object.values(BudgetRange) as [BudgetRange, ...BudgetRange[]];
const TIMELINE_VALUES = Object.values(ProjectTimeline) as [ProjectTimeline, ...ProjectTimeline[]];

function makeSchema(t: (l: L) => string) {
  return z.object({
    name: z.string().trim().min(2, t({ ar: 'الاسم قصير جدًا؛ أدخل حرفين على الأقل.', en: 'Name is too short; enter at least 2 characters.' })).max(100, t({ ar: 'الاسم طويل جدًا؛ الحد الأقصى 100 حرف.', en: 'Name is too long; the limit is 100 characters.' })),
    email: z.string().trim().max(200).email(t({ ar: 'البريد الإلكتروني غير صحيح', en: 'Invalid email address' })).or(z.literal('')),
    organization: z.string().trim().max(120, t({ ar: 'الحد الأقصى 120 حرفًا.', en: 'The limit is 120 characters.' })),
    service: z.enum(SERVICE_VALUES, { errorMap: () => ({ message: t({ ar: 'اختر الخدمة', en: 'Choose a service' }) }) }),
    budget: z.enum(BUDGET_VALUES).or(z.literal('')),
    timeline: z.enum(TIMELINE_VALUES).or(z.literal('')),
    description: z
      .string()
      .trim()
      .min(10, t({ ar: 'أضف مزيدًا من التفاصيل (10 أحرف على الأقل).', en: 'Please add more detail (at least 10 characters).' }))
      .max(3000, t({ ar: 'الحد الأقصى 3000 حرف.', en: 'The limit is 3,000 characters.' })),
  });
}
type FormValues = z.infer<ReturnType<typeof makeSchema>>;

function Field({ id, label, optional, error, children, hint }: { id?: string; label: string; optional?: boolean; error?: string; children: React.ReactNode; hint?: string }) {
  const { t } = useLang();
  const errorId = id ? `${id}-error` : undefined;
  const hintId = id && hint ? `${id}-hint` : undefined;
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between gap-3">
        {id ? (
          <label htmlFor={id} className="text-sm font-semibold">
            {label}
            {!optional && <span className="ms-1 text-primary">*</span>}
          </label>
        ) : (
          <span className="text-sm font-semibold">
            {label}
            {!optional && <span className="ms-1 text-primary">*</span>}
          </span>
        )}
        {optional && <span className="text-xs text-muted-foreground">{t({ ar: 'اختياري', en: 'Optional' })}</span>}
      </div>
      {children}
      {hint && !error && <p id={hintId} className="mt-1.5 text-xs text-muted-foreground">{hint}</p>}
      <AnimatePresence>
        {error && (
          <motion.p id={errorId} initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-1.5 text-xs font-medium text-destructive" role="alert">
            {error}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}

const inputCls =
  'w-full rounded-xl border border-input bg-card px-4 py-3.5 text-base outline-none transition-shadow placeholder:text-muted-foreground/70 focus:border-primary focus:ring-4 focus:ring-primary/15';

function Chip({ active, onClick, children, testid }: { active: boolean; onClick: () => void; children: React.ReactNode; testid: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-testid={testid}
      aria-pressed={active}
      className={cn(
        'rounded-xl border px-4 py-3 text-sm font-medium transition-all',
        active ? 'border-foreground bg-foreground text-background' : 'border-input bg-card hover:border-foreground/50',
      )}
    >
      {children}
    </button>
  );
}

export default function RequestPage() {
  const { t } = useLang();
  useDocTitle({ ar: 'اطلب مشروعك — مروان الزهراني', en: 'Request a project — Marwan Alzahrani' });
  const search = useSearch();
  const preset = useMemo(() => {
    const v = new URLSearchParams(search).get('service');
    return v && (SERVICE_VALUES as string[]).includes(v) ? (v as ServiceType) : undefined;
  }, [search]);

  const schema = useMemo(() => makeSchema(t), [t]);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: '',
      email: '',
      organization: '',
      service: preset as ServiceType,
      budget: '',
      timeline: '',
      description: '',
    },
  });
  const { register, handleSubmit, control, formState, watch } = form;
  const errors = formState.errors;
  const create = useCreateProjectRequest();
  const submissionIdsRef = useRef(new Map<string, string>());
  const [, navigate] = useLocation();
  const [submitError, setSubmitError] = useState<{ kind: 'rate' | 'invalid' | 'conflict' | 'other' } | null>(null);
  const desc = watch('description') ?? '';
  const service = watch('service');

  const onSubmit = (v: FormValues) => {
    setSubmitError(null);
    const data: ProjectRequestInput = {
      name: v.name.trim(),
      service: v.service,
      description: v.description.trim(),
    };
    if (v.email.trim()) data.email = v.email.trim();
    if (v.organization.trim()) data.organization = v.organization.trim();
    if (v.budget) data.budget = v.budget;
    if (v.timeline) data.timeline = v.timeline;
    const fingerprint = JSON.stringify(data);
    let submissionId = submissionIdsRef.current.get(fingerprint);
    if (!submissionId) {
      submissionId = crypto.randomUUID();
      submissionIdsRef.current.set(fingerprint, submissionId);
    }
    data.submissionId = submissionId;
    create.mutate(
      { data },
      {
        onSuccess: (r) => {
          submissionIdsRef.current.clear();
          saveConversation({ token: r.token, reference: r.reference, createdAt: new Date(r.createdAt).toISOString() });
          markWelcome(r.token);
          navigate(`/c/${r.token}`, { replace: true });
        },
        onError: (err) => {
          const status = (err as { status?: number }).status;
          if (status === 409) submissionIdsRef.current.delete(fingerprint);
          setSubmitError({ kind: status === 429 ? 'rate' : status === 400 ? 'invalid' : status === 409 ? 'conflict' : 'other' });
        },
      },
    );
  };

  return (
    <SiteShell>
      <Page className="mx-auto max-w-7xl px-5 pb-10 pt-6 md:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.6fr]">
            <aside className="lg:sticky lg:top-24 lg:self-start">
              <h1 className="font-display text-4xl font-extrabold leading-tight sm:text-5xl">{t({ ar: 'أخبرني عن مشروعك.', en: 'Tell me about your project.' })}</h1>
              <p className="mt-4 text-lg leading-8 text-muted-foreground">{t({ ar: 'لن يستغرق إرسال الطلب أكثر من دقيقتين. سأقرأه بنفسي وأرد عليك عبر صفحة محادثة خاصة على الموقع.', en: 'It takes about two minutes to send a request. I’ll read it myself and reply through a private conversation page on the site.' })}</p>
              <div className="mt-8 rounded-[1.5rem] bg-[hsl(var(--ink))] p-6 text-[hsl(var(--wool))]" data-testid="box-how-it-works">
                <div className="flex items-center gap-2 text-sm font-semibold text-[hsl(var(--saffron))]">
                  <MessagesSquare className="h-4 w-4" />
                  {t({ ar: 'كيف يجري التواصل؟', en: 'How communication works' })}
                </div>
                <ol className="mt-4 space-y-3 text-sm leading-6">
                  {[
                    { ar: 'أرسل طلبك عبر النموذج.', en: 'Send your request through the form.' },
                    { ar: 'تُفتح لك صفحة محادثة خاصة بك وبمروان فقط.', en: 'A private conversation page opens for you and Marwan only.' },
                    { ar: 'أرد عليك من الصفحة نفسها، وتتابع مستجدات مشروعك من خلالها.', en: 'I reply on that page, where you can follow your project’s progress.' },
                  ].map((step, i) => (
                    <li key={i} className="flex gap-3">
                      <span className="num grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[hsl(var(--wool)/0.12)] text-xs font-bold">{i + 1}</span>
                      <span className="text-[hsl(var(--wool)/0.85)]">{t(step)}</span>
                    </li>
                  ))}
                </ol>
                <p className="mt-5 border-t border-[hsl(var(--wool)/0.12)] pt-4 text-xs leading-6 text-[hsl(var(--wool)/0.6)]">{t({ ar: 'يبقى التواصل والردود داخل الموقع، دون الحاجة إلى مشاركة رقم هاتف أو استخدام واتساب.', en: 'All project messages and replies stay on this site; you don’t need to share a phone number or use WhatsApp.' })}</p>
              </div>
            </aside>

            <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-10 rounded-[2rem] border border-card-border bg-card/60 p-6 md:p-10" data-testid="form-request">
              <section className="space-y-5">
                <h2 className="flex items-center gap-3 font-display text-lg font-bold"><span className="num grid h-8 w-8 place-items-center rounded-full bg-primary text-sm text-primary-foreground">1</span>{t({ ar: 'ما الخدمة التي تحتاج إليها؟', en: 'What service do you need?' })}</h2>
                <Field label={t({ ar: 'الخدمة', en: 'Service' })} error={errors.service?.message}>
                  <Controller
                    control={control}
                    name="service"
                    render={({ field }) => (
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                        {SERVICE_VALUES.map((s) => (
                          <button
                            key={s}
                            type="button"
                            onClick={() => field.onChange(s)}
                            data-testid={`button-service-${s}`}
                            aria-pressed={field.value === s}
                            className={cn(
                              'flex flex-col items-start gap-3 rounded-2xl border p-4 text-start text-sm font-semibold transition-all',
                              field.value === s ? 'border-primary bg-primary text-primary-foreground shadow-md' : 'border-input bg-card hover:border-foreground/40',
                            )}
                          >
                            <ServiceIcon type={s} className="h-7 w-7" />
                            {t(SERVICE_LABEL[s])}
                          </button>
                        ))}
                      </div>
                    )}
                  />
                </Field>
                {service === 'community_package' && (
                  <p className="rounded-xl bg-accent/30 p-4 text-sm leading-6">{t({ ar: 'باقة المجتمع مخصصة للأسر المنتجة والجمعيات الخيرية. اكتب اسم مشروعك أو جمعيتك في الحقل أدناه.', en: 'The community package is for productive families and charities. Enter your project or charity name below.' })}</p>
                )}
                <Field id="project-description" label={t({ ar: 'وصف المشروع', en: 'Project description' })} error={errors.description?.message}>
                  <textarea id="project-description" aria-invalid={Boolean(errors.description)} aria-describedby={errors.description ? 'project-description-error' : undefined} {...register('description')} rows={6} data-testid="input-description" className={cn(inputCls, 'resize-y leading-7')} placeholder={t({ ar: 'مثال: أملك متجرًا للعطور، وأرغب في موقع يعرض المنتجات ويتيح للعملاء إرسال الطلبات.', en: 'For example: I run a perfume shop and want a site to showcase products and receive orders.' })} />
                  <div className="num mt-1 text-end text-xs text-muted-foreground">{desc.length} / 3000</div>
                </Field>
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label={t({ ar: 'الميزانية التقريبية', en: 'Approximate budget' })} optional>
                    <Controller control={control} name="budget" render={({ field }) => (
                      <div className="flex flex-wrap gap-2">
                        {BUDGET_VALUES.map((b) => (
                          <Chip key={b} active={field.value === b} onClick={() => field.onChange(field.value === b ? '' : b)} testid={`button-budget-${b}`}>{t(BUDGET_LABEL[b])}</Chip>
                        ))}
                      </div>
                    )} />
                  </Field>
                  <Field label={t({ ar: 'متى تحتاج إلى إنجازه؟', en: 'When do you need it completed?' })} optional>
                    <Controller control={control} name="timeline" render={({ field }) => (
                      <div className="flex flex-wrap gap-2">
                        {TIMELINE_VALUES.map((b) => (
                          <Chip key={b} active={field.value === b} onClick={() => field.onChange(field.value === b ? '' : b)} testid={`button-timeline-${b}`}>{t(TIMELINE_LABEL[b])}</Chip>
                        ))}
                      </div>
                    )} />
                  </Field>
                </div>
              </section>

              <section className="space-y-5">
                <h2 className="flex items-center gap-3 font-display text-lg font-bold"><span className="num grid h-8 w-8 place-items-center rounded-full bg-primary text-sm text-primary-foreground">2</span>{t({ ar: 'معلومات عنك', en: 'About you' })}</h2>
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field id="request-name" label={t({ ar: 'الاسم', en: 'Name' })} error={errors.name?.message}>
                    <input id="request-name" aria-invalid={Boolean(errors.name)} aria-describedby={errors.name ? 'request-name-error' : undefined} {...register('name')} data-testid="input-name" autoComplete="name" className={inputCls} />
                  </Field>
                  <Field id="request-organization" label={t({ ar: 'اسم المشروع أو الجهة', en: 'Business or organisation' })} optional error={errors.organization?.message}>
                    <input id="request-organization" aria-invalid={Boolean(errors.organization)} aria-describedby={errors.organization ? 'request-organization-error' : undefined} {...register('organization')} data-testid="input-organization" className={inputCls} />
                  </Field>
                </div>
                <Field
                  id="request-email"
                  label={t({ ar: 'بريدك الإلكتروني للتنبيه', en: 'Email for alerts' })}
                  optional
                  error={errors.email?.message}
                  hint={t({ ar: 'إذا أضفت بريدك الإلكتروني، سأرسل إليك تنبيهًا مختصرًا عند وصول رد جديد. ستجد الرد كاملًا في صفحة محادثتك.', en: 'If you add your email, I’ll send a brief alert when I reply. The full reply will remain on your conversation page.' })}
                >
                  <input id="request-email" aria-invalid={Boolean(errors.email)} aria-describedby={errors.email ? 'request-email-error' : 'request-email-hint'} {...register('email')} data-testid="input-email" type="email" autoComplete="email" dir="ltr" className={inputCls} />
                </Field>
              </section>

              <AnimatePresence>
                {submitError && (
                  <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex gap-3 rounded-2xl border border-destructive/30 bg-destructive/10 p-4 text-sm leading-6" role="alert" data-testid="status-submit-error">
                    <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
                    <div>
                      {submitError.kind === 'rate' && t({ ar: 'أرسلت طلبات كثيرة خلال وقت قصير. أعد المحاولة بعد 15 دقيقة.', en: 'Too many submissions in a short time. Please try again in 15 minutes.' })}
                      {submitError.kind === 'invalid' && t({ ar: 'بعض البيانات غير صحيحة. راجع الحقول وحاول مرة أخرى.', en: 'Some details are invalid. Please check the fields and try again.' })}
                      {submitError.kind === 'conflict' && t({ ar: 'تغيّرت تفاصيل الطلب بعد محاولة سابقة. أرسله مرة أخرى لإنشاء متابعة جديدة.', en: 'The request details changed after an earlier attempt. Submit again to create a new tracking link.' })}
                      {submitError.kind === 'other' && t({ ar: 'لم نتأكد من وصول الطلب بسبب مشكلة اتصال. يمكنك إعادة المحاولة؛ سيمنع النظام إنشاء طلب مكرر للتفاصيل نفسها.', en: 'We could not confirm the request because of a connection problem. You can retry; the same details will not create a duplicate request.' })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <button type="submit" disabled={create.isPending} data-testid="button-submit-request" className="flex h-14 w-full items-center justify-center gap-2 rounded-full bg-primary text-base font-semibold text-primary-foreground shadow-lg transition-transform hover:-translate-y-0.5 disabled:opacity-70">
                {create.isPending && <Loader2 className="h-5 w-5 animate-spin" />}
                {create.isPending ? t({ ar: 'جارٍ إرسال الطلب…', en: 'Sending…' }) : t({ ar: 'أرسل الطلب', en: 'Send request' })}
              </button>
            </form>
          </div>
      </Page>
    </SiteShell>
  );
}
