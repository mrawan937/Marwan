import { Link } from 'wouter';
import { Calculator, Languages, Store, HeartHandshake } from 'lucide-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { asset, SaduBand, ServiceIcon } from '@/components/brand';
import { Page, Reveal } from '@/components/motion';
import { Arrow, SiteShell } from '@/components/site-shell';

export default function Community() {
  const { t } = useLang();
  useDocTitle({ ar: 'ركن المجتمع — مروان الزهراني', en: 'Community corner — Marwan Alzahrani' });

  const who = [
    { icon: Store, title: { ar: 'الأسر المنتجة', en: 'Productive families' }, body: { ar: 'مشروعك المنزلي يستحق واجهة احترافية تعرض منتجاتك وتسهّل على العملاء طلبها.', en: 'Your home business deserves a professional storefront that showcases products and makes ordering easy.' } },
    { icon: HeartHandshake, title: { ar: 'الجمعيات الخيرية', en: 'Charities' }, body: { ar: 'موقع يعرّف بالجمعية وبرامجها، أو نظام بسيط لتسجيل المستفيدين والمتطوعين.', en: 'A site presenting your charity and its programmes, or a simple system to register beneficiaries and volunteers.' } },
  ];
  const includes = [
    { ar: 'موقع تعريفي متجاوب، أو نظام تسجيل وحجز بسيط', en: 'A responsive website, or a simple registration / booking system' },
    { ar: 'زر واضح لإرسال الطلب ومتابعته عبر المحادثة الخاصة في الموقع', en: 'A clear button to send a request and follow up through the site’s private conversation' },
    { ar: 'مساعدة في النشر والاستضافة', en: 'Help with publishing and hosting' },
    { ar: 'متابعة مباشرة معي عبر محادثة خاصة في الموقع حتى اكتمال المشروع', en: 'Direct follow-up with me through a private conversation on the site until the project is complete' },
  ];

  return (
    <SiteShell>
      <Page>
        <section className="mx-auto max-w-7xl px-5 pb-16 pt-6 md:px-8">
          <div className="grid items-center gap-10 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1.5 text-sm font-semibold text-primary">
                <ServiceIcon type="community_package" className="h-5 w-5" />
                {t({ ar: 'ركن المجتمع', en: 'Community corner' })}
              </span>
              <h1 className="mt-6 font-display text-4xl font-extrabold leading-tight sm:text-6xl">
                {t({ ar: 'هل يخدم مشروعك المجتمع؟', en: 'Does your project serve the community?' })}
                <span className="block text-primary">{t({ ar: 'قد تستفيد من سعر مخفّض.', en: 'You may qualify for reduced pricing.' })}</span>
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-8 text-muted-foreground">
                {t({
                  ar: 'باقة المجتمع مخصصة للأسر المنتجة والجمعيات الخيرية، وتقدّم الجودة والعناية نفسيهما بسعر مخفّض. وهي طريقتي لردّ الجميل للمجتمع الذي علّمني.',
                  en: 'The community package for productive families and charities: the same quality and care, at a discounted price. It’s my way of giving back to the community that taught me.',
                })}
              </p>
              <Link href="/request?service=community_package" data-testid="link-community-apply" className="mt-8 inline-flex h-14 items-center gap-2 rounded-full bg-primary px-8 font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5">
                {t({ ar: 'اطلب باقة المجتمع', en: 'Request the community package' })}
                <Arrow className="h-5 w-5" />
              </Link>
            </div>
            <div className="relative">
              <img src={asset('images/community.jpg')} alt={t({ ar: 'طاولة مشروع منزلي عليها تمور وبهارات', en: 'Home-business table with dates and spices' })} className="aspect-[4/3] w-full rounded-[2rem] object-cover shadow-xl" />
              <div className="absolute -bottom-6 start-6 rounded-2xl bg-accent px-5 py-3 font-display font-bold text-accent-foreground shadow-lg">
                {t({ ar: 'سعر مخفّض', en: 'Discounted' })}
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-5 py-16 md:px-8">
          <div className="grid gap-5 md:grid-cols-2">
            {who.map((w, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className="h-full rounded-[1.75rem] border border-card-border bg-card p-8">
                  <w.icon className="h-9 w-9 text-primary" />
                  <h2 className="mt-5 font-display text-2xl font-bold">{t(w.title)}</h2>
                  <p className="mt-3 leading-7 text-muted-foreground">{t(w.body)}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal>
            <div className="mt-5 overflow-hidden rounded-[1.75rem] bg-[hsl(var(--ink))] text-[hsl(var(--wool))]">
              <SaduBand />
              <div className="grid gap-8 p-8 md:grid-cols-[1fr_1.4fr] md:p-10">
                <div>
                  <h2 className="font-display text-2xl font-bold text-[hsl(var(--saffron))]">{t({ ar: 'ماذا تشمل الباقة؟', en: 'What the package includes' })}</h2>
                  <p className="mt-3 text-sm leading-7 text-[hsl(var(--wool)/0.7)]">{t({ ar: 'تُحدّد التفاصيل والتكلفة بحسب احتياجك. أرسل طلبك للحصول على عرض سعر.', en: 'The details and cost depend on your needs. Send a request for a quote.' })}</p>
                </div>
                <ul className="grid gap-3 sm:grid-cols-2">
                  {includes.map((x, i) => (
                    <li key={i} className="flex gap-3 rounded-xl bg-[hsl(var(--wool)/0.06)] p-4 text-sm leading-6">
                      <span className="mt-1.5 h-2 w-2 shrink-0 rotate-45 bg-primary" />
                      {t(x)}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>
        </section>

        <section className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <h2 className="font-display text-3xl font-bold sm:text-4xl">{t({ ar: 'أدوات مجانية', en: 'Free tools' })}</h2>
                <p className="mt-3 text-muted-foreground">{t({ ar: 'أدوات مجانية للجميع، من التطبيقات التي طوّرتها.', en: 'Free tools for everyone, built from apps I’ve developed.' })}</p>
          </Reveal>
          <div className="mt-8 grid gap-5 md:grid-cols-3">
            <Reveal className="md:col-span-2">
              <Link href="/tasbeeh" data-testid="link-community-tasbeeh" className="group flex h-full flex-col justify-between gap-8 rounded-[1.75rem] bg-primary p-8 text-primary-foreground">
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-[hsl(var(--wool)/0.2)] px-3 py-1 text-xs font-semibold">{t({ ar: 'متاح الآن', en: 'Live now' })}</span>
                  <Arrow className="h-6 w-6 transition-transform group-hover:-translate-y-1" />
                </div>
                <div>
                  <h3 className="font-display text-3xl font-bold">{t({ ar: 'السبحة الذكية', en: 'Smart Tasbeeh' })}</h3>
                  <p className="mt-2 text-primary-foreground/85">{t({ ar: 'عدّاد للأذكار مع أهداف يومية وإجمالي محفوظ على جهازك. لا يتطلب تسجيلًا ولا يعرض إعلانات.', en: 'A dhikr counter with daily targets and a total saved on your device. No sign-up or ads.' })}</p>
                </div>
              </Link>
            </Reveal>
            <Reveal delay={0.08}>
              <div className="flex h-full flex-col gap-4 rounded-[1.75rem] border border-dashed border-border p-8">
                <span className="w-fit rounded-full bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground">{t({ ar: 'تطبيقات الجوال', en: 'Mobile apps' })}</span>
                <div className="flex items-center gap-3"><Calculator className="h-5 w-5 text-primary" />{t({ ar: 'الآلة الحاسبة', en: 'Calculator' })}</div>
                <div className="flex items-center gap-3"><Languages className="h-5 w-5 text-primary" />{t({ ar: 'مترجم النصوص عبر البلوتوث', en: 'Bluetooth Text Translator' })}</div>
                <p className="mt-auto text-xs leading-6 text-muted-foreground">{t({ ar: 'طُوّرت هذه التطبيقات باستخدام MIT App Inventor وJava.', en: 'These apps were developed with MIT App Inventor and Java.' })}</p>
              </div>
            </Reveal>
          </div>
        </section>
      </Page>
    </SiteShell>
  );
}
