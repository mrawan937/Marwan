import { Link, useParams } from 'wouter';
import { motion, useReducedMotion } from 'framer-motion';
import { useLang, useDocTitle } from '@/lib/i18n';
import { SERVICES, serviceBySlug } from '@/lib/content';
import { asset, ServiceIcon } from '@/components/brand';
import { Page, Reveal } from '@/components/motion';
import { Arrow, SiteShell } from '@/components/site-shell';
import NotFound from './not-found';

export default function ServicePage() {
  const params = useParams<{ slug: string }>();
  const s = serviceBySlug(params.slug);
  const { t } = useLang();
  const reduce = useReducedMotion();
  useDocTitle(s ? { ar: `${s.name.ar} — مروان الزهراني`, en: `${s.name.en} — Marwan Alzahrani` } : { ar: 'غير موجود', en: 'Not found' });
  if (!s) return <NotFound />;
  const idx = SERVICES.indexOf(s);
  const others = SERVICES.filter((x) => x.slug !== s.slug);
  const relatedDemo = s.slug === 'booking-system'
    ? { href: '/demo/booking', label: { ar: 'جرّب نموذج الحجز التوضيحي', en: 'Try the booking demo' } }
    : s.slug === 'business-website'
      ? { href: '/demo/cafe', label: { ar: 'شاهد نموذج قائمة متجر', en: 'View a sample storefront' } }
      : s.slug === 'mobile-app'
        ? { href: '/tasbeeh', label: { ar: 'جرّب أداة السبحة على الويب', en: 'Try the web Tasbeeh tool' } }
        : null;

  return (
    <SiteShell>
      <Page>
        <section className="mx-auto max-w-7xl px-5 pb-16 pt-6 md:px-8">
          <Link href="/#services" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground" data-testid="link-back-services">
            {t({ ar: 'كل الخدمات', en: 'All services' })}
          </Link>
          <div className="mt-6 grid items-end gap-10 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <div className="flex items-center gap-4">
                <span className="grid h-16 w-16 place-items-center rounded-2xl bg-[hsl(var(--ink))] text-[hsl(var(--wool))]">
                  <ServiceIcon type={s.type} className="h-9 w-9" />
                </span>
                <span className="num text-sm text-muted-foreground">0{idx + 1} / 05</span>
              </div>
              <h1 className="mt-6 font-display text-4xl font-extrabold leading-tight sm:text-6xl">{t(s.name)}</h1>
              <p className="mt-5 max-w-xl text-lg leading-8 text-muted-foreground">{t(s.pitch)}</p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link href={`/request?service=${s.type}`} data-testid="link-service-request" className="inline-flex h-14 items-center justify-center gap-2 rounded-full bg-primary px-8 font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5">
                  {t({ ar: 'اطلب عرض سعر', en: 'Request a quote' })}
                  <Arrow className="h-5 w-5" />
                </Link>
                {relatedDemo && (
                  <Link href={relatedDemo.href} data-testid="link-service-demo" className="inline-flex h-14 items-center justify-center gap-2 rounded-full border border-border bg-card px-6 font-semibold transition-colors hover:border-primary/50 hover:text-primary">
                    {t(relatedDemo.label)}
                    <Arrow className="h-5 w-5" />
                  </Link>
                )}
              </div>
            </div>
            <motion.div
              initial={reduce ? false : { opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="relative"
            >
              <div className="absolute -bottom-4 -end-4 h-full w-full rounded-[2rem] bg-primary" />
              <img src={asset(s.image)} alt={t(s.imageAlt)} className="relative aspect-[4/3] w-full rounded-[2rem] object-cover shadow-xl" />
            </motion.div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-5 py-16 md:px-8">
          <Reveal>
            <h2 className="font-display text-3xl font-bold sm:text-4xl">{t({ ar: 'ما الذي تتضمنه الخدمة؟', en: 'What you get' })}</h2>
          </Reveal>
          <div className="mt-10 grid gap-5 sm:grid-cols-2">
            {s.gets.map((g, i) => (
              <Reveal key={i} delay={i * 0.06}>
                <div className="flex h-full gap-5 rounded-[1.5rem] border border-card-border bg-card p-6">
                  <span className="num font-display text-3xl font-bold text-primary">0{i + 1}</span>
                  <div>
                    <h3 className="font-display text-lg font-bold">{t(g.title)}</h3>
                    <p className="mt-1.5 leading-7 text-muted-foreground">{t(g.body)}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="mx-auto grid max-w-7xl gap-5 px-5 md:px-8 lg:grid-cols-2">
          <Reveal>
            <div className="h-full rounded-[1.75rem] bg-[hsl(var(--ink))] p-8 text-[hsl(var(--wool))]">
              <h3 className="font-display text-xl font-bold text-[hsl(var(--saffron))]">{t({ ar: 'لمن تناسب هذه الخدمة؟', en: 'Who it’s for' })}</h3>
              <ul className="mt-5 space-y-3">
                {s.forWho.map((f, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <span className="h-2 w-2 rotate-45 bg-primary" />
                    {t(f)}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
          <Reveal delay={0.08}>
            <div className="h-full rounded-[1.75rem] border border-card-border bg-card p-8">
              <h3 className="font-display text-xl font-bold">{t({ ar: 'التقنيات المستخدمة', en: 'Built with' })}</h3>
              <div className="mt-5 flex flex-wrap gap-2">
                {s.stack.map((x) => (
                  <span key={x} className="num rounded-lg bg-muted px-3 py-1.5 text-sm">{x}</span>
                ))}
              </div>
              <div className="mt-8 rounded-2xl border border-dashed border-primary/50 p-5">
                <div className="text-sm font-semibold text-primary">{t({ ar: 'السعر', en: 'Price' })}</div>
                <div className="mt-1 font-display text-xl font-bold">{t({ ar: 'عرض سعر يناسب مشروعك', en: 'A quote for your project' })}</div>
                <p className="mt-1 text-sm text-muted-foreground">{t({ ar: 'تختلف التكلفة بحسب تفاصيل كل مشروع. أرسل فكرتك لأقدّم لك عرضًا واضحًا.', en: 'The cost depends on each project. Send your idea and I’ll provide a clear quote.' })}</p>
              </div>
            </div>
          </Reveal>
        </section>

        <section className="mx-auto max-w-7xl px-5 pt-20 md:px-8">
          <h2 className="font-display text-2xl font-bold">{t({ ar: 'خدمات أخرى', en: 'Other services' })}</h2>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {others.map((o) => (
              <Link key={o.slug} href={`/services/${o.slug}`} data-testid={`link-other-${o.slug}`} className="group flex items-center gap-4 rounded-2xl border border-card-border bg-card p-4 transition-all hover:-translate-y-0.5 hover:shadow-md">
                <img src={asset(o.image)} alt="" loading="lazy" className="h-14 w-14 rounded-xl object-cover" />
                <div className="flex-1 text-sm font-semibold">{t(o.name)}</div>
                <Arrow className="h-4 w-4 text-primary opacity-0 transition-opacity group-hover:opacity-100" />
              </Link>
            ))}
          </div>
        </section>
      </Page>
    </SiteShell>
  );
}
