import { useEffect, useMemo, useState } from 'react';
import { Copy, Globe2, ImagePlus, RotateCcw, Share2, X } from 'lucide-react';
import { Link } from 'wouter';
import { SiteShell } from '@/components/site-shell';
import { useDocTitle, useLang } from '@/lib/i18n';

const tx = (ar: string, en: string) => ({ ar, en });
const SAMPLE = {
  title: 'مشروعك يبدأ بخطوة واضحة',
  description: 'اكتب وصفًا قصيرًا يشرح فائدة مشروعك للعميل، ثم عاين كيف قد تظهر بطاقة المشاركة.',
  url: 'https://example.com/project',
};
const escapeAttribute = (value: string) => value.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

export default function SharePreview() {
  const { t, dir } = useLang();
  useDocTitle(tx('معاينة بطاقة المشاركة — مروان الزهراني', 'Share-card preview — Marwan Alzahrani'));
  const [title, setTitle] = useState(SAMPLE.title);
  const [description, setDescription] = useState(SAMPLE.description);
  const [url, setUrl] = useState(SAMPLE.url);
  const [notice, setNotice] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState('');
  const [imageNotice, setImageNotice] = useState('');
  useEffect(() => {
    if (!imageFile) {
      setImageUrl('');
      return;
    }
    const objectUrl = URL.createObjectURL(imageFile);
    setImageUrl(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [imageFile]);
  const host = useMemo(() => {
    try {
      const parsed = new URL(/^https?:\/\//iu.test(url) ? url : `https://${url}`);
      return parsed.protocol === 'https:' || parsed.protocol === 'http:' ? parsed.host : t(tx('رابط غير صالح', 'Invalid URL'));
    } catch {
      return t(tx('أدخل رابطًا صحيحًا', 'Enter a valid URL'));
    }
  }, [url, t]);
  const reset = () => {
    setTitle(SAMPLE.title);
    setDescription(SAMPLE.description);
    setUrl(SAMPLE.url);
    setNotice('');
    setImageFile(null);
    setImageNotice('');
  };
  const selectImage = (file?: File) => {
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setImageNotice(t(tx('اختر صورة JPG أو PNG أو WebP.', 'Choose a JPG, PNG or WebP image.')));
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setImageNotice(t(tx('حجم الصورة أكبر من ٥ ميغابايت. اختر صورة أصغر.', 'The image is larger than 5 MB. Choose a smaller file.')));
      return;
    }
    setImageFile(file);
    setImageNotice(t(tx('تُعرض الصورة محليًا في متصفحك فقط؛ لا تُرفع إلى أي خادم.', 'The image is previewed locally in your browser and is not uploaded.')));
  };
  const copyTags = async () => {
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(url.trim());
      if (!['http:', 'https:'].includes(parsedUrl.protocol)) throw new Error('protocol');
    } catch {
      setNotice(t(tx('أدخل رابطًا كاملًا يبدأ بـ https:// قبل نسخ الوسوم.', 'Enter a complete URL beginning with https:// before copying the tags.')));
      return;
    }
    const safeTitle = escapeAttribute(title.trim());
    const safeDescription = escapeAttribute(description.trim());
    const safeUrl = escapeAttribute(parsedUrl.href);
    const snippet = `<title>${safeTitle}</title>\n<meta name="description" content="${safeDescription}">\n<meta property="og:title" content="${safeTitle}">\n<meta property="og:description" content="${safeDescription}">\n<meta property="og:url" content="${safeUrl}">`;
    try {
      await navigator.clipboard.writeText(snippet);
      setNotice(t(tx('نُسخت وسوم المعاينة. راجعها قبل استخدامها في موقعك.', 'Preview tags copied. Review them before using them on your site.')));
    } catch {
      setNotice(t(tx('تعذّر النسخ التلقائي. حدّد النص المعروض وانسخه يدويًا.', 'Automatic copy was blocked. Select and copy the preview tags manually.')));
    }
  };
  const snippet = `<title>${escapeAttribute(title.trim())}</title>\n<meta name="description" content="${escapeAttribute(description.trim())}">\n<meta property="og:title" content="${escapeAttribute(title.trim())}">\n<meta property="og:description" content="${escapeAttribute(description.trim())}">\n<meta property="og:url" content="${escapeAttribute(url.trim())}">`;

  return (
    <SiteShell>
      <main className="mx-auto max-w-7xl px-5 py-10 md:px-8 md:py-16">
        <div className="mx-auto max-w-4xl">
          <Link href="/" data-testid="link-share-preview-home" className="text-sm font-semibold text-primary underline-offset-4 hover:underline">{t(tx('العودة إلى الأعمال', 'Back to the portfolio'))}</Link>
          <div className="mt-7 flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-primary/10 text-primary"><Share2 className="h-6 w-6" aria-hidden="true" /></span>
            <span className="rounded-full border border-primary/20 px-3 py-1 text-xs font-bold text-primary">{t(tx('أداة تفاعلية محلية', 'Interactive browser tool'))}</span>
          </div>
          <h1 data-testid="heading-share-preview" className="mt-4 font-display text-4xl font-extrabold leading-tight sm:text-5xl">{t(tx('عاين بطاقة مشاركة موقعك', 'Preview your website share card'))}</h1>
          <p className="mt-3 max-w-3xl leading-7 text-muted-foreground">{t(tx('جرّب عنوان الصفحة ووصفها ورابطها، ثم انسخ وسومًا أولية لتراجعها مع مطور موقعك. هذه معاينة وليست فحصًا لمحركات البحث أو ضمانًا لظهور النتيجة نفسها على كل منصة.', 'Try a page title, description and URL, then copy draft tags to review with your developer. This is a preview—not a search-engine audit or a guarantee that every platform will render it identically.'))}</p>

          <section data-testid="notice-share-preview-local" className="mt-6 rounded-2xl border border-primary/20 bg-primary/[.045] p-4 text-sm leading-6 text-muted-foreground">
            <span className="inline-flex items-center gap-2 font-semibold text-foreground"><Globe2 className="h-4 w-4 text-primary" aria-hidden="true" />{t(tx('خصوصيتك', 'Your privacy'))}</span>
            <p className="mt-1">{t(tx('كل المعاينة والحسابات تتم على جهازك؛ لا نرسل النص أو الرابط ولا نحفظه بعد مغادرة الصفحة.', 'The preview runs on your device. Your text and URL are not sent or saved after you leave.'))}</p>
          </section>

          <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_.95fr]">
            <section className="rounded-[1.6rem] border border-card-border bg-card p-5 shadow-sm sm:p-7" aria-label={t(tx('مدخلات بطاقة المشاركة', 'Share-card inputs'))}>
              <label htmlFor="share-title" className="flex items-center justify-between gap-3 text-sm font-bold">
                <span>{t(tx('عنوان الصفحة', 'Page title'))}</span><span className="num text-xs text-muted-foreground">{title.length}/70</span>
              </label>
              <input id="share-title" data-testid="input-share-title" dir={dir} maxLength={70} value={title} onChange={(event) => setTitle(event.target.value)} className="mt-2 h-12 w-full rounded-xl border border-input bg-background px-3 text-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary" />
              <label htmlFor="share-description" className="mt-5 flex items-center justify-between gap-3 text-sm font-bold">
                <span>{t(tx('وصف مختصر', 'Short description'))}</span><span className="num text-xs text-muted-foreground">{description.length}/200</span>
              </label>
              <textarea id="share-description" data-testid="input-share-description" dir={dir} maxLength={200} rows={4} value={description} onChange={(event) => setDescription(event.target.value)} className="mt-2 w-full resize-y rounded-xl border border-input bg-background px-3 py-3 text-sm leading-7 focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary" />
              <label htmlFor="share-url" className="mt-5 block text-sm font-bold">{t(tx('رابط الصفحة', 'Page URL'))}</label>
              <input id="share-url" data-testid="input-share-url" dir="ltr" type="url" inputMode="url" value={url} onChange={(event) => setUrl(event.target.value)} className="mt-2 h-12 w-full rounded-xl border border-input bg-background px-3 text-left text-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary" />
              <div className="mt-5">
                <label htmlFor="share-image" className="flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-primary/35 bg-primary/[.035] px-4 text-sm font-semibold text-primary transition-colors hover:bg-primary/[.07]">
                  <ImagePlus className="h-4 w-4" aria-hidden="true" />{t(tx(imageFile ? 'اختر صورة أخرى للمعاينة' : 'أضف صورة للمعاينة فقط', imageFile ? 'Choose another preview image' : 'Add an image for preview only'))}
                </label>
                <input id="share-image" data-testid="input-share-image" type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => { selectImage(event.target.files?.[0]); event.target.value = ''; }} className="sr-only" />
                <p data-testid="text-share-image-note" aria-live="polite" className="mt-2 text-xs leading-5 text-muted-foreground">{imageNotice || t(tx('JPG أو PNG أو WebP، بحد أقصى ٥ ميغابايت. تبقى الصورة على جهازك ولا تُضاف إلى وسوم النشر.', 'JPG, PNG or WebP, up to 5 MB. The image stays on your device and is not added to the published tags.'))}</p>
                {imageFile && <button type="button" data-testid="button-remove-share-image" onClick={() => { setImageFile(null); setImageNotice(''); }} className="mt-2 inline-flex min-h-9 items-center gap-1.5 rounded-full border border-border px-3 text-xs font-semibold"><X className="h-3.5 w-3.5" aria-hidden="true" />{t(tx('إزالة الصورة', 'Remove image'))}</button>}
              </div>
              <div className="mt-5 flex flex-wrap gap-2">
                <button type="button" data-testid="button-copy-share-tags" onClick={() => void copyTags()} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 text-sm font-bold text-primary-foreground"><Copy className="h-4 w-4" aria-hidden="true" />{t(tx('انسخ وسوم المعاينة', 'Copy draft tags'))}</button>
                <button type="button" data-testid="button-reset-share-preview" onClick={reset} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-border px-4 text-sm font-semibold"><RotateCcw className="h-4 w-4" aria-hidden="true" />{t(tx('إعادة المثال', 'Reset sample'))}</button>
              </div>
              <p data-testid="status-share-copy" role="status" aria-live="polite" className="mt-3 min-h-5 text-xs leading-5 text-muted-foreground">{notice}</p>
            </section>

            <div className="space-y-4">
              <section aria-labelledby="share-result-heading">
                <h2 id="share-result-heading" className="mb-3 font-display text-lg font-bold">{t(tx('معاينة تقريبية', 'Approximate preview'))}</h2>
                <article data-testid="card-share-preview" className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
                  {imageUrl ? <img data-testid="img-share-preview" src={imageUrl} alt={t(tx('صورة محلية لمعاينة بطاقة المشاركة', 'Local image preview for the share card'))} className="aspect-[1.91/1] w-full bg-muted object-cover" /> : (
                    <div className="relative grid aspect-[1.91/1] place-items-center overflow-hidden bg-[hsl(var(--ink))] p-6 text-center text-[hsl(var(--wool))]">
                      <div className="absolute inset-0 opacity-40" style={{ backgroundImage: 'radial-gradient(circle at 15% 20%, hsl(var(--primary)) 0, transparent 32%), radial-gradient(circle at 85% 85%, hsl(var(--saffron)) 0, transparent 28%)' }} />
                      <div className="relative max-w-sm">
                        <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-white/15 bg-white/10"><Share2 className="h-5 w-5 text-[hsl(var(--saffron))]" aria-hidden="true" /></span>
                        <p className="mt-3 text-xs text-white/60">{t(tx('أضف صورة لترى معاينة أقرب لبطاقة المشاركة.', 'Add an image for a closer share-card preview.'))}</p>
                      </div>
                    </div>
                  )}
                  <div className="p-4">
                    <p data-testid="text-share-host" dir="ltr" className="text-xs text-muted-foreground">{host}</p>
                    <h3 data-testid="text-share-title-preview" dir={dir} className="mt-1 line-clamp-2 font-bold">{title || t(tx('سيظهر عنوان الصفحة هنا', 'Your page title will appear here'))}</h3>
                    <p data-testid="text-share-description-preview" dir={dir} className="mt-1 line-clamp-3 text-sm leading-6 text-muted-foreground">{description || t(tx('سيظهر وصف الصفحة هنا', 'Your page description will appear here'))}</p>
                  </div>
                </article>
              </section>
              <section className="rounded-2xl border border-border bg-muted/50 p-4">
                <h3 className="text-sm font-bold">{t(tx('مسودة الوسوم', 'Draft meta tags'))}</h3>
                <pre data-testid="text-share-tags" dir="ltr" className="mt-2 max-h-40 overflow-auto whitespace-pre-wrap break-all rounded-xl bg-background p-3 text-xs leading-5 text-muted-foreground">{snippet}</pre>
                <p className="mt-2 text-xs leading-5 text-muted-foreground">{t(tx('راجع طول النص والصورة النهائية وطريقة عرض المنصة قبل النشر. لا تضع معلومات سرية في الأداة.', 'Review text length, final image and platform rendering before publishing. Do not enter secrets here.'))}</p>
              </section>
            </div>
          </div>
        </div>
      </main>
    </SiteShell>
  );
}
