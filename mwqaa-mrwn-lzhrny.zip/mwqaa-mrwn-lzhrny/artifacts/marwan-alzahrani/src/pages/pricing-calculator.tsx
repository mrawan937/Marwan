import { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { ArrowLeft, ArrowRight, Calculator, Check, Clipboard, RotateCcw, Wallet } from 'lucide-react';
import { useDocTitle, useLang } from '@/lib/i18n';
import { SiteShell } from '@/components/site-shell';

function money(value: number, lang: 'ar' | 'en') {
  return new Intl.NumberFormat(lang === 'ar' ? 'ar-SA' : 'en-SA', {
    style: 'currency',
    currency: 'SAR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

export default function PricingCalculator() {
  const { t, lang, dir } = useLang();
  useDocTitle({ ar: 'حاسبة سعر البيع — مروان الزهراني', en: 'Selling price calculator — Marwan Alzahrani' });
  const [cost, setCost] = useState('35');
  const [otherCost, setOtherCost] = useState('5');
  const [feePercent, setFeePercent] = useState('2.5');
  const [marginPercent, setMarginPercent] = useState('30');
  const [copyState, setCopyState] = useState<'idle' | 'copied' | 'blocked'>('idle');
  const BackIcon = dir === 'rtl' ? ArrowRight : ArrowLeft;

  const result = useMemo(() => {
    if ([cost, otherCost, feePercent, marginPercent].some((value) => value.trim() === '')) {
      return { error: t({ ar: 'أكمل جميع الخانات الرقمية قبل قراءة النتيجة.', en: 'Complete all numeric fields before using the result.' }) };
    }
    const productCost = Number(cost);
    const addedCost = Number(otherCost);
    const fee = Number(feePercent);
    const margin = Number(marginPercent);
    if (![productCost, addedCost, fee, margin].every(Number.isFinite) || productCost < 0 || addedCost < 0 || fee < 0 || margin < 0 || fee > 99 || margin > 99) {
      return { error: t({ ar: 'أدخل أرقامًا موجبة وصحيحة. النسب يجب أن تكون أقل من 100٪.', en: 'Enter valid non-negative numbers. Percentages must be under 100%.' }) };
    }
    const baseCost = productCost + addedCost;
    const denominator = 1 - (fee + margin) / 100;
    if (denominator <= 0) {
      return { error: t({ ar: 'مجموع الرسوم وهامش الربح يجب أن يكون أقل من 100٪.', en: 'Fees plus profit margin must total less than 100%.' }) };
    }
    const salePrice = baseCost / denominator;
    const feeAmount = salePrice * fee / 100;
    const profit = salePrice - baseCost - feeAmount;
    return { baseCost, salePrice, feeAmount, profit, margin };
  }, [cost, otherCost, feePercent, marginPercent, t]);

  const summary = result.error ? '' : [
    t({ ar: 'ملخص تسعير تقديري', en: 'Estimated pricing summary' }),
    `${t({ ar: 'التكلفة الكاملة', en: 'Total cost' })}: ${money(result.baseCost!, lang)}`,
    `${t({ ar: 'سعر البيع المقترح', en: 'Suggested selling price' })}: ${money(result.salePrice!, lang)}`,
    `${t({ ar: 'رسوم الدفع المقدرة', en: 'Estimated payment fee' })}: ${money(result.feeAmount!, lang)}`,
    `${t({ ar: 'الربح التقديري', en: 'Estimated profit' })}: ${money(result.profit!, lang)}`,
  ].join('\n');

  const copySummary = async () => {
    try {
      await navigator.clipboard.writeText(summary);
      setCopyState('copied');
    } catch {
      setCopyState('blocked');
    }
  };

  const inputClass = 'mt-2 h-12 w-full rounded-xl border border-input bg-background px-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary';

  return (
    <SiteShell>
      <main className="mx-auto max-w-6xl px-5 pb-20 pt-7 md:px-8 md:pt-12">
        <Link href="/#work" data-testid="link-pricing-back" className="inline-flex min-h-10 items-center gap-2 rounded-full px-3 text-sm font-semibold text-muted-foreground hover:text-foreground">
          <BackIcon className="h-4 w-4" aria-hidden="true" />{t({ ar: 'العودة إلى النماذج والأدوات', en: 'Back to demos and tools' })}
        </Link>

        <div className="mt-7 grid gap-8 lg:grid-cols-[.8fr_1.2fr] lg:items-start">
          <header className="rounded-[1.75rem] bg-[hsl(var(--ink))] p-6 text-[hsl(var(--wool))] sm:p-8">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[hsl(var(--saffron))] text-[hsl(var(--ink))]"><Calculator className="h-6 w-6" aria-hidden="true" /></span>
            <p className="mt-6 text-sm font-bold text-[hsl(var(--saffron))]">{t({ ar: 'أداة عملية لمتجرك', en: 'A practical tool for your shop' })}</p>
            <h1 className="mt-2 font-display text-3xl font-extrabold leading-tight sm:text-4xl">{t({ ar: 'اعرف تكلفة المنتج قبل أن تسعّره.', en: 'Know your costs before setting a price.' })}</h1>
            <p className="mt-4 leading-7 text-[hsl(var(--wool)/.76)]">{t({ ar: 'أدخل تكلفة الوحدة ورسوم الدفع وهامش الربح المطلوب. احصل على سعر يغطي التكاليف ويعرض الربح والرسوم بوضوح.', en: 'Enter unit costs, payment fees and your target margin. See a price that covers costs, with profit and fees shown clearly.' })}</p>
            <div className="mt-6 flex flex-wrap gap-2">
              {[t({ ar: 'حساب محلي', en: 'Local calculation' }), t({ ar: 'لا حفظ أو إرسال', en: 'No storage or upload' })].map((label) => <span key={label} className="rounded-full border border-white/15 px-3 py-1.5 text-xs">{label}</span>)}
            </div>
          </header>

          <section aria-labelledby="pricing-fields-title" className="rounded-[1.75rem] border border-card-border bg-card p-5 shadow-sm sm:p-7">
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary"><Wallet className="h-5 w-5" aria-hidden="true" /></span>
              <div>
                <h2 id="pricing-fields-title" className="font-display text-xl font-bold">{t({ ar: 'بيانات الوحدة الواحدة', en: 'Per-unit inputs' })}</h2>
                <p className="mt-1 text-xs text-muted-foreground">{t({ ar: 'الأرقام الظاهرة أمثلة أولية؛ غيّرها لتناسب منتجك.', en: 'The initial numbers are examples; change them to match your product.' })}</p>
              </div>
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <label className="text-sm font-semibold">{t({ ar: 'تكلفة المنتج (ر.س)', en: 'Product cost (SAR)' })}
                <input data-testid="input-pricing-cost" type="number" min="0" step="0.01" inputMode="decimal" value={cost} onChange={(event) => { setCost(event.target.value); setCopyState('idle'); }} className={inputClass} />
              </label>
              <label className="text-sm font-semibold">{t({ ar: 'تغليف أو تكاليف أخرى (ر.س)', en: 'Packaging or other costs (SAR)' })}
                <input data-testid="input-pricing-extra-cost" type="number" min="0" step="0.01" inputMode="decimal" value={otherCost} onChange={(event) => { setOtherCost(event.target.value); setCopyState('idle'); }} className={inputClass} />
              </label>
              <label className="text-sm font-semibold">{t({ ar: 'رسوم الدفع (%)', en: 'Payment fees (%)' })}
                <input data-testid="input-pricing-fee" type="number" min="0" max="99" step="0.1" inputMode="decimal" value={feePercent} onChange={(event) => { setFeePercent(event.target.value); setCopyState('idle'); }} className={inputClass} />
              </label>
              <label className="text-sm font-semibold">{t({ ar: 'هامش الربح المطلوب (%)', en: 'Target profit margin (%)' })}
                <input data-testid="input-pricing-margin" type="number" min="0" max="99" step="0.1" inputMode="decimal" value={marginPercent} onChange={(event) => { setMarginPercent(event.target.value); setCopyState('idle'); }} className={inputClass} />
              </label>
            </div>

            <div className="mt-6 rounded-2xl bg-muted/60 p-4 sm:p-5">
              {result.error ? (
                <p role="alert" data-testid="error-pricing-calculation" className="text-sm font-semibold text-destructive">{result.error}</p>
              ) : (
                <>
                  <div className="flex flex-wrap items-end justify-between gap-3">
                    <div>
                      <p className="text-sm text-muted-foreground">{t({ ar: 'سعر البيع المقترح', en: 'Suggested selling price' })}</p>
                      <p data-testid="result-pricing-sale-price" className="num mt-1 font-display text-3xl font-extrabold text-primary">{money(result.salePrice!, lang)}</p>
                    </div>
                    <button type="button" data-testid="button-copy-pricing-summary" onClick={() => void copySummary()} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border bg-background px-4 text-xs font-semibold hover:border-primary/50">
                      {copyState === 'copied' ? <Check className="h-4 w-4 text-primary" aria-hidden="true" /> : <Clipboard className="h-4 w-4" aria-hidden="true" />}
                      {copyState === 'copied' ? t({ ar: 'نُسخ الملخص', en: 'Summary copied' }) : t({ ar: 'انسخ الملخص', en: 'Copy summary' })}
                    </button>
                  </div>
                  <dl data-testid="results-pricing-breakdown" className="mt-5 grid gap-3 border-t border-border pt-4 sm:grid-cols-3">
                    <div><dt className="text-xs text-muted-foreground">{t({ ar: 'التكلفة الكاملة', en: 'Total cost' })}</dt><dd className="num mt-1 font-bold">{money(result.baseCost!, lang)}</dd></div>
                    <div><dt className="text-xs text-muted-foreground">{t({ ar: 'رسوم الدفع', en: 'Payment fees' })}</dt><dd className="num mt-1 font-bold">{money(result.feeAmount!, lang)}</dd></div>
                    <div><dt className="text-xs text-muted-foreground">{t({ ar: `الربح (${result.margin}٪ من السعر)`, en: `Profit (${result.margin}% of price)` })}</dt><dd data-testid="result-pricing-profit" className="num mt-1 font-bold">{money(result.profit!, lang)}</dd></div>
                  </dl>
                </>
              )}
            </div>
            {copyState === 'blocked' && <p role="status" className="mt-3 text-xs text-muted-foreground">{t({ ar: 'تعذّر النسخ تلقائيًا؛ يمكنك تحديد الملخص ونسخه يدويًا.', en: 'Clipboard access was blocked; you can select and copy the summary manually.' })}</p>}
            <button type="button" data-testid="button-reset-pricing" onClick={() => { setCost('35'); setOtherCost('5'); setFeePercent('2.5'); setMarginPercent('30'); setCopyState('idle'); }} className="mt-4 inline-flex min-h-10 items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground">
              <RotateCcw className="h-4 w-4" aria-hidden="true" />{t({ ar: 'إعادة الأرقام المثال', en: 'Reset sample numbers' })}
            </button>
            <p data-testid="notice-pricing-limits" className="mt-4 border-t border-border pt-4 text-xs leading-6 text-muted-foreground">
              {t({ ar: 'معادلة الأداة: سعر البيع = مجموع التكلفة ÷ (1 − نسبة الرسوم − هامش الربح). أدخل الضرائب والشحن ضمن التكاليف إن انطبقت. الحساب تقديري وليس استشارة محاسبية أو ضريبية، ولا يحفظ البيانات.', en: 'Formula: sale price = total costs ÷ (1 − fee rate − profit margin). Include taxes or shipping in costs when applicable. This is an estimate, not accounting or tax advice; inputs are not saved.' })}
            </p>
          </section>
        </div>
      </main>
    </SiteShell>
  );
}
