import { Fragment } from 'react';
import { Link } from 'wouter';
import { motion, useReducedMotion } from 'framer-motion';
import { CalendarDays, CircleDot, Coffee, Code2, GraduationCap, MessageCircle, FileText, Hammer, Rocket, Check, ArrowUpRight, ClipboardCheck, ScanText, Calculator, Copy, Share2 } from 'lucide-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { COMPETENCIES, COURSES, EXPERIENCE, PROJECTS, SERVICES, SKILLS } from '@/lib/content';
import { asset, SaduBand, ServiceIcon } from '@/components/brand';
import { Reveal, Page } from '@/components/motion';
import { Arrow, SiteShell } from '@/components/site-shell';

function HeroPhone() {
  const { t } = useLang();
  const reduce = useReducedMotion();
  const slots = ['09:00', '10:30', '12:00', '16:00', '17:30', '19:00'];
  return (
    <div className="relative mx-auto w-[260px] sm:w-[290px]">
      <div className="absolute -inset-10 -z-10 rounded-full bg-[hsl(var(--saffron)/0.35)] blur-3xl" />
      <motion.div
        initial={reduce ? false : { rotate: -8, y: 40, opacity: 0 }}
        animate={{ rotate: -4, y: 0, opacity: 1 }}
        transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        className="relative rounded-[2.6rem] bg-[hsl(var(--ink))] p-3 shadow-2xl"
      >
        <div className="overflow-hidden rounded-[2rem] bg-[hsl(var(--wool))]">
          <div className="flex items-center justify-between bg-primary px-5 pb-5 pt-6 text-primary-foreground">
            <div>
              <div className="text-[10px] opacity-80">{t({ ar: 'مثال: صالونك', en: 'Example: your salon' })}</div>
              <div className="font-display text-base font-bold">{t({ ar: 'احجزي موعدك', en: 'Book a visit' })}</div>
            </div>
            <div className="h-8 w-8 rounded-lg bg-[hsl(var(--wool)/0.2)]" />
          </div>
          <div className="sadu-band !h-2" />
          <div className="space-y-3 p-4">
            <div className="flex gap-1.5">
              {[t({ ar: 'سبت', en: 'Sat' }), t({ ar: 'أحد', en: 'Sun' }), t({ ar: 'إثنين', en: 'Mon' }), t({ ar: 'ثلاثاء', en: 'Tue' })].map((d, i) => (
                <div key={d} className={`flex-1 rounded-xl py-2 text-center text-[10px] font-semibold ${i === 1 ? 'bg-[hsl(var(--ink))] text-[hsl(var(--wool))]' : 'bg-muted'}`}>
                  {d}
                  <div className="num mt-0.5 text-sm">{12 + i}</div>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {slots.map((s, i) => (
                <motion.div
                  key={s}
                  animate={reduce ? undefined : i === 3 ? { scale: [1, 0.94, 1] } : undefined}
                  transition={{ repeat: Infinity, duration: 3.2, delay: 1.6, repeatDelay: 1.8 }}
                  className={`num rounded-lg border py-2 text-center text-[11px] ${i === 3 ? 'border-primary bg-primary text-primary-foreground' : i === 1 ? 'border-border text-muted-foreground line-through opacity-60' : 'border-border'}`}
                >
                  {s}
                </motion.div>
              ))}
            </div>
            <div className="rounded-xl bg-muted p-3">
              <div className="h-2 w-2/3 rounded bg-foreground/15" />
              <div className="mt-2 h-2 w-1/2 rounded bg-foreground/10" />
            </div>
            <div className="rounded-xl bg-[hsl(var(--ink))] py-3 text-center text-xs font-semibold text-[hsl(var(--wool))]">
              {t({ ar: 'تأكيد الحجز', en: 'Confirm booking' })}
            </div>
          </div>
        </div>
      </motion.div>
      <motion.div
        initial={reduce ? false : { opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.1, duration: 0.6 }}
        className="absolute -start-10 bottom-16 rounded-2xl border border-border bg-card px-4 py-3 shadow-lg sm:-start-16"
      >
        <div className="flex items-center gap-2 text-xs font-semibold">
          <span className="grid h-6 w-6 place-items-center rounded-full bg-[hsl(168_40%_34%)] text-[hsl(var(--wool))]"><Check className="h-3.5 w-3.5" /></span>
          {t({ ar: 'تم الحجز', en: 'Booked' })}
        </div>
        <div className="num mt-1 text-[10px] text-muted-foreground">PHP · MySQL</div>
      </motion.div>
      <motion.div
        initial={reduce ? false : { opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.3, duration: 0.6 }}
        className="absolute -end-6 top-10 rotate-6 rounded-2xl bg-accent px-3 py-2 text-[11px] font-bold text-accent-foreground shadow-lg sm:-end-12"
      >
        {t({ ar: 'يعمل على كل جهاز', en: 'Works on every device' })}
      </motion.div>
    </div>
  );
}

function Hero() {
  const { t, lang } = useLang();
  const reduce = useReducedMotion();
  const words = lang === 'ar'
    ? ['أصمّم وأطوّر', 'مواقع وتطبيقات', 'لمشروعك،', 'من الفكرة', 'إلى الإطلاق.']
    : ['I design and build', 'websites and apps', 'for your project,', 'from idea', 'to launch.'];
  return (
    <section className="relative overflow-hidden">
      <div className="sadu-dots absolute inset-0 -z-10 opacity-60 [mask-image:linear-gradient(to_bottom,black,transparent_80%)]" />
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 pb-20 pt-8 md:px-8 lg:grid-cols-[1.25fr_1fr] lg:pb-28 lg:pt-14">
        <div>
          <motion.div
            initial={reduce ? false : { opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-semibold"
          >
            <span className="relative grid h-2 w-2 place-items-center rounded-full bg-[hsl(168_40%_38%)] text-[hsl(168_40%_38%)] pulse-ring" />
            {t({ ar: 'متاح لمشاريع جديدة', en: 'Available for new projects' })}
            <span className="text-muted-foreground">· {t({ ar: 'السعودية', en: 'Saudi Arabia' })}</span>
          </motion.div>
          <h1 dir={lang === 'ar' ? 'rtl' : 'ltr'} className="mt-6 font-display text-[2.6rem] font-extrabold leading-[1.3] sm:text-6xl lg:text-[4.6rem]">
            {words.map((w, i) => (
              <Fragment key={`${w}-${i}`}>
                <motion.span
                  initial={reduce ? false : { opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + i * 0.08, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
                  className={`inline-block ${i === 4 ? 'text-primary' : ''}`}
                >
                  {w}
                </motion.span>
                {i < words.length - 1 ? ' ' : null}
              </Fragment>
            ))}
          </h1>
          <motion.p
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-6 max-w-xl text-lg leading-8 text-muted-foreground"
          >
            {t({
              ar: 'أنا مروان الزهراني، مطوّر مواقع وتطبيقات. أساعد المحلات والأسر المنتجة والجمعيات على بناء مواقع تعريفية وأنظمة حجز وتطبيقات جوال، وأتابع كل مشروع بنفسي من استلام الطلب حتى الإطلاق.',
              en: 'I’m Marwan Alzahrani, a web & mobile developer. I design and build business websites, booking systems and mobile apps for shops, home businesses and charities — and handle each project myself from request to launch.',
            })}
          </motion.p>
          <motion.div
            initial={reduce ? false : { opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.75 }}
            className="mt-9 flex flex-col gap-3 sm:flex-row"
          >
            <Link href="/request" data-testid="link-hero-request" className="group inline-flex h-14 items-center justify-center gap-2 rounded-full bg-primary px-8 text-base font-semibold text-primary-foreground shadow-lg transition-transform hover:-translate-y-0.5">
              {t({ ar: 'ابدأ مشروعك', en: 'Start your project' })}
              <Arrow className="h-5 w-5 transition-transform group-hover:-translate-y-0.5" />
            </Link>
            <Link href="/learning-lab" data-testid="link-hero-learning-lab" className="group inline-flex h-14 items-center justify-center gap-2 rounded-full border border-border bg-card/80 px-6 text-sm font-semibold transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:text-primary">
              <GraduationCap className="h-5 w-5 text-primary" />
              {t({ ar: 'مختبر التعلّم', en: 'Learning lab' })}
              <Arrow className="h-4 w-4 transition-transform group-hover:-translate-y-0.5" />
            </Link>
          </motion.div>
          <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm">
            <div className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-primary" />
              <span>{t({ ar: 'خريج الكلية التقنية لعام 2025', en: 'Technical College graduate, 2025' })}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="num rounded-md bg-[hsl(var(--ink))] px-2 py-0.5 text-xs font-semibold text-[hsl(var(--saffron))]">4.35 / 5</span>
              <span>{t({ ar: 'المعدل التراكمي', en: 'GPA' })}</span>
            </div>
          </div>
        </div>
        <HeroPhone />
      </div>
    </section>
  );
}

function Marquee() {
  const items = ['HTML5', 'CSS3', 'JavaScript', 'PHP', 'MySQL', 'Java', 'MIT App Inventor', 'UI/UX', 'Git', 'Responsive', 'FTP', 'XAMPP'];
  const row = [...items, ...items];
  return (
    <div className="overflow-hidden border-y border-[hsl(var(--ink))] bg-[hsl(var(--ink))] py-4 text-[hsl(var(--wool))]" dir="ltr">
      <div className="marquee-track flex w-max gap-10 whitespace-nowrap">
        {row.map((s, i) => (
          <span key={i} className="flex items-center gap-10 font-display text-xl font-semibold">
            {s}
            <span className="h-2.5 w-2.5 rotate-45 bg-primary" />
          </span>
        ))}
      </div>
    </div>
  );
}

function SectionHead({ kicker, title, body, id }: { kicker: string; title: string; body?: string; id?: string }) {
  return (
    <Reveal className="max-w-2xl" >
      <div id={id} className="scroll-mt-24" />
      <div className="flex items-center gap-3 text-sm font-semibold text-primary">
        <span className="h-2.5 w-2.5 rotate-45 bg-primary" />
        {kicker}
      </div>
      <h2 className="mt-4 font-display text-3xl font-bold leading-tight sm:text-5xl">{title}</h2>
      {body && <p className="mt-4 text-lg leading-8 text-muted-foreground">{body}</p>}
    </Reveal>
  );
}

function Services() {
  const { t } = useLang();
  return (
    <section className="mx-auto max-w-7xl px-5 py-24 md:px-8">
      <SectionHead
        id="services"
        kicker={t({ ar: 'خدمات أقدّمها', en: 'Services I offer' })}
        title={t({ ar: 'خمس خدمات تبدأ بفهم احتياجات مشروعك.', en: 'Five services, each starting with an understanding of your needs.' })}
        body={t({ ar: 'تختلف التكلفة بحسب حجم المشروع. اختر الخدمة وأرسل طلبك للحصول على عرض سعر، وسأرد عليك بنفسي.', en: 'Pricing depends on the scope of each project. Choose a service and send a request for a quote; I’ll reply personally.' })}
      />
      <div className="mt-14 grid gap-5 md:grid-cols-6">
        {SERVICES.map((s, i) => (
          <Reveal key={s.slug} delay={i * 0.06} className={i < 2 ? 'md:col-span-3' : 'md:col-span-2'}>
            <Link href={`/services/${s.slug}`} data-testid={`card-service-${s.slug}`} className="group relative flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-card-border bg-card transition-all duration-500 hover:-translate-y-1 hover:shadow-xl">
              <div className={`relative overflow-hidden ${i < 2 ? 'aspect-[16/9]' : 'aspect-[4/3]'}`}>
                <img src={asset(s.image)} alt={t(s.imageAlt)} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--ink)/0.55)] to-transparent" />
                <span className="num absolute start-4 top-4 rounded-full bg-[hsl(var(--wool)/0.9)] px-2.5 py-1 text-xs font-semibold">0{i + 1}</span>
              </div>
              <div className="flex flex-1 flex-col p-6">
                <div className="-mt-14 mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-[hsl(var(--ink))] text-[hsl(var(--wool))] shadow-lg ring-4 ring-card transition-transform duration-500 group-hover:-rotate-6">
                  <ServiceIcon type={s.type} className="h-9 w-9" />
                </div>
                <h3 className="font-display text-xl font-bold">{t(s.name)}</h3>
                <p className="mt-2 flex-1 text-sm leading-7 text-muted-foreground">{t(s.short)}</p>
                <div className="mt-5 flex items-center justify-between text-sm font-semibold">
                  <span className="text-primary">{t({ ar: 'اطلب عرض سعر', en: 'Request a quote' })}</span>
                  <span className="grid h-9 w-9 place-items-center rounded-full border border-border transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                    <Arrow className="h-4 w-4" />
                  </span>
                </div>
              </div>
            </Link>
          </Reveal>
        ))}
        <Reveal delay={0.3} className="md:col-span-6">
          <Link href="/community" data-testid="card-community-teaser" className="group relative flex flex-col items-start gap-6 overflow-hidden rounded-[1.75rem] bg-primary p-8 text-primary-foreground sm:flex-row sm:items-center md:p-10">
            <div className="sadu-diamonds absolute inset-0 opacity-60" />
            <div className="relative grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-[hsl(var(--wool))] text-[hsl(var(--ink))]">
              <ServiceIcon type="community_package" className="h-9 w-9" />
            </div>
            <div className="relative flex-1">
              <h3 className="font-display text-2xl font-bold">{t({ ar: 'باقة المجتمع — بأسعار مخفّضة', en: 'Community package — reduced pricing' })}</h3>
              <p className="mt-2 max-w-2xl text-primary-foreground/85">{t({ ar: 'للأسر المنتجة والجمعيات الخيرية: مواقع أو أنظمة بأسعار مخفّضة للمشاريع التي تخدم المجتمع.', en: 'Reduced pricing on websites and systems for productive families and charities serving their communities.' })}</p>
            </div>
            <span className="relative inline-flex h-12 items-center gap-2 rounded-full bg-[hsl(var(--wool))] px-6 font-semibold text-[hsl(var(--ink))] transition-transform group-hover:-translate-y-0.5">
              {t({ ar: 'اعرف أكثر', en: 'Learn more' })}
              <Arrow className="h-4 w-4" />
            </span>
          </Link>
        </Reveal>
      </div>
    </section>
  );
}

function Strengths() {
  const { t } = useLang();
  return (
    <section className="relative bg-[hsl(var(--ink))] py-24 text-[hsl(var(--wool))]">
      <div className="sadu-diamonds absolute inset-0" />
      <div className="relative mx-auto max-w-7xl px-5 md:px-8">
        <Reveal className="max-w-3xl">
          <div className="flex items-center gap-3 text-sm font-semibold text-[hsl(var(--saffron))]">
            <span className="h-2.5 w-2.5 rotate-45 bg-[hsl(var(--saffron))]" />
            {t({ ar: 'لماذا مروان؟', en: 'Why Marwan?' })}
          </div>
          <h2 className="mt-4 font-display text-3xl font-bold leading-tight sm:text-5xl">
            {t({ ar: 'خبرة عملية في المستودعات والمبيعات أقدّمها لمشروعك.', en: 'Practical experience in warehousing and sales, brought to your project.' })}
          </h2>
          <p className="mt-5 text-lg leading-8 text-[hsl(var(--wool)/0.72)]">
            {t({
              ar: 'قبل عملي في البرمجة، عملت في أمازون وبيبسيكو. تعلّمت هناك أهمية الدقة، وفهم احتياجات أصحاب المشاريع، والالتزام بالمواعيد. أطبّق هذه القيم في كل مشروع أعمل عليه.',
              en: 'Before code, I worked at Amazon and PepsiCo. I learned that precision doesn’t allow mistakes, and that business owners want someone who understands their goal and keeps deadlines. That’s what I bring to your project.',
            })}
          </p>
        </Reveal>
        <div className="mt-14 grid gap-5 lg:grid-cols-2">
          {EXPERIENCE.map((e, i) => (
            <Reveal key={e.year} delay={i * 0.1}>
              <div className="h-full rounded-[1.75rem] border border-[hsl(var(--wool)/0.12)] bg-[hsl(var(--wool)/0.04)] p-7 md:p-9">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="font-display text-2xl font-bold text-[hsl(var(--saffron))]">{t(e.lesson)}</div>
                    <div className="mt-2 text-sm text-[hsl(var(--wool)/0.7)]">
                      {t(e.role)} · {t(e.org)}
                    </div>
                  </div>
                  <span className="num rounded-full border border-[hsl(var(--wool)/0.2)] px-3 py-1 text-sm">{e.year}</span>
                </div>
                <ul className="mt-6 space-y-3">
                  {e.points.map((p, j) => (
                    <li key={j} className="flex gap-3 text-[0.95rem] leading-7 text-[hsl(var(--wool)/0.85)]">
                      <span className="mt-2.5 h-1.5 w-1.5 shrink-0 rotate-45 bg-primary" />
                      {t(p)}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Work() {
  const { t } = useLang();
  const icons = {
    tasbeeh: CircleDot,
    booking: CalendarDays,
    cafe: Coffee,
    learning: Code2,
    quality: ScanText,
    toolbox: ClipboardCheck,
    pricing: Calculator,
    copy: Copy,
    share: Share2,
  };
  const demos = PROJECTS.filter((project) =>
    ['booking', 'cafe', 'learning'].includes(project.icon),
  );
  const tools = PROJECTS.filter((project) => !demos.includes(project));
  const renderCards = (items: typeof PROJECTS) => (
    <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
      {items.map((p, i) => {
        const Icon = icons[p.icon];
        return (
          <Reveal key={p.href} delay={i * 0.06}>
            <Link href={p.href} data-testid={`link-project-${p.icon}`} className="group block h-full overflow-hidden rounded-[1.75rem] border border-card-border bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
              <div className="relative overflow-hidden">
                <img src={asset(p.image)} alt={t(p.imageAlt)} loading="lazy" className="aspect-[16/10] w-full object-cover transition-transform duration-500 group-hover:scale-[1.025]" />
                <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--ink)/0.5)] via-transparent to-transparent" />
                <span className="absolute start-4 top-4 grid h-11 w-11 place-items-center rounded-2xl bg-card/95 text-foreground shadow-sm" aria-hidden="true">
                  <Icon className="h-5 w-5" />
                </span>
                <span className="absolute bottom-4 end-4 rounded-full border border-white/50 bg-[hsl(var(--ink)/0.7)] px-3 py-1 text-xs font-semibold text-white">{t(p.type)}</span>
              </div>
              <div className="p-6">
                <h3 className="font-display text-xl font-bold transition-colors group-hover:text-primary">{t(p.name)}</h3>
                <p className="mt-2 min-h-[4.5rem] leading-7 text-muted-foreground">{t(p.body)}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.stack.map((s) => (
                    <span key={s} className="num rounded-full border border-border bg-background px-3 py-1 text-xs">{s}</span>
                  ))}
                </div>
                <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary">
                  {t({ ar: 'افتح الرابط وجربه', en: 'Open and try it' })}
                  <ArrowUpRight className="h-4 w-4" />
                </span>
              </div>
            </Link>
          </Reveal>
        );
      })}
    </div>
  );
  return (
    <section id="work" className="mx-auto max-w-7xl px-5 py-24 md:px-8">
      <SectionHead
        kicker={t({ ar: 'عمل حقيقي ونماذج تعمل', en: 'Real work and working demos' })}
        title={t({ ar: 'شاهد العمل، وافتحه بنفسك.', en: 'See the work. Open it yourself.' })}
        body={t({ ar: 'أعرض هنا الموقع الذي بنيته ونظام الطلبات المرتبط به، ثم نماذج وأدوات شخصية بروابط وصور فعلية. أوضح نوع كل عمل حتى لا أخلط بين مشروع عميل ونموذج تعليمي.', en: 'Here you can see the site I built and its connected request system, followed by personal demos and tools with real screenshots and links. Each item is labeled so client work is never confused with a learning demo.' })}
      />
      <article data-testid="card-real-project-site" className="mt-10 overflow-hidden rounded-[1.9rem] border border-card-border bg-card shadow-sm">
        <div className="grid lg:grid-cols-[0.9fr_1.1fr]">
          <div className="flex flex-col justify-center bg-[hsl(var(--ink))] p-6 text-[hsl(var(--wool))] sm:p-9 lg:p-10">
            <span className="inline-flex w-fit items-center gap-2 rounded-full border border-[hsl(var(--saffron)/0.45)] bg-[hsl(var(--saffron)/0.1)] px-3 py-1.5 text-xs font-bold text-[hsl(var(--saffron))]">
              <Check className="h-4 w-4" aria-hidden="true" />
              {t({ ar: 'مشروع شخصي فعلي — من تنفيذ مروان', en: 'Real personal project — built by Marwan' })}
            </span>
            <h3 className="mt-5 font-display text-2xl font-extrabold leading-tight sm:text-3xl">
              {t({ ar: 'هذا الموقع، ونظام استقبال الطلبات وراءه.', en: 'This website, and the request system behind it.' })}
            </h3>
            <p className="mt-3 leading-7 text-[hsl(var(--wool)/0.78)]">
              {t({ ar: 'ليس صورة واجهة فقط: نموذج المشروع يرسل إلى خدمة API، ويحفظ الطلب ويرجع للعميل رقمًا مرجعيًا ورابط محادثة خاصة للمتابعة. لا أرسل طلبات اختبار حتى لا أضيف بيانات أو إشعارات وهمية.', en: 'This is more than a static mock-up: the project form sends to an API, saves the request, and returns a reference number and private conversation link for follow-up. I do not submit test requests that would create fake records or notifications.' })}
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {['React', 'TypeScript', 'REST API', 'Database'].map((item) => (
                <span key={item} className="rounded-full border border-[hsl(var(--wool)/0.2)] px-3 py-1.5 text-xs">{item}</span>
              ))}
            </div>
            <Link href="/request" data-testid="link-real-project-request" className="group mt-7 inline-flex min-h-12 w-fit items-center gap-2 rounded-full bg-primary px-5 text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-0.5">
              {t({ ar: 'افتح نموذج الطلب الحقيقي', en: 'Open the real project request form' })}
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </Link>
            <p className="mt-3 max-w-lg text-xs leading-5 text-[hsl(var(--wool)/0.62)]">
              {t({ ar: 'تنبيه: إرسال النموذج ينشئ طلبًا حقيقيًا في النظام؛ استخدمه لطلب مشروع فعلي، لا للتجربة.', en: 'Note: submitting the form creates a real request in the system. Use it for a genuine project enquiry, not as a demo.' })}
            </p>
          </div>
          <div className="grid gap-3 bg-muted/50 p-4 sm:grid-cols-2 sm:p-5">
            <Link href="/" data-testid="link-real-project-home-preview" className="group overflow-hidden rounded-2xl border border-card-border bg-card">
              <div className="relative overflow-hidden">
                <img src={asset('images/preview-portfolio-site.jpg')} alt={t({ ar: 'لقطة شاشة حقيقية من الصفحة الرئيسية لموقع مروان', en: 'Actual screenshot of Marwan’s homepage' })} loading="lazy" className="aspect-[16/10] w-full object-cover object-top transition-transform duration-500 group-hover:scale-[1.025]" />
                <span className="absolute start-3 top-3 rounded-full bg-card/95 px-3 py-1 text-xs font-semibold">{t({ ar: 'الموقع نفسه', en: 'The actual website' })}</span>
              </div>
              <span className="flex items-center justify-between gap-2 p-3 text-sm font-semibold">
                {t({ ar: 'الصفحة الرئيسية', en: 'Homepage' })}
                <ArrowUpRight className="h-4 w-4 text-primary" aria-hidden="true" />
              </span>
            </Link>
            <Link href="/request" data-testid="link-real-project-request-preview" className="group overflow-hidden rounded-2xl border border-card-border bg-card">
              <div className="relative overflow-hidden">
                <img src={asset('images/preview-real-request-flow.jpg')} alt={t({ ar: 'لقطة شاشة حقيقية من نموذج استقبال طلب مشروع', en: 'Actual screenshot of the project request form' })} loading="lazy" className="aspect-[16/10] w-full object-cover object-top transition-transform duration-500 group-hover:scale-[1.025]" />
                <span className="absolute start-3 top-3 rounded-full bg-card/95 px-3 py-1 text-xs font-semibold">{t({ ar: 'نموذج متصل بالخادم', en: 'Connected request form' })}</span>
              </div>
              <span className="flex items-center justify-between gap-2 p-3 text-sm font-semibold">
                {t({ ar: 'استقبال ومتابعة الطلبات', en: 'Request intake and follow-up' })}
                <ArrowUpRight className="h-4 w-4 text-primary" aria-hidden="true" />
              </span>
            </Link>
          </div>
        </div>
      </article>
      <div id="interactive-tools" className="mb-5 mt-16 scroll-mt-24">
        <h3 className="font-display text-2xl font-extrabold sm:text-3xl">{t({ ar: 'أدوات للاستخدام المباشر', en: 'Tools you can use now' })}</h3>
        <p className="mt-2 max-w-3xl leading-7 text-muted-foreground">{t({ ar: 'أدوات عملية بروابط مباشرة، مع وصف مختصر لطريقة عمل كل أداة.', en: 'Practical tools with direct links and a clear summary of how each one works.' })}</p>
      </div>
      {renderCards(tools)}
      <div id="interactive-demos" className="mb-5 mt-14 scroll-mt-24 border-t border-border pt-10">
        <h3 className="font-display text-2xl font-extrabold sm:text-3xl">{t({ ar: 'نماذج تفاعلية للتجربة', en: 'Interactive demos to explore' })}</h3>
        <p className="mt-2 max-w-3xl leading-7 text-muted-foreground">{t({ ar: 'نماذج تعليمية ببيانات محلية؛ لا تنشئ حجوزات أو طلبات حقيقية.', en: 'Educational demos with local sample data; they do not create real bookings or orders.' })}</p>
      </div>
      {renderCards(demos)}
    </section>
  );
}

function Process() {
  const { t } = useLang();
  const steps = [
    { icon: MessageCircle, title: { ar: 'تحديد الاحتياجات', en: 'Understand your needs' }, body: { ar: 'أرسل فكرتك عبر الموقع. سأتابع معك من خلال صفحة محادثة خاصة، وأسألك عن التفاصيل اللازمة.', en: 'Send your idea through the site. I’ll follow up in a private conversation and ask for the details I need.' } },
    { icon: FileText, title: { ar: 'عرض سعر واضح', en: 'A clear quote' }, body: { ar: 'أرسل لك تفاصيل العمل والتكلفة والمدة بوضوح.', en: 'I’ll outline the scope, cost and timeline clearly.' } },
    { icon: Hammer, title: { ar: 'التصميم والتطوير', en: 'Design and development' }, body: { ar: 'أطوّر المشروع وأشاركك التقدم أولًا بأول لتراجع العمل قبل اكتماله.', en: 'I’ll share progress as I build so you can review the work before it’s complete.' } },
    { icon: Rocket, title: { ar: 'الإطلاق والمتابعة', en: 'Launch and follow-up' }, body: { ar: 'أنشر المشروع على الاستضافة، وأتابع معك بعد الإطلاق لإجراء التعديلات المتفق عليها.', en: 'I’ll publish the project and follow up on any agreed changes after launch.' } },
  ];
  return (
    <section className="bg-muted/60 py-24">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHead kicker={t({ ar: 'آلية العمل', en: 'How we work' })} title={t({ ar: 'أربع خطوات، وتبقى على اطّلاع في كل مرحلة.', en: 'Four steps, with you involved at every stage.' })} />
        <ol className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <Reveal key={i} delay={i * 0.08}>
              <li className="relative h-full rounded-[1.5rem] border border-card-border bg-card p-6">
                <div className="flex items-center justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary"><s.icon className="h-6 w-6" /></span>
                  <span className="num font-display text-4xl font-bold text-foreground/10">{i + 1}</span>
                </div>
                <h3 className="mt-6 font-display text-lg font-bold">{t(s.title)}</h3>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{t(s.body)}</p>
              </li>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}

function About() {
  const { t } = useLang();
  return (
    <section className="mx-auto max-w-7xl px-5 py-24 md:px-8">
      <SectionHead
        id="about"
        kicker={t({ ar: 'عنّي', en: 'About me' })}
        title={t({ ar: 'مروان الزهراني — مطوّر مواقع وتطبيقات.', en: 'Marwan Alzahrani — web and app developer.' })}
        body={t({
          ar: 'مطوّر مواقع وتطبيقات، حاصل على دبلوم البرمجة وتطوير الويب من الكلية التقنية بمعدل 4.35 من 5. لدي خبرة عملية في بناء مواقع متجاوبة وتطبيقات للجوال وأنظمة قواعد بيانات. أستمتع بتحليل المشكلات التقنية وبناء حلول عملية لها، وأتعلّم حاليًا React.js وLaravel وواجهات REST API.',
          en: 'Web & app developer with a Diploma in Programming & Web Development from the Technical College (GPA 4.35/5). Hands-on experience building responsive websites, mobile apps and database systems. I love analysing a technical problem and building a practical solution; currently expanding into React.js, Laravel and REST APIs.',
        })}
      />
      <div className="mt-14 grid gap-5 lg:grid-cols-[1.3fr_1fr]">
        <Reveal>
          <div className="h-full rounded-[1.75rem] border border-card-border bg-card p-7 md:p-9">
            <h3 className="font-display text-xl font-bold">{t({ ar: 'المهارات', en: 'Skills' })}</h3>
            <div className="mt-6 space-y-5">
              {SKILLS.map((g) => (
                <div key={g.group.en} className="grid gap-2 sm:grid-cols-[170px_1fr] sm:items-center">
                  <div className={`text-sm font-semibold ${g.learning ? 'text-primary' : 'text-muted-foreground'}`}>{t(g.group)}</div>
                  <div className="flex flex-wrap gap-2">
                    {g.items.map((s) => (
                      <span key={s} className={`num rounded-lg px-3 py-1.5 text-xs font-medium ${g.learning ? 'border border-dashed border-primary/60 text-primary' : 'bg-[hsl(var(--ink))] text-[hsl(var(--wool))]'}`}>
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-6 text-xs text-muted-foreground">{t({ ar: 'الإطار المتقطع يشير إلى تقنية أتعلمها حاليًا.', en: 'A dashed outline marks a technology I’m currently learning.' })}</p>
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="relative h-full overflow-hidden rounded-[1.75rem] bg-accent p-7 text-accent-foreground md:p-9">
            <GraduationCap className="h-10 w-10" />
            <div className="num mt-6 text-sm font-semibold">2025</div>
            <h3 className="mt-1 font-display text-2xl font-bold">{t({ ar: 'دبلوم البرمجة وتطوير الويب', en: 'Diploma in Programming & Web Development' })}</h3>
            <p className="mt-1">{t({ ar: 'الكلية التقنية', en: 'Technical College' })}</p>
            <div className="mt-8 flex items-end gap-2">
              <span className="num font-display text-7xl font-extrabold leading-none">4.35</span>
              <span className="num pb-2 text-xl font-semibold">/ 5</span>
            </div>
            <div className="mt-1 text-sm font-semibold">{t({ ar: 'المعدل التراكمي', en: 'Cumulative GPA' })}</div>
          </div>
        </Reveal>
      </div>
      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Reveal>
          <div className="h-full rounded-[1.75rem] border border-card-border bg-card p-7 md:p-9">
            <h3 className="font-display text-xl font-bold">{t({ ar: 'الدورات والشهادات', en: 'Courses & certificates' })}</h3>
            <ul className="mt-6 space-y-3">
              {COURSES.map((c, i) => (
                <li key={i} className="flex items-start gap-3 text-sm leading-6">
                  <span className="num mt-0.5 text-xs text-primary">0{i + 1}</span>
                  {t(c)}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="h-full rounded-[1.75rem] border border-card-border bg-card p-7 md:p-9">
            <h3 className="font-display text-xl font-bold">{t({ ar: 'الكفاءات', en: 'Core competencies' })}</h3>
            <div className="mt-6 flex flex-wrap gap-2.5">
              {COMPETENCIES.map((c, i) => (
                <span key={i} className="rounded-full border border-border px-4 py-2 text-sm">{t(c)}</span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function FinalCta() {
  const { t } = useLang();
  return (
    <section className="mx-auto max-w-7xl px-5 pt-24 md:px-8">
      <Reveal>
        <div className="relative overflow-hidden rounded-[2rem] bg-primary text-primary-foreground">
          <SaduBand className="opacity-90" />
          <div className="grid gap-10 p-8 md:grid-cols-[1.4fr_1fr] md:p-14">
            <div>
              <h2 className="font-display text-3xl font-bold leading-tight sm:text-5xl">{t({ ar: 'هل لديك مشروع؟ دعني أساعدك في تنفيذه.', en: 'Have a project? Let me help bring it to life.' })}</h2>
              <p className="mt-5 max-w-lg text-lg leading-8 text-primary-foreground/85">{t({ ar: 'أرسل طلبك خلال دقيقتين. سأقرأه وأرد عليك بنفسي عبر صفحة محادثتك الخاصة على الموقع.', en: 'Send your request in about two minutes. I’ll read it and reply personally through your private conversation page.' })}</p>
            </div>
            <div className="flex flex-col gap-3 self-end">
              <Link href="/request" data-testid="link-cta-request" className="flex h-14 items-center justify-between rounded-full bg-[hsl(var(--wool))] px-6 font-semibold text-[hsl(var(--ink))] transition-transform hover:-translate-y-0.5">
                {t({ ar: 'أرسل طلب مشروعك', en: 'Send your project request' })}
                <Arrow className="h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

export default function Home() {
  useDocTitle({ ar: 'مروان الزهراني — مطوّر مواقع وتطبيقات', en: 'Marwan Alzahrani — Web & Mobile Developer' });
  return (
    <SiteShell>
      <Page>
        <Hero />
        <Marquee />
        <Services />
        <Strengths />
        <Work />
        <Process />
        <About />
        <FinalCta />
      </Page>
    </SiteShell>
  );
}
