import { useMemo, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, Check, CircleHelp, ClipboardCheck, Contrast,
  ExternalLink, Eye, FileText, Info, LockKeyhole, RotateCcw, ScanText,
  ShieldCheck, Sparkles, Type,
} from 'lucide-react';
import { Link } from 'wouter';
import { useDocTitle, useLang } from '@/lib/i18n';
import { SiteShell } from '@/components/site-shell';

type Bilingual = { ar: string; en: string };
const tx = (ar: string, en: string): Bilingual => ({ ar, en });

const INVISIBLE_RE = /[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/gu;
const PUNCTUATION_RE = /[،؛؟,.!:;]/u;

function countMatches(value: string, expression: RegExp) {
  return [...value.matchAll(new RegExp(expression.source, expression.flags))].length;
}

function cleanWhitespace(value: string) {
  return value
    .replace(/[ \t]{2,}/gu, ' ')
    .replace(/[ \t]+([،؛؟,.!:;])/gu, '$1')
    .replace(/([،؛؟,.!:;])(?=[\p{L}])/gu, '$1 ')
    .replace(/[ \t]+$/gmu, '');
}

function parseHex(value: string): [number, number, number] | null {
  if (!/^#[\da-f]{6}$/iu.test(value)) return null;
  return [
    Number.parseInt(value.slice(1, 3), 16),
    Number.parseInt(value.slice(3, 5), 16),
    Number.parseInt(value.slice(5, 7), 16),
  ];
}

function relativeLuminance(color: [number, number, number]) {
  const linear = color.map((channel) => {
    const value = channel / 255;
    return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2];
}

function contrastRatio(foreground: string, background: string) {
  const fg = parseHex(foreground);
  const bg = parseHex(background);
  if (!fg || !bg) return null;
  const [lighter, darker] = [relativeLuminance(fg), relativeLuminance(bg)].sort((a, b) => b - a);
  return (lighter + 0.05) / (darker + 0.05);
}

function LabIllustration() {
  return (
    <svg viewBox="0 0 520 330" role="img" aria-labelledby="lab-art-title" className="h-full w-full">
      <title id="lab-art-title">Arabic copy and color contrast being carefully reviewed</title>
      <defs>
        <pattern id="lab-grid" width="22" height="22" patternUnits="userSpaceOnUse">
          <path d="M22 0H0V22" fill="none" stroke="#f6f0e3" strokeOpacity=".12" />
        </pattern>
      </defs>
      <rect width="520" height="330" fill="url(#lab-grid)" />
      <circle cx="384" cy="153" r="108" fill="none" stroke="#e7af3f" strokeWidth="1.5" strokeDasharray="3 8" />
      <g transform="translate(267 54) rotate(5 94 108)">
        <rect width="184" height="216" rx="16" fill="#f6f0e3" />
        <rect x="18" y="18" width="148" height="76" rx="10" fill="#28305e" />
        <text x="92" y="51" textAnchor="middle" fill="#f6f0e3" fontSize="18" fontFamily="sans-serif">نصّ واضح</text>
        <text x="92" y="76" textAnchor="middle" fill="#e7af3f" fontSize="10" fontFamily="monospace">Aa / ض</text>
        <path d="M22 117h122M22 137h90M22 157h112" stroke="#28305e" strokeOpacity=".26" strokeWidth="5" strokeLinecap="round" />
        <rect x="21" y="177" width="64" height="20" rx="10" fill="#d8664f" />
        <rect x="92" y="177" width="64" height="20" rx="10" fill="#3a9b83" />
      </g>
      <g transform="translate(58 86) rotate(-8 95 65)">
        <rect width="190" height="132" rx="18" fill="#d8664f" />
        <circle cx="95" cy="66" r="39" fill="none" stroke="#f6f0e3" strokeWidth="2" />
        <path d="M95 27a39 39 0 0 1 0 78" fill="#f6f0e3" />
        <path d="M95 27a39 39 0 0 0 0 78" fill="#28305e" />
        <path d="m81 65 10 10 20-22" fill="none" stroke="#e7af3f" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        <text x="95" y="119" textAnchor="middle" fill="#f6f0e3" fontSize="9" fontFamily="monospace" letterSpacing="2">CHECK / ADJUST</text>
      </g>
      <path d="M67 277h132m-66-20v20m-24 0 24 22 24-22" fill="none" stroke="#e7af3f" strokeWidth="2.5" />
      <text x="381" y="291" textAnchor="middle" fill="#f6f0e3" fontFamily="monospace" fontSize="11" letterSpacing="1">NOTICE / MEASURE / DECIDE</text>
    </svg>
  );
}

function ResultBadge({ passed, label }: { passed: boolean; label: string }) {
  const { t } = useLang();
  return (
    <span data-testid={`status-contrast-${label.toLowerCase().replace(/\s+/gu, '-')}`} className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold ${passed ? 'bg-[#d9eee6] text-[#175e4f]' : 'bg-[#f5dfd8] text-[#8e3529]'}`}>
      {passed ? <Check className="h-3.5 w-3.5" aria-hidden="true" /> : <CircleHelp className="h-3.5 w-3.5" aria-hidden="true" />}
      {t(passed ? tx('ناجح', 'Pass') : tx('غير مستوفٍ', 'Does not pass'))}
    </span>
  );
}

function ContrastStatus({ ratio }: { ratio: number }) {
  const { t } = useLang();
  const rows = [
    { id: 'aa-normal', title: tx('AA — نص عادي', 'AA — normal text'), threshold: 4.5 },
    { id: 'aa-large', title: tx('AA — نص كبير', 'AA — large text'), threshold: 3 },
    { id: 'aaa-normal', title: tx('AAA — نص عادي', 'AAA — normal text'), threshold: 7 },
    { id: 'aaa-large', title: tx('AAA — نص كبير', 'AAA — large text'), threshold: 4.5 },
  ];
  return (
    <div className="mt-5 grid gap-2 sm:grid-cols-2">
      {rows.map((row) => (
        <div key={row.id} data-testid={`result-${row.id}`} className="flex min-h-14 items-center justify-between gap-2 rounded-xl border border-border/70 bg-background/70 px-3 py-2">
          <span className="text-sm font-semibold">{t(row.title)}</span>
          <ResultBadge passed={ratio >= row.threshold} label={row.id} />
        </div>
      ))}
    </div>
  );
}

export default function QualityLab() {
  const { t, dir } = useLang();
  const reduceMotion = useReducedMotion();
  const [copy, setCopy] = useState('');
  const [sampleLoaded, setSampleLoaded] = useState(false);
  const [foreground, setForeground] = useState('#28305E');
  const [background, setBackground] = useState('#F6F0E3');
  const [foregroundDraft, setForegroundDraft] = useState('#28305E');
  const [backgroundDraft, setBackgroundDraft] = useState('#F6F0E3');
  const [copyNotice, setCopyNotice] = useState('');
  const [contrastNotice, setContrastNotice] = useState('');

  useDocTitle(tx('مختبر الجودة — مروان الزهراني', 'Quality Lab — Marwan Alzahrani'));

  const stats = useMemo(() => {
    const invisible = countMatches(copy, INVISIBLE_RE);
    const repeatedSpaces = countMatches(copy, /[ \t]{2,}/gu);
    const punctuationSpacing = countMatches(copy, /[ \t]+[،؛؟,.!:;]|[،؛؟,.!:;](?=\S)/gu);
    const words = copy.trim() ? copy.trim().split(/\s+/u).length : 0;
    return { chars: [...copy].length, words, lines: copy ? copy.split(/\r\n|\r|\n/u).length : 0, invisible, repeatedSpaces, punctuationSpacing };
  }, [copy]);

  const suggestion = useMemo(() => cleanWhitespace(copy), [copy]);
  const ratio = useMemo(() => contrastRatio(foregroundDraft, backgroundDraft), [foregroundDraft, backgroundDraft]);
  const validForeground = Boolean(parseHex(foregroundDraft));
  const validBackground = Boolean(parseHex(backgroundDraft));
  const BackIcon = dir === 'rtl' ? ArrowRight : ArrowLeft;

  const updateColor = (which: 'foreground' | 'background', value: string) => {
    if (which === 'foreground') {
      setForegroundDraft(value);
      if (parseHex(value)) setForeground(value.toUpperCase());
    } else {
      setBackgroundDraft(value);
      if (parseHex(value)) setBackground(value.toUpperCase());
    }
  };

  const loadSample = () => {
    setCopy(t(tx('نكتب تجربة رقمية واضحة  ونراجع تفاصيلها، قبل النشر.', 'We write clear digital experiences  and review the details, before launch.')));
    setSampleLoaded(true);
  };

  const copySuggestion = async () => {
    try {
      await navigator.clipboard.writeText(suggestion);
      setCopyNotice(t(tx('نُسخت النسخة المقترحة. النص الأصلي لم يتغير.', 'Suggested version copied. Your original text was not changed.')));
    } catch {
      setCopyNotice(t(tx('تعذّر الوصول إلى الحافظة. يمكنك تحديد النسخة المقترحة ونسخها يدويًا.', 'Clipboard access was blocked. Select and copy the suggested text manually.')));
    }
  };

  return (
    <SiteShell>
      <div className="overflow-hidden">
        <section className="relative isolate overflow-hidden bg-[hsl(var(--ink))] text-[hsl(var(--wool))]">
          <div className="sadu-diamonds absolute inset-0 opacity-60" />
          <div className="relative mx-auto grid max-w-7xl items-center gap-8 px-5 pb-14 pt-7 md:px-8 md:pb-20 md:pt-10 lg:grid-cols-[1.05fr_.95fr]">
            <div>
              <Link href="/" data-testid="link-quality-home" className="inline-flex min-h-10 items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-white/75 transition-colors hover:bg-white/10 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-[hsl(var(--saffron))]">
                <BackIcon className="h-4 w-4" aria-hidden="true" />{t(tx('العودة للرئيسية', 'Back to homepage'))}
              </Link>
              <motion.div initial={reduceMotion ? false : { opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .45 }} className="mt-10 inline-flex items-center gap-2 rounded-full border border-[hsl(var(--saffron)/.38)] bg-[hsl(var(--saffron)/.1)] px-3 py-1.5 text-xs font-bold text-[hsl(var(--saffron))]">
                <ScanText className="h-3.5 w-3.5" aria-hidden="true" />{t(tx('مختبر صغير، مراجعة بيدك', 'A small lab, reviewed by you'))}
              </motion.div>
              <motion.h1 data-testid="heading-quality-lab" initial={reduceMotion ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .05, duration: .55 }} className="mt-5 max-w-2xl font-display text-4xl font-extrabold leading-[1.3] sm:text-6xl">
                {t(tx('تفاصيل صغيرة. فرق واضح.', 'Small details. A clearer result.'))}
              </motion.h1>
              <motion.p initial={reduceMotion ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .15 }} className="mt-5 max-w-xl text-base leading-8 text-[hsl(var(--wool)/.72)] sm:text-lg">
                {t(tx('راجع تنسيق النص العربي، ثم قِس تباين الألوان بمعيار WCAG. أدوات عملية ومحدودة النطاق — والقرار يبقى لك.', 'Review Arabic text formatting, then measure color contrast against WCAG thresholds. Practical tools with clear limits — the decision stays yours.'))}
              </motion.p>
              <div className="mt-7 flex flex-wrap gap-2">
                {[tx('محلي في المتصفح', 'Browser-local'), tx('لا حفظ أو إرسال', 'No storage or upload'), tx('لا تصحيح لغوي', 'No grammar correction')].map((tag) => <span key={tag.en} data-testid={`badge-quality-${tag.en.toLowerCase().replace(/\s+/gu, '-')}`} className="num rounded-full border border-white/15 px-3 py-1.5 text-xs text-white/80">{t(tag)}</span>)}
              </div>
            </div>
            <motion.div initial={reduceMotion ? false : { opacity: 0, y: 10, rotate: 1 }} animate={{ opacity: 1, y: 0, rotate: 0 }} transition={{ delay: .1, duration: .65 }} className="mx-auto w-full max-w-[510px] rounded-[2rem] border border-white/10 bg-[hsl(var(--wool)/.04)] p-3 text-[hsl(var(--wool))] sm:p-5">
              <LabIllustration />
            </motion.div>
          </div>
          <div className="sadu-band relative" />
        </section>

        <main className="mx-auto max-w-7xl px-5 pb-16 pt-9 md:px-8 md:pt-14">
          <section data-testid="notice-quality-privacy" aria-labelledby="quality-privacy-title" className="mx-auto max-w-5xl rounded-[1.5rem] border border-primary/25 bg-primary/[.045] p-5 sm:p-6">
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><LockKeyhole className="h-5 w-5" aria-hidden="true" /></span>
              <div>
                <h2 id="quality-privacy-title" data-testid="heading-quality-privacy" className="font-display font-bold">{t(tx('الخصوصية والحدود — قبل أن تبدأ', 'Privacy & limits — before you begin'))}</h2>
                <p data-testid="text-quality-privacy" className="mt-2 text-sm leading-7 text-muted-foreground">{t(tx('كل الحسابات تتم داخل متصفحك فقط؛ لا API ولا تخزين أو إرسال للنصوص أو الألوان، ولا حقول لبيانات شخصية. إعادة تحميل الصفحة تمسح المدخلات. أداة النص تلاحظ المسافات وعلامات الترقيم وبعض محارف التنسيق غير المرئية فقط؛ لا تفهم المعنى ولا تفحص الإملاء أو النحو. أداة الألوان تحسب تباين لونين وفق معادلة WCAG، ولا تختبر الصور أو حالات الواجهة أو الموقع كاملًا. النتيجة إرشادية وليست شهادة امتثال.', 'All calculations happen in your browser: no API, storage, or transmission of text or colors, and no personal-data fields. Reloading clears your input. The text tool only notices spacing, punctuation spacing, and selected invisible formatting characters; it does not interpret meaning or check spelling or grammar. The color tool calculates the contrast of two colors using the WCAG formula; it does not test images, interface states, or an entire website. Results are guidance, not a compliance certification.'))}</p>
              </div>
            </div>
          </section>

          <section className="mx-auto mt-12 max-w-5xl" aria-labelledby="copy-review-heading">
            <div className="mb-6 flex items-start gap-3">
              <span className="num grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[hsl(var(--ink))] text-xs font-bold text-[hsl(var(--saffron))]">01</span>
              <div><p className="num text-[10px] tracking-wider text-primary">COPY / FORMAT</p><h2 id="copy-review-heading" data-testid="heading-copy-review" className="font-display text-2xl font-bold sm:text-3xl">{t(tx('مراجعة تنسيق النص', 'Copy formatting review'))}</h2><p data-testid="text-copy-intro" className="mt-2 text-sm leading-6 text-muted-foreground">{t(tx('إشارات تنسيق حذرة، لا مراجعة لغوية. جرّب نصًا قصيرًا أو ألصق نصك بنفسك.', 'Cautious formatting signals, not language review. Try a short sample or paste your own text.'))}</p></div>
            </div>
            <div className="grid gap-5 lg:grid-cols-[1.15fr_.85fr]">
              <section className="rounded-[1.6rem] border border-card-border bg-card p-5 shadow-sm sm:p-7" aria-label={t(tx('مدخل مراجعة النص', 'Text review input'))}>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <label htmlFor="quality-copy" data-testid="label-quality-copy" className="inline-flex items-center gap-2 text-sm font-bold"><FileText className="h-4 w-4 text-primary" aria-hidden="true" />{t(tx('النص المراد مراجعته', 'Text to review'))}</label>
                  <button type="button" data-testid="button-copy-sample" onClick={loadSample} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border bg-background px-3.5 text-xs font-semibold transition-colors hover:border-primary/40 hover:bg-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary">
                    <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />{t(tx(sampleLoaded ? 'إعادة إدراج المثال' : 'جرّب نصًا تجريبيًا', sampleLoaded ? 'Load sample again' : 'Try a sample'))}
                  </button>
                </div>
                <textarea id="quality-copy" data-testid="input-quality-copy" dir={dir} value={copy} onChange={(event) => { setCopy(event.target.value); setSampleLoaded(false); setCopyNotice(''); }} rows={8} maxLength={12000} placeholder={t(tx('الصق نصًا هنا… لا يُرسل أو يُحفظ.', 'Paste text here… it is not sent or saved.'))} className="mt-4 w-full resize-y rounded-2xl border border-input bg-background px-4 py-3 text-base leading-8 placeholder:text-muted-foreground/70 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary" aria-describedby="copy-local-note" />
                <p id="copy-local-note" data-testid="text-copy-local-note" className="mt-2 text-xs leading-5 text-muted-foreground">{t(tx('الحد ١٢٬٠٠٠ محرف. لا تدخل معلومات حساسة على جهاز مشترك.', '12,000 character limit. Avoid sensitive information on a shared device.'))}</p>
                <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {[
                    { id: 'characters', label: tx('محرف', 'Characters'), value: stats.chars },
                    { id: 'words', label: tx('كلمة تقريبًا', 'Words approx.'), value: stats.words },
                    { id: 'lines', label: tx('سطر', 'Lines'), value: stats.lines },
                    { id: 'invisible', label: tx('محرف تنسيق خفي', 'Invisible format chars'), value: stats.invisible },
                  ].map((item) => <div key={item.id} data-testid={`result-copy-${item.id}`} className="rounded-xl bg-muted/70 p-3"><p className="num text-xl font-bold text-primary">{item.value}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{t(item.label)}</p></div>)}
                </div>
              </section>

              <aside className="flex flex-col rounded-[1.6rem] bg-[hsl(var(--ink))] p-5 text-[hsl(var(--wool))] shadow-sm sm:p-6" aria-labelledby="copy-findings-heading">
                <div className="flex items-center gap-3">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/10 text-[hsl(var(--saffron))]"><Eye className="h-5 w-5" aria-hidden="true" /></span>
                  <div><p className="num text-[10px] tracking-wider text-[hsl(var(--saffron))]">LOCAL REVIEW / 01</p><h3 id="copy-findings-heading" data-testid="heading-copy-findings" className="font-display text-lg font-bold">{t(tx('ملاحظات تنسيق', 'Formatting notes'))}</h3></div>
                </div>
                <ul className="mt-5 space-y-3">
                  {[
                    { id: 'repeat-spaces', label: tx('تتابع مسافات أو تبويبات', 'Repeated spaces or tabs'), value: stats.repeatedSpaces },
                    { id: 'punctuation-spacing', label: tx('مسافات قرب علامات الترقيم', 'Spacing near punctuation'), value: stats.punctuationSpacing },
                  ].map((item) => <li key={item.id} data-testid={`result-copy-${item.id}`} className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[.055] px-3 py-3"><span className="text-sm leading-6 text-white/80">{t(item.label)}</span><span className="num min-w-8 rounded-full bg-white/10 px-2 py-1 text-center text-xs font-bold text-[hsl(var(--saffron))]">{item.value}</span></li>)}
                </ul>
                {stats.invisible > 0 && <p data-testid="notice-invisible-characters" className="mt-3 rounded-xl border border-[hsl(var(--saffron)/.3)] bg-[hsl(var(--saffron)/.08)] p-3 text-xs leading-6 text-white/80">{t(tx('قد تؤثر بعض محارف اتجاه النص أو التنسيق غير المرئية في العرض أو النسخ. راجع النص الأصلي قبل حذفها.', 'Some invisible direction or formatting characters may affect display or copying. Review the original before removing them.'))}</p>}
                {stats.invisible === 0 && <p data-testid="notice-no-invisible-characters" className="mt-3 rounded-xl border border-white/10 bg-white/[.04] p-3 text-xs leading-6 text-white/65">{t(tx('لم تُرصد محارف تنسيق خفية من الأنواع التي تبحث عنها هذه الأداة.', 'No invisible formatting characters from the types this tool checks were found.'))}</p>}
                <div className="mt-5 border-t border-white/10 pt-4">
                  <div className="flex items-center gap-2"><Type className="h-4 w-4 text-[hsl(var(--saffron))]" aria-hidden="true" /><h4 data-testid="heading-clean-preview" className="text-sm font-bold">{t(tx('اقتراح تنظيف المسافات', 'Suggested whitespace cleanup'))}</h4></div>
                  <p data-testid="text-clean-preview-note" className="mt-1 text-xs leading-5 text-white/60">{t(tx('معاينة مستقلة: توحيد المسافات المتكررة وإزالة المسافة قبل الترقيم. لا يتغير نصك إلا إذا نسخت هذا الاقتراح أو ألصقته بنفسك.', 'Separate preview: normalize repeated spaces and remove spaces before punctuation. Your text changes only if you copy or paste this suggestion yourself.'))}</p>
                  <pre data-testid="result-clean-preview" dir={dir} className="mt-3 min-h-20 max-h-44 overflow-auto whitespace-pre-wrap break-words rounded-xl border border-white/10 bg-white/[.055] p-3 font-sans text-sm leading-7 text-white/85">{suggestion || t(tx('ستظهر المعاينة هنا.', 'The preview will appear here.'))}</pre>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" data-testid="button-copy-suggestion" onClick={() => void copySuggestion()} disabled={!copy} className="inline-flex min-h-10 items-center justify-center gap-2 rounded-full bg-[hsl(var(--saffron))] px-4 text-xs font-bold text-[hsl(var(--ink))] transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45"><ClipboardCheck className="h-4 w-4" aria-hidden="true" />{t(tx('نسخ الاقتراح', 'Copy suggestion'))}</button>
                    <button type="button" data-testid="button-apply-suggestion" onClick={() => { setCopy(suggestion); setCopyNotice(t(tx('طُبّق الاقتراح على النص بإجراء منك.', 'The suggestion was applied by your action.'))); }} disabled={!copy || suggestion === copy} className="inline-flex min-h-10 items-center justify-center gap-2 rounded-full border border-white/20 px-4 text-xs font-semibold text-white transition-colors hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-45"><Check className="h-3.5 w-3.5" aria-hidden="true" />{t(tx('استبدال النص يدويًا', 'Apply to text'))}</button>
                  </div>
                  <p data-testid="status-copy-action" aria-live="polite" className="mt-2 min-h-5 text-xs text-[hsl(var(--wool)/.72)]">{copyNotice}</p>
                </div>
              </aside>
            </div>
          </section>

          <section className="mx-auto mt-16 max-w-5xl" aria-labelledby="contrast-heading">
            <div className="mb-6 flex items-start gap-3">
              <span className="num grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[hsl(var(--ink))] text-xs font-bold text-[hsl(var(--saffron))]">02</span>
              <div><p className="num text-[10px] tracking-wider text-primary">WCAG / CONTRAST</p><h2 id="contrast-heading" data-testid="heading-contrast" className="font-display text-2xl font-bold sm:text-3xl">{t(tx('حاسبة تباين الألوان', 'Color contrast calculator'))}</h2><p data-testid="text-contrast-intro" className="mt-2 text-sm leading-6 text-muted-foreground">{t(tx('أدخل لون النص والخلفية بصيغة HEX سداسية. القيم محسوبة مباشرة من ألوان sRGB وفق صيغة WCAG.', 'Enter foreground and background colors as six-digit HEX. Values are calculated directly from sRGB colors using the WCAG formula.'))}</p></div>
            </div>
            <div className="grid gap-5 lg:grid-cols-[.95fr_1.05fr]">
              <section className="rounded-[1.6rem] border border-card-border bg-card p-5 shadow-sm sm:p-7" aria-label={t(tx('مدخلات حاسبة التباين', 'Contrast calculator inputs'))}>
                <div className="grid gap-5 sm:grid-cols-2">
                  {([
                    { key: 'foreground' as const, title: tx('لون النص الأمامي', 'Foreground / text'), value: foreground, draft: foregroundDraft, valid: validForeground },
                    { key: 'background' as const, title: tx('لون الخلفية', 'Background'), value: background, draft: backgroundDraft, valid: validBackground },
                  ]).map((field) => <div key={field.key} data-testid={`group-color-${field.key}`}>
                    <label htmlFor={`color-hex-${field.key}`} data-testid={`label-color-${field.key}`} className="mb-2 block text-sm font-bold">{t(field.title)}</label>
                    <div className="flex items-center gap-2 rounded-xl border border-input bg-background p-2">
                      <input type="color" aria-label={t(field.key === 'foreground' ? tx('اختيار لون النص', 'Choose text color') : tx('اختيار لون الخلفية', 'Choose background color'))} data-testid={`input-color-picker-${field.key}`} value={field.value} onChange={(event) => updateColor(field.key, event.target.value.toUpperCase())} className="h-11 w-12 cursor-pointer rounded-lg border-0 bg-transparent p-0.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary" />
                      <input id={`color-hex-${field.key}`} data-testid={`input-color-hex-${field.key}`} aria-invalid={!field.valid} aria-describedby={`color-help-${field.key}`} value={field.draft} onChange={(event) => updateColor(field.key, event.target.value)} autoComplete="off" spellCheck={false} maxLength={7} inputMode="text" className="num min-h-11 min-w-0 flex-1 rounded-lg border border-transparent bg-transparent px-2 text-base font-semibold uppercase tracking-wide focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary" />
                    </div>
                    <p id={`color-help-${field.key}`} data-testid={`text-color-help-${field.key}`} className={`mt-2 text-xs leading-5 ${field.valid ? 'text-muted-foreground' : 'text-destructive'}`}>{field.valid ? t(tx('صيغة صالحة مثل #28305E', 'Valid format, e.g. #28305E')) : t(tx('أدخل # متبوعًا بستة أرقام أو أحرف سداسية عشرية.', 'Enter # followed by six hexadecimal digits or letters.'))}</p>
                  </div>)}
                </div>
                <button type="button" data-testid="button-contrast-reset" onClick={() => { setForeground('#28305E'); setForegroundDraft('#28305E'); setBackground('#F6F0E3'); setBackgroundDraft('#F6F0E3'); setContrastNotice(t(tx('عادت الألوان إلى القيم الافتراضية.', 'Colors restored to the defaults.'))); }} className="mt-5 inline-flex min-h-10 items-center gap-2 rounded-full border border-border bg-background px-4 text-xs font-semibold transition-colors hover:border-primary/40 hover:bg-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary"><RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />{t(tx('استعادة الألوان الافتراضية', 'Restore default colors'))}</button>
                <p data-testid="status-contrast-action" aria-live="polite" className="mt-2 min-h-5 text-xs text-muted-foreground">{contrastNotice}</p>
                {!validForeground || !validBackground ? <p data-testid="notice-invalid-colors" role="alert" className="mt-2 rounded-xl border border-destructive/25 bg-destructive/[.06] p-3 text-sm leading-6 text-destructive">{t(tx('أصلح صيغة اللون غير الصالحة لعرض النسبة والنتائج.', 'Correct the invalid color format to see the ratio and results.'))}</p> : null}
              </section>

              <section className="rounded-[1.6rem] border border-card-border bg-card p-5 shadow-sm sm:p-7" aria-labelledby="contrast-results-heading">
                <div className="flex items-center justify-between gap-4">
                  <div><p className="num text-[10px] tracking-wider text-muted-foreground">LIVE / WCAG</p><h3 id="contrast-results-heading" data-testid="heading-contrast-results" className="mt-1 font-display text-lg font-bold">{t(tx('نتيجة القياس', 'Measurement result'))}</h3></div>
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-muted text-primary"><Contrast className="h-5 w-5" aria-hidden="true" /></span>
                </div>
                <div data-testid="result-contrast-ratio" aria-live="polite" className="mt-4 flex items-end gap-2">
                  <span className="num text-5xl font-bold tracking-tight text-primary">{ratio === null ? '—' : ratio.toFixed(2)}</span><span className="mb-1 text-sm text-muted-foreground">{t(tx('إلى 1', ':1 ratio'))}</span>
                </div>
                {ratio !== null ? <ContrastStatus ratio={ratio} /> : <p data-testid="text-contrast-waiting" className="mt-4 rounded-xl bg-muted/70 p-4 text-sm leading-6 text-muted-foreground">{t(tx('أدخل لونين صالحين لإظهار حالات النجاح.', 'Enter two valid colors to show pass states.'))}</p>}
                <div data-testid="sample-contrast-live" aria-label={t(tx('معاينة حية للنص والألوان المختارة', 'Live preview of the selected text and colors'))} style={{ color: foreground, backgroundColor: background }} className="mt-5 rounded-2xl border border-border p-5 transition-colors">
                  <div className="flex items-center gap-2 text-xs font-semibold opacity-75"><Eye className="h-4 w-4" aria-hidden="true" />{t(tx('معاينة مباشرة', 'Live sample'))}</div>
                  <p data-testid="text-contrast-sample-large" className="mt-3 font-display text-2xl font-bold leading-relaxed">{t(tx('وضوح النص يبدأ من التباين', 'Clear text starts with contrast'))}</p>
                  <p data-testid="text-contrast-sample-normal" className="mt-2 text-sm leading-6">{t(tx('هذا مثال لنص عادي على اللونين المحددين. افحص حالات الاستخدام الفعلية أيضًا.', 'This is a normal-text sample using your selected colors. Check real interface states too.'))}</p>
                  <span data-testid="badge-contrast-sample" className="mt-3 inline-flex rounded-full border border-current/30 px-3 py-1 text-xs font-bold">{foreground} / {background}</span>
                </div>
                <p data-testid="text-contrast-limits" className="mt-3 text-xs leading-5 text-muted-foreground">{t(tx('WCAG 2.2: AA للنص العادي 4.5:1، والكبير 3:1؛ AAA للنص العادي 7:1، والكبير 4.5:1. النص الكبير عادةً 18pt أو 14pt عريضًا. الحساب لا يغطي الشفافية أو الصور أو ظروف العرض.', 'WCAG 2.2: AA is 4.5:1 for normal text and 3:1 for large text; AAA is 7:1 for normal and 4.5:1 for large text. Large text is generally 18pt or 14pt bold. This calculation does not cover transparency, images, or display conditions.'))}</p>
              </section>
            </div>
          </section>

          <section data-testid="section-quality-references" aria-labelledby="quality-references-heading" className="mx-auto mt-16 max-w-5xl rounded-[1.75rem] bg-muted/70 p-6 sm:p-8">
            <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--ink))] text-[hsl(var(--saffron))]"><ShieldCheck className="h-5 w-5" aria-hidden="true" /></span><div><h2 id="quality-references-heading" data-testid="heading-quality-references" className="font-display text-xl font-bold">{t(tx('مراجع للتعمق', 'Go to the source'))}</h2><p data-testid="text-quality-references" className="mt-1 text-sm text-muted-foreground">{t(tx('المعيار الرسمي وشرح حساب التباين؛ أدواتنا لا تستبدل القراءة المتخصصة.', 'The official standard and contrast explanation; these tools do not replace expert review.'))}</p></div></div>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {[
                { id: 'wcag', href: 'https://www.w3.org/TR/WCAG22/', title: tx('معايير WCAG 2.2', 'WCAG 2.2 standard'), description: tx('معيار الوصول الرسمي من W3C', 'Official W3C accessibility standard') },
                { id: 'contrast', href: 'https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html', title: tx('شرح الحد الأدنى للتباين', 'Understanding contrast minimum'), description: tx('معايير النص العادي والكبير', 'Normal and large text thresholds') },
              ].map((reference) => <a key={reference.id} data-testid={`link-reference-${reference.id}`} href={reference.href} target="_blank" rel="noreferrer" className="group flex min-h-[76px] items-center justify-between gap-3 rounded-2xl border border-border/70 bg-card p-4 transition-colors hover:border-primary/40 hover:bg-background focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary">
                <span><span className="block text-sm font-bold">{t(reference.title)}</span><span className="mt-1 block text-xs text-muted-foreground">{t(reference.description)}</span></span><ExternalLink className="h-4 w-4 shrink-0 text-primary transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
              </a>)}
            </div>
            <p data-testid="text-quality-footer-note" className="mt-5 flex items-start gap-2 text-xs leading-6 text-muted-foreground"><Info className="mt-1 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />{t(tx('استخدم النتائج كبداية للمراجعة، لا كحكم على جودة اللغة أو إمكانية الوصول الكاملة.', 'Use these results as a starting point, not as a judgment of language quality or complete accessibility.'))}</p>
          </section>
        </main>
      </div>
    </SiteShell>
  );
}
