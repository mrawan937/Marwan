import { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { ArrowLeft, ArrowRight, Check, Copy, FileText, RotateCcw, Sparkles } from 'lucide-react';
import { useDocTitle, useLang } from '@/lib/i18n';
import { SiteShell } from '@/components/site-shell';

export default function ProductCopyBuilder() {
  const { t, dir } = useLang();
  useDocTitle({ ar: 'منشئ وصف المنتج — مروان الزهراني', en: 'Product description builder — Marwan Alzahrani' });
  const [name, setName] = useState('صندوق تمر للضيافة');
  const [audience, setAudience] = useState('محبي الضيافة');
  const [features, setFeatures] = useState('تغليف مناسب للإهداء\nأحجام متعددة');
  const [callToAction, setCallToAction] = useState('اختر ما يناسب مناسبتك');
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [tone, setTone] = useState<'warm' | 'professional'>('warm');
  const [copied, setCopied] = useState(false);
  const BackIcon = dir === 'rtl' ? ArrowRight : ArrowLeft;

  const output = useMemo(() => {
    const title = name.trim();
    const target = audience.trim();
    const points = features.split(/\n|،|,/u).map((item) => item.trim()).filter(Boolean).slice(0, 5);
    const cta = callToAction.trim();
    if (!title || points.length === 0) return '';
    if (language === 'ar') {
      const intro = tone === 'warm'
        ? `اكتشف ${title}${target ? `، المصمم لـ${target}` : ''}.`
        : `${title}${target ? ` — خيار عملي لـ${target}` : ''}.`;
      return [intro, '', ...points.map((item) => `• ${item}`), '', cta || 'اطلبه الآن وتعرّف على التفاصيل.'].join('\n');
    }
    const intro = tone === 'warm'
      ? `Meet ${title}${target ? `, made for ${target}` : ''}.`
      : `${title}${target ? ` — a practical choice for ${target}` : ''}.`;
    return [intro, '', ...points.map((item) => `• ${item}`), '', cta || 'Order now to learn more.'].join('\n');
  }, [name, audience, features, callToAction, language, tone]);

  const copyOutput = async () => {
    try {
      await navigator.clipboard.writeText(output);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };
  const reset = () => {
    setName('');
    setAudience('');
    setFeatures('');
    setCallToAction('');
    setCopied(false);
  };
  const inputClass = 'mt-2 h-12 w-full rounded-xl border border-input bg-background px-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary';

  return (
    <SiteShell>
      <main className="mx-auto max-w-6xl px-5 pb-20 pt-7 md:px-8 md:pt-12">
        <Link href="/#work" data-testid="link-copy-builder-back" className="inline-flex min-h-10 items-center gap-2 rounded-full px-3 text-sm font-semibold text-muted-foreground hover:text-foreground">
          <BackIcon className="h-4 w-4" aria-hidden="true" />{t({ ar: 'العودة إلى النماذج والأدوات', en: 'Back to demos and tools' })}
        </Link>

        <div className="mt-7 overflow-hidden rounded-[1.8rem] border border-card-border bg-card shadow-sm">
          <header className="bg-[hsl(var(--ink))] p-6 text-[hsl(var(--wool))] sm:p-9">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[hsl(var(--saffron))] text-[hsl(var(--ink))]"><FileText className="h-6 w-6" aria-hidden="true" /></span>
            <p className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-[hsl(var(--saffron))]"><Sparkles className="h-4 w-4" aria-hidden="true" />{t({ ar: 'أداة كتابة محلية', en: 'Local writing tool' })}</p>
            <h1 className="mt-2 font-display text-3xl font-extrabold leading-tight sm:text-4xl">{t({ ar: 'حوّل مواصفات منتجك إلى وصف واضح.', en: 'Turn product details into clear copy.' })}</h1>
            <p className="mt-3 max-w-3xl leading-7 text-[hsl(var(--wool)/.76)]">{t({ ar: 'أدخل الاسم والمزايا والجمهور، وشاهد مسودة مرتبة قابلة للنسخ. الأداة تستخدم قالبًا مباشرًا ولا تخترع مزايا أو ترسل بياناتك.', en: 'Enter a name, features and audience to create a structured draft you can copy. This tool uses a simple template; it does not invent product claims or send your data.' })}</p>
          </header>

          <div className="grid gap-6 p-5 sm:p-8 lg:grid-cols-2">
            <section aria-labelledby="copy-builder-input-heading">
              <div className="flex items-center justify-between gap-3">
                <h2 id="copy-builder-input-heading" className="font-display text-xl font-bold">{t({ ar: 'تفاصيل المنتج', en: 'Product details' })}</h2>
                <label className="text-xs font-semibold">
                  {t({ ar: 'لغة الوصف', en: 'Copy language' })}
                  <select data-testid="select-copy-language" value={language} onChange={(event) => { const nextLanguage = event.target.value as 'ar' | 'en'; setLanguage(nextLanguage); if (nextLanguage !== language) { setName(''); setAudience(''); setFeatures(''); setCallToAction(''); setCopied(false); } }} className="ms-2 h-9 rounded-lg border border-input bg-background px-2 text-sm">
                    <option value="ar">العربية</option>
                    <option value="en">English</option>
                  </select>
                </label>
              </div>
              <p className="mt-2 text-xs leading-5 text-muted-foreground">{t({ ar: 'اكتب المدخلات باللغة التي اخترتها؛ الأداة لا تترجمها.', en: 'Write inputs in your selected language; the tool does not translate them.' })}</p>
              <p className="mt-3 rounded-lg border border-primary/20 bg-primary/[.04] px-3 py-2 text-xs leading-5 text-muted-foreground">{t({ ar: 'المحتوى الظاهر الآن مثال توضيحي فقط، وليس منتجًا أو عميلًا حقيقيًا. استبدله بمزايا منتجك الفعلية قبل النسخ.', en: 'The current content is illustrative sample data, not a real product or client. Replace it with your verified product details before copying.' })}</p>

              <div className="mt-5 space-y-4">
                <label className="block text-sm font-semibold">{t({ ar: 'اسم المنتج *', en: 'Product name *' })}
                  <input data-testid="input-copy-product-name" value={name} onChange={(event) => { setName(event.target.value); setCopied(false); }} maxLength={90} className={inputClass} placeholder={t({ ar: 'مثال: علبة هدايا من التمر', en: 'e.g. Date gift box' })} />
                </label>
                <label className="block text-sm font-semibold">{t({ ar: 'لمن يناسب؟ (اختياري)', en: 'Who is it for? (optional)' })}
                  <input data-testid="input-copy-audience" value={audience} onChange={(event) => { setAudience(event.target.value); setCopied(false); }} maxLength={100} className={inputClass} placeholder={t({ ar: 'مثال: محبي القهوة العربية', en: 'e.g. Arabic coffee lovers' })} />
                </label>
                <label className="block text-sm font-semibold">{t({ ar: 'مزايا حقيقية — كل ميزة في سطر أو افصل بينها بفاصلة *', en: 'Real features — one per line or comma-separated *' })}
                  <textarea data-testid="input-copy-features" value={features} onChange={(event) => { setFeatures(event.target.value); setCopied(false); }} maxLength={600} rows={5} className="mt-2 w-full resize-y rounded-xl border border-input bg-background px-4 py-3 text-base leading-7 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" placeholder={t({ ar: 'تمر سكري من القصيم\nتغليف مناسب للإهداء', en: 'Qassim Sukkari dates\nGift-ready packaging' })} />
                </label>
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block text-sm font-semibold">{t({ ar: 'نبرة الكتابة', en: 'Writing tone' })}
                    <select data-testid="select-copy-tone" value={tone} onChange={(event) => { setTone(event.target.value as 'warm' | 'professional'); setCopied(false); }} className={inputClass}>
                      <option value="warm">{t({ ar: 'ودودة', en: 'Warm' })}</option>
                      <option value="professional">{t({ ar: 'مهنية', en: 'Professional' })}</option>
                    </select>
                  </label>
                  <label className="block text-sm font-semibold">{t({ ar: 'دعوة الإجراء (اختياري)', en: 'Call to action (optional)' })}
                    <input data-testid="input-copy-cta" value={callToAction} onChange={(event) => { setCallToAction(event.target.value); setCopied(false); }} maxLength={100} className={inputClass} placeholder={t({ ar: 'مثال: اطلبه اليوم', en: 'e.g. Order yours today' })} />
                  </label>
                </div>
              </div>
            </section>

            <section aria-labelledby="copy-builder-output-heading" className="flex flex-col rounded-[1.4rem] bg-muted/50 p-4 sm:p-6">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 id="copy-builder-output-heading" className="font-display text-xl font-bold">{t({ ar: 'المسودة', en: 'Draft' })}</h2>
                  <p className="mt-1 text-xs text-muted-foreground">{t({ ar: 'راجع النص وعدّله قبل استخدامه.', en: 'Review and edit the copy before using it.' })}</p>
                </div>
                <span className="rounded-full border border-border bg-background px-3 py-1 text-xs">{t({ ar: 'قالب محلي', en: 'Local template' })}</span>
              </div>
              <div data-testid="output-product-copy" aria-live="polite" className="mt-4 min-h-60 flex-1 whitespace-pre-wrap rounded-xl border border-border bg-background p-4 text-sm leading-7">
                {output || <span className="text-muted-foreground">{t({ ar: 'أدخل اسم المنتج وميزة واحدة على الأقل لعرض المسودة هنا.', en: 'Enter a product name and at least one feature to see the draft here.' })}</span>}
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button type="button" data-testid="button-copy-product-copy" disabled={!output} onClick={() => void copyOutput()} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 text-sm font-bold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50">
                  {copied ? <Check className="h-4 w-4" aria-hidden="true" /> : <Copy className="h-4 w-4" aria-hidden="true" />}
                  {copied ? t({ ar: 'تم النسخ', en: 'Copied' }) : t({ ar: 'انسخ الوصف', en: 'Copy description' })}
                </button>
                <button type="button" data-testid="button-reset-product-copy" onClick={reset} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-border bg-background px-4 text-sm font-semibold">
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />{t({ ar: 'امسح المدخلات', en: 'Clear inputs' })}
                </button>
              </div>
              {!copied && output && <p role="status" className="mt-2 text-xs text-muted-foreground">{t({ ar: 'إذا لم يعمل النسخ، حدّد النص وانسخه يدويًا.', en: 'If copying is blocked, select and copy the text manually.' })}</p>}
            </section>
          </div>
          <p data-testid="notice-copy-builder-privacy" className="mx-5 mb-5 rounded-xl border border-border bg-background p-4 text-xs leading-6 text-muted-foreground sm:mx-8 sm:mb-8">
            {t({ ar: 'الخصوصية والحدود: كل شيء يعمل داخل متصفحك؛ لا API ولا ذكاء اصطناعي ولا تخزين أو إرسال للنصوص. الأداة ترتب المعلومات التي تدخلها فقط، ولا تتحقق من صحة ادعاءات المنتج.', en: 'Privacy and limits: everything runs in your browser—no API, AI, storage, or text upload. This tool only arranges what you enter and does not verify product claims.' })}
          </p>
        </div>
      </main>
    </SiteShell>
  );
}
