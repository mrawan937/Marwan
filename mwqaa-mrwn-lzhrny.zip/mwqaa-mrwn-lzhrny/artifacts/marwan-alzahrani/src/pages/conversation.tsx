import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { AlertTriangle, Bell, BellOff, Check, Copy, Home, Loader2, LockKeyhole, MessageCircle, Send } from 'lucide-react';
import {
  getGetConversationQueryKey,
  useGetConversation,
  useSendClientMessage,
} from '@workspace/api-client-react';
import { useLang, useDocTitle } from '@/lib/i18n';
import { SERVICE_LABEL, STATUS_LABEL } from '@/lib/content';
import { conversationsHref, saveConversation, takeWelcome, useSavedConversations } from '@/lib/conversations';
import { enablePush, getPushState, isIosDevice, isStandaloneApp, restorePushLink, type PushState } from '@/lib/push';
import { fmtDate, relTime } from '@/lib/format';
import { SiteShell } from '@/components/site-shell';
import { Page } from '@/components/motion';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

const STAGES = ['new', 'contacted', 'in_progress', 'completed'] as const;

export default function ConversationPage() {
  const params = useParams<{ token: string }>();
  const token = params.token ?? '';
  const { t, lang } = useLang();
  const qc = useQueryClient();
  const saved = useSavedConversations();
  const valid = /^[A-Za-z0-9_-]{20,100}$/.test(token);
  const query = useGetConversation(token, {
    query: {
      enabled: valid,
      queryKey: getGetConversationQueryKey(token),
      refetchInterval: () => document.visibilityState === 'visible' ? 10_000 : false,
      refetchIntervalInBackground: false,
      refetchOnWindowFocus: true,
    },
  });
  const send = useSendClientMessage();
  const [body, setBody] = useState('');
  const [welcome, setWelcome] = useState(false);
  const [pushState, setPushState] = useState<PushState>(() => getPushState());
  const [pushError, setPushError] = useState('');
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const pushRestoreToken = useRef('');
  const conversation = query.data;

  useDocTitle({
    ar: conversation ? `${conversation.reference} — محادثتك مع مروان` : 'محادثتي — مروان الزهراني',
    en: conversation ? `${conversation.reference} — Your conversation with Marwan` : 'My conversation — Marwan Alzahrani',
  });

  useEffect(() => {
    setWelcome(takeWelcome(token));
    setPushState(getPushState());
  }, [token]);

  useEffect(() => {
    if (!conversation) return;
    saveConversation({ token, reference: conversation.reference, createdAt: conversation.createdAt });
  }, [conversation?.reference, conversation?.createdAt, token]);

  useEffect(() => {
    if (!conversation || pushRestoreToken.current === token || getPushState() !== 'granted') return;
    pushRestoreToken.current = token;
    restorePushLink(token).catch(() => setPushError(t({ ar: 'تعذّر تحديث التنبيهات على هذا الجهاز. أعد تفعيلها من إعدادات المتصفح.', en: 'Couldn’t refresh notifications on this device. Re-enable them in your browser settings.' })));
  }, [conversation, token, t]);

  useEffect(() => {
    const existingLink = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
    const link = existingLink ?? document.createElement('link');
    const originalHref = existingLink?.getAttribute('href') ?? null;
    link.rel = 'manifest';
    link.href = `${import.meta.env.BASE_URL}api/conversations/${encodeURIComponent(token)}/manifest.webmanifest`;
    if (!link.parentNode) document.head.appendChild(link);
    return () => {
      if (existingLink && originalHref !== null) link.href = originalHref;
      else if (link.parentNode) link.parentNode.removeChild(link);
    };
  }, [token]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [conversation?.messages.length]);

  const submit = () => {
    const text = body.trim();
    if (!text || text.length > 2000 || !conversation || conversation.status === 'archived') return;
    send.mutate(
      { token, data: { body: text } },
      {
        onSuccess: () => {
          setBody('');
          qc.invalidateQueries({ queryKey: getGetConversationQueryKey(token) });
          qc.invalidateQueries({ queryKey: ['conversation-summaries'] });
        },
      },
    );
  };

  const onComposerKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey && window.matchMedia('(pointer: fine)').matches) {
      event.preventDefault();
      submit();
    }
  };

  const turnOnNotifications = async () => {
    setPushError('');
    try {
      setPushState(await enablePush(token));
    } catch {
      setPushError(t({ ar: 'تعذّر تفعيل التنبيهات. تحقّق من إعدادات المتصفح، ثم أعد المحاولة.', en: 'Couldn’t enable notifications. Check your browser settings, then try again.' }));
    }
  };

  const copyLink = async () => {
    setCopyError(false);
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopyError(true);
    }
  };

  const errorStatus = (query.error as { status?: number } | null)?.status;

  return (
    <SiteShell>
      <Page className="mx-auto max-w-4xl px-5 pb-16 pt-6 md:px-8">
        <Link href={conversationsHref(saved)} className="mb-5 inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground">
          <span aria-hidden>←</span>{t({ ar: 'كل محادثاتي', en: 'All conversations' })}
        </Link>
        {query.isLoading ? (
          <div className="space-y-4"><Skeleton className="h-32 rounded-2xl" /><Skeleton className="h-96 rounded-2xl" /></div>
        ) : !valid || errorStatus === 404 ? (
          <div className="rounded-[1.75rem] border border-dashed border-border bg-card p-10 text-center">
            <AlertTriangle className="mx-auto h-9 w-9 text-primary" />
            <h1 className="mt-4 font-display text-2xl font-bold">{t({ ar: 'المحادثة غير موجودة', en: 'Conversation not found' })}</h1>
            <p className="mt-2 text-sm text-muted-foreground">{t({ ar: 'تحقّق من صحة رابط المحادثة الخاص بك.', en: 'Check that you have the correct private conversation link.' })}</p>
          </div>
        ) : query.isError || !conversation ? (
          <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
            <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
            <p className="mt-3 font-semibold">{t({ ar: 'تعذّر تحميل المحادثة', en: 'Couldn’t load the conversation' })}</p>
            <button type="button" onClick={() => query.refetch()} className="mt-4 rounded-full bg-foreground px-5 py-2 text-sm font-semibold text-background">{t({ ar: 'إعادة المحاولة', en: 'Try again' })}</button>
          </div>
        ) : (
          <>
            <header className="overflow-hidden rounded-[1.75rem] bg-[hsl(var(--ink))] text-[hsl(var(--wool))]">
              <div className="sadu-diamonds p-6 md:p-8">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <span className="num text-sm font-semibold text-[hsl(var(--saffron))]">{conversation.reference}</span>
                    <h1 className="mt-1 font-display text-2xl font-bold sm:text-3xl">{t({ ar: 'محادثتك مع مروان', en: 'Your conversation with Marwan' })}</h1>
                    <p className="mt-2 text-sm text-[hsl(var(--wool)/0.72)]">{t(SERVICE_LABEL[conversation.service])} · {fmtDate(conversation.createdAt, lang, false)}</p>
                  </div>
                  <span className="rounded-full bg-[hsl(var(--wool)/0.12)] px-3 py-1.5 text-xs font-semibold">{t(STATUS_LABEL[conversation.status])}</span>
                </div>
                {conversation.status === 'archived' ? (
                  <div className="mt-6 rounded-xl border border-[hsl(var(--wool)/0.15)] px-4 py-3 text-sm">{t({ ar: 'هذه المحادثة مؤرشفة، ولا يمكن إرسال رسائل جديدة.', en: 'This conversation is archived. New messages can’t be sent.' })}</div>
                ) : (
                  <ol className="mt-7 grid grid-cols-4 gap-2">
                    {STAGES.map((stage, index) => {
                      const current = STAGES.indexOf(conversation.status as (typeof STAGES)[number]);
                      const complete = current >= index;
                      return (
                        <li key={stage} className="text-center">
                          <span className={cn('mx-auto grid h-8 w-8 place-items-center rounded-full text-xs font-bold', complete ? 'bg-primary text-primary-foreground' : 'bg-[hsl(var(--wool)/0.12)] text-[hsl(var(--wool)/0.6)]')}>{complete ? <Check className="h-4 w-4" /> : index + 1}</span>
                          <span className={cn('mt-2 block text-[10px] leading-4 sm:text-xs', complete ? 'text-[hsl(var(--wool))]' : 'text-[hsl(var(--wool)/0.55)]')}>{t(STATUS_LABEL[stage])}</span>
                        </li>
                      );
                    })}
                  </ol>
                )}
              </div>
            </header>

            {welcome && <div className="mt-4 rounded-2xl border border-primary/20 bg-primary/5 p-4 text-sm leading-6">{t({ ar: 'وصل طلبك إلى مروان. يمكنك العودة إلى هذه الصفحة في أي وقت عبر «محادثاتي».', en: 'Marwan has received your request. You can return here any time from “My conversations”.' })}</div>}

            <section className="mt-5 rounded-[1.75rem] border border-card-border bg-card p-4 sm:p-6" aria-label={t({ ar: 'المحادثة', en: 'Conversation' })}>
              <div className="max-h-[62vh] min-h-64 space-y-4 overflow-y-auto rounded-2xl bg-muted/40 p-4 sm:p-5">
                <div className="flex justify-start">
                  <div className="max-w-[92%] rounded-2xl rounded-ss-md bg-card px-4 py-3 shadow-sm">
                    <div className="mb-1 flex items-center gap-2 text-[11px] text-muted-foreground"><span>{t({ ar: 'طلب المشروع', en: 'Project request' })}</span><span>{relTime(conversation.createdAt, lang)}</span></div>
                    <p className="whitespace-pre-wrap text-sm leading-7" dir="auto">{conversation.description}</p>
                  </div>
                </div>
                {conversation.messages.map((message) => {
                  const isOwner = message.sender !== 'client';
                  const seenByOwner = !isOwner && conversation.ownerLastReadAt && new Date(conversation.ownerLastReadAt).getTime() >= new Date(message.createdAt).getTime();
                  return (
                    <div key={message.id} className={cn('flex', isOwner ? 'justify-start' : 'justify-end')}>
                      <div className={cn('max-w-[92%] rounded-2xl px-4 py-3 shadow-sm', isOwner ? 'rounded-ss-md bg-card' : 'rounded-se-md bg-primary text-primary-foreground')}>
                        <div className={cn('mb-1 flex items-center gap-2 text-[11px]', isOwner ? 'text-muted-foreground' : 'text-primary-foreground/75')}>
                          <span>{message.sender === 'assistant' ? t({ ar: 'مساعد آلي ثابت', en: 'Automated FAQ assistant' }) : isOwner ? t({ ar: 'مروان', en: 'Marwan' }) : t({ ar: 'أنت', en: 'You' })}</span>
                          <span>{relTime(message.createdAt, lang)}</span>
                        </div>
                        <p className="whitespace-pre-wrap text-sm leading-7" dir="auto">{message.body}</p>
                        {seenByOwner && <p className="mt-1 text-[11px] text-muted-foreground">{t({ ar: 'اطّلع مروان عليها', en: 'Seen by Marwan' })}</p>}
                      </div>
                    </div>
                  );
                })}
                <div ref={endRef} />
              </div>
              <form className="mt-4" onSubmit={(event) => { event.preventDefault(); submit(); }}>
                <textarea
                  value={body}
                  onChange={(event) => setBody(event.target.value.slice(0, 2000))}
                  onKeyDown={onComposerKeyDown}
                  rows={3}
                  maxLength={2000}
                  disabled={conversation.status === 'archived' || send.isPending}
                  placeholder={t({ ar: 'اكتب رسالتك هنا…', en: 'Write your message here…' })}
                  className="w-full resize-y rounded-xl border border-input bg-background p-4 text-sm leading-7 outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 disabled:opacity-60"
                  data-testid="input-client-message"
                />
                <div className="mt-2 flex flex-wrap items-center justify-between gap-3">
                  <span className="num text-xs text-muted-foreground">{body.length} / 2000{window.matchMedia('(pointer: fine)').matches ? ` · ${t({ ar: 'Enter للإرسال، وShift+Enter لسطر جديد', en: 'Enter to send, Shift+Enter for a new line' })}` : ''}</span>
                  <button type="submit" disabled={!body.trim() || body.trim().length > 2000 || send.isPending || conversation.status === 'archived'} className="inline-flex h-11 items-center gap-2 rounded-full bg-foreground px-5 text-sm font-semibold text-background disabled:opacity-40">
                    {send.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    {t({ ar: 'إرسال', en: 'Send' })}
                  </button>
                </div>
                {send.isError && <p role="alert" className="mt-2 text-sm text-destructive">{t({ ar: 'تعذّر إرسال الرسالة. أعد المحاولة.', en: 'Couldn’t send the message. Try again.' })}</p>}
              </form>
            </section>

            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <section className="rounded-2xl border border-card-border bg-card p-5">
                <div className="flex items-center gap-2 font-semibold"><Bell className="h-4 w-4 text-primary" />{t({ ar: 'تنبيهات الردود', en: 'Reply notifications' })}</div>
                {pushState === 'granted' ? (
                  <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground"><Check className="h-4 w-4 text-primary" />{t({ ar: 'التنبيهات مفعّلة على هذا الجهاز.', en: 'Notifications are enabled on this device.' })}</p>
                ) : pushState === 'denied' ? (
                  <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground"><BellOff className="h-4 w-4" />{t({ ar: 'التنبيهات محظورة في إعدادات المتصفح. يمكنك تفعيلها من إعدادات الموقع.', en: 'Notifications are blocked in browser settings. You can enable them in site settings.' })}</p>
                ) : pushState === 'unsupported' ? (
                  <p className="mt-3 text-sm text-muted-foreground">{t({ ar: 'هذا المتصفح لا يدعم التنبيهات.', en: 'This browser does not support notifications.' })}</p>
                ) : pushState === 'ios-needs-install' ? (
                  <div className="mt-3 text-sm leading-6 text-muted-foreground">
                    <p>{t({ ar: 'على أجهزة iPhone، أضف الموقع إلى الشاشة الرئيسية أولًا لتفعيل التنبيهات:', en: 'On iPhone, add this site to your Home Screen first to enable notifications:' })}</p>
                    <p className="mt-2 flex items-center gap-2 rounded-xl bg-muted p-3"><Home className="h-4 w-4 shrink-0 text-primary" />{t({ ar: 'اضغط على «مشاركة»، ثم اختر «إضافة إلى الشاشة الرئيسية». افتح الموقع من الأيقونة الجديدة.', en: 'Tap Share, then “Add to Home Screen”. Open the site from its new icon.' })}</p>
                    {isStandaloneApp() && <button type="button" onClick={turnOnNotifications} className="mt-3 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">{t({ ar: 'تفعيل التنبيهات', en: 'Enable notifications' })}</button>}
                  </div>
                ) : (
                  <>
                    <p className="mt-2 text-sm leading-6 text-muted-foreground">{t({ ar: 'سيصلك إشعار على هذا الجهاز عند وصول رد جديد من مروان.', en: 'Get a notification on this device when Marwan sends a new reply.' })}</p>
                    <button type="button" onClick={turnOnNotifications} className="mt-3 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">{t({ ar: 'فعّل تنبيهات المتصفح', en: 'Enable browser notifications' })}</button>
                  </>
                )}
                {pushError && <p role="alert" className="mt-2 text-xs text-destructive">{pushError}</p>}
              </section>

              <section className="rounded-2xl border border-card-border bg-card p-5">
                <div className="flex items-center gap-2 font-semibold"><LockKeyhole className="h-4 w-4 text-primary" />{t({ ar: 'رابطك الخاص', en: 'Your private link' })}</div>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{t({ ar: 'يفتح هذا الرابط محادثتك مباشرة. حافظ على خصوصيته، وأضفه إلى المفضلة لتتمكن من العودة إليه.', en: 'This link opens your conversation directly. Keep it private and bookmark it to return later.' })}</p>
                <button type="button" onClick={copyLink} className="mt-3 inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-sm font-semibold">
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  {copied ? t({ ar: 'تم نسخ الرابط', en: 'Link copied' }) : t({ ar: 'انسخ رابط المحادثة', en: 'Copy conversation link' })}
                </button>
                {copyError && <p role="alert" className="mt-2 text-xs text-destructive">{t({ ar: 'تعذّر نسخ الرابط. يمكنك نسخه من شريط العنوان.', en: 'Couldn’t copy the link. Copy it from the address bar.' })}</p>}
              </section>
            </div>
          </>
        )}
      </Page>
    </SiteShell>
  );
}