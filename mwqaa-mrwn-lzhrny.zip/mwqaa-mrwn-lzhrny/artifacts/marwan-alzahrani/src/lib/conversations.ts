import { useSyncExternalStore } from 'react';
import { useQuery } from '@tanstack/react-query';
import { lookupConversations } from '@workspace/api-client-react';

/**
 * Conversations this device has opened, kept in localStorage so a client can
 * get back to their private conversation without an account. The token in
 * each entry is the only key to the conversation.
 */

export type SavedConversation = { token: string; reference: string; createdAt: string };

const STORAGE_KEY = 'mz-conversations';
const MAX_SAVED = 20; // the lookup endpoint accepts up to 20 tokens
const TOKEN_RE = /^[A-Za-z0-9_-]{20,100}$/;

function isSaved(v: unknown): v is SavedConversation {
  if (!v || typeof v !== 'object') return false;
  const o = v as Record<string, unknown>;
  return typeof o.token === 'string' && TOKEN_RE.test(o.token) && typeof o.reference === 'string' && typeof o.createdAt === 'string';
}

function read(): SavedConversation[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]');
    return Array.isArray(parsed) ? parsed.filter(isSaved) : [];
  } catch {
    return [];
  }
}

let snapshot: SavedConversation[] = read();
const listeners = new Set<() => void>();

function emit() {
  snapshot = read();
  listeners.forEach((l) => l());
}

window.addEventListener('storage', (e) => {
  if (e.key === STORAGE_KEY) emit();
});

function write(list: SavedConversation[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list.slice(0, MAX_SAVED)));
  } catch {
    // Storage full or blocked (private mode): the private link still works.
  }
  emit();
}

export function isConversationToken(token: string | undefined): token is string {
  return !!token && TOKEN_RE.test(token);
}

/** Adds or refreshes a conversation; most recent first. */
export function saveConversation(entry: SavedConversation) {
  const current = read();
  const existing = current.find((c) => c.token === entry.token);
  if (existing && existing.reference === entry.reference && current[0]?.token === entry.token) return;
  write([entry, ...current.filter((c) => c.token !== entry.token)]);
}

export function forgetConversation(token: string) {
  write(read().filter((c) => c.token !== token));
}

export function useSavedConversations(): SavedConversation[] {
  return useSyncExternalStore(
    (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    () => snapshot,
  );
}

export const conversationSummariesKey = (tokens: string[]) => ['conversation-summaries', tokens] as const;

/** Status and unread replies for every saved conversation (header badge, list page). */
export function useConversationSummaries() {
  const saved = useSavedConversations();
  const tokens = saved.map((c) => c.token);
  const query = useQuery({
    queryKey: conversationSummariesKey(tokens),
    queryFn: () => lookupConversations({ tokens }),
    enabled: tokens.length > 0,
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
    staleTime: 10_000,
  });
  const unread = (query.data ?? []).reduce((sum, c) => sum + c.unreadCount, 0);
  return {
    saved,
    summaries: query.data,
    unread,
    isLoading: query.isLoading && tokens.length > 0,
    error: query.error,
    refetch: query.refetch,
  };
}

const WELCOME_KEY = 'mz-welcome';

/** Flags a just-created conversation so its page can greet the client once. */
export function markWelcome(token: string) {
  try {
    sessionStorage.setItem(WELCOME_KEY, token);
  } catch {
    // Not important if storage is blocked.
  }
}

/** True once for the conversation that was just created on this tab. */
export function takeWelcome(token: string): boolean {
  try {
    if (sessionStorage.getItem(WELCOME_KEY) !== token) return false;
    sessionStorage.removeItem(WELCOME_KEY);
    return true;
  } catch {
    return false;
  }
}

/** Where "my conversation" should go: straight to it when there's only one. */
export function conversationsHref(saved: SavedConversation[]): string {
  return saved.length === 1 ? `/c/${saved[0]!.token}` : '/c';
}
