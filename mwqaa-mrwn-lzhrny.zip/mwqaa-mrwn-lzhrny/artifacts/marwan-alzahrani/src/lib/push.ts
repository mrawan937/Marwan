import { getPushPublicKey, saveConversationPushSubscription } from '@workspace/api-client-react';

export type PushState = 'unsupported' | 'ios-needs-install' | 'default' | 'granted' | 'denied';

const BASE_URL = import.meta.env.BASE_URL;

export function isIosDevice() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

export function isStandaloneApp() {
  return window.matchMedia('(display-mode: standalone)').matches ||
    (navigator as Navigator & { standalone?: boolean }).standalone === true;
}

export function getPushState(): PushState {
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) return 'unsupported';
  if (isIosDevice() && !isStandaloneApp()) return 'ios-needs-install';
  return Notification.permission;
}

function decodeBase64Url(value: string) {
  const padded = value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (value.length % 4)) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

function encodeBase64Url(value: ArrayBuffer) {
  const bytes = new Uint8Array(value);
  let binary = '';
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

async function linkPush(token: string, publicKey?: string) {
  const key = publicKey ?? (await getPushPublicKey()).publicKey;
  if (!key) throw new Error('Push notifications are not configured.');
  const registration = await navigator.serviceWorker.register(`${BASE_URL}sw.js`, { scope: BASE_URL });
  await navigator.serviceWorker.ready;
  let subscription = await registration.pushManager.getSubscription();
  const currentKey = subscription?.options.applicationServerKey;
  if (subscription && (!currentKey || encodeBase64Url(currentKey) !== key)) {
    await subscription.unsubscribe();
    subscription = null;
  }
  subscription ??= await registration.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: decodeBase64Url(key).buffer as ArrayBuffer,
  });
  const json = subscription.toJSON();
  if (!json.endpoint || !json.keys?.p256dh || !json.keys.auth) throw new Error('The browser returned an incomplete push subscription.');
  await saveConversationPushSubscription(token, {
    endpoint: json.endpoint,
    keys: { p256dh: json.keys.p256dh, auth: json.keys.auth },
  });
}

/** Call directly from a user gesture: browsers require permission requests to be gesture-triggered. */
export async function enablePush(token: string): Promise<PushState> {
  const state = getPushState();
  if (state === 'unsupported' || state === 'ios-needs-install') return state;
  const permission = await Notification.requestPermission();
  if (permission !== 'granted') return permission;
  await linkPush(token);
  return 'granted';
}

/** Reconnect the saved browser subscription when the client returns with permission already granted. */
export async function restorePushLink(token: string) {
  if (getPushState() === 'granted' && Notification.permission === 'granted') await linkPush(token);
}