import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export type Lang = 'ar' | 'en';
export type L = { ar: string; en: string };

interface LangCtx {
  lang: Lang;
  dir: 'rtl' | 'ltr';
  setLang: (l: Lang) => void;
  toggle: () => void;
  t: (l: L) => string;
}

const Ctx = createContext<LangCtx | null>(null);
const KEY = 'mz-lang';

function initial(): Lang {
  try {
    const v = localStorage.getItem(KEY);
    if (v === 'en' || v === 'ar') return v;
  } catch {
    /* ignore */
  }
  return 'ar';
}

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(initial);

  useEffect(() => {
    const el = document.documentElement;
    el.lang = lang;
    el.dir = lang === 'ar' ? 'rtl' : 'ltr';
    try {
      localStorage.setItem(KEY, lang);
    } catch {
      /* ignore */
    }
  }, [lang]);

  const setLang = useCallback((l: Lang) => setLangState(l), []);
  const toggle = useCallback(() => setLangState((p) => (p === 'ar' ? 'en' : 'ar')), []);
  const t = useCallback((l: L) => l[lang], [lang]);

  const value = useMemo<LangCtx>(
    () => ({ lang, dir: lang === 'ar' ? 'rtl' : 'ltr', setLang, toggle, t }),
    [lang, setLang, toggle, t],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useLang() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useLang outside LangProvider');
  return c;
}

export function useDocTitle(title: L) {
  const { t } = useLang();
  const s = t(title);
  useEffect(() => {
    document.title = s;
  }, [s]);
}
