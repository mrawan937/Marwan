import type {
  BudgetRange,
  ProjectTimeline,
  RequestStatus,
  ServiceType,
} from '@workspace/api-client-react';
import type { L } from './i18n';

export const NAME: L = { ar: 'مروان الزهراني', en: 'Marwan Alzahrani' };
export const TITLE: L = { ar: 'مطوّر مواقع وتطبيقات', en: 'Web & Mobile Developer' };

export type ServiceSlug = 'business-website' | 'booking-system' | 'mobile-app' | 'ui-ux-design' | 'maintenance';

export interface Service {
  slug: ServiceSlug;
  type: ServiceType;
  name: L;
  short: L;
  pitch: L;
  image: string;
  imageAlt: L;
  forWho: L[];
  gets: { title: L; body: L }[];
  stack: string[];
}

export const SERVICES: Service[] = [
  {
    slug: 'business-website',
    type: 'business_website',
    name: { ar: 'موقع تعريفي لمشروعك', en: 'Business Website' },
    short: { ar: 'واجهة إلكترونية واضحة لمشروعك، تعمل على جميع الأجهزة.', en: 'A clear online home for your business, on every device.' },
    pitch: {
      ar: 'موقع تعريفي سريع وأنيق يعرّف بمشروعك، ويعرض خدماتك ومنتجاتك، ويتيح لعملائك التواصل معك بسهولة من الجوال أو الكمبيوتر.',
      en: 'A fast, elegant site that introduces your business, shows what you offer, and gets people in touch with one tap — phone first.',
    },
    image: 'images/business-website.jpg',
    imageAlt: { ar: 'جوال وجهاز لوحي على قماش السدو', en: 'Phone and tablet resting on Sadu weave' },
    forWho: [
      { ar: 'المحلات والمطاعم والمقاهي', en: 'Shops, restaurants and cafés' },
      { ar: 'العيادات والمراكز', en: 'Clinics and centres' },
      { ar: 'الشركات الناشئة والمكاتب', en: 'Start-ups and offices' },
    ],
    gets: [
      { title: { ar: 'تصميم متجاوب', en: 'Responsive design' }, body: { ar: 'يعرض الموقع محتواه بوضوح على الجوال والأجهزة اللوحية والحواسيب.', en: 'Your site looks clear on phones, tablets and computers.' } },
      { title: { ar: 'تواصل سهل', en: 'Easy contact' }, body: { ar: 'أزرار للمراسلة أو الاتصال، ورابط لموقعك على الخريطة.', en: 'Messaging and call buttons, plus a map link to your location.' } },
      { title: { ar: 'صفحات واضحة', en: 'Clear pages' }, body: { ar: 'صفحات للتعريف بمشروعك وخدماتك وأعمالك وطرق التواصل.', en: 'Pages to introduce your business, services, work and contact options.' } },
      { title: { ar: 'النشر وربط النطاق', en: 'Publishing and domain setup' }, body: { ar: 'أساعدك على نشر الموقع على الاستضافة وربطه بنطاقك.', en: 'I help publish your site and connect it to your domain.' } },
    ],
    stack: ['HTML5', 'CSS3', 'JavaScript', 'Responsive'],
  },
  {
    slug: 'booking-system',
    type: 'booking_system',
    name: { ar: 'نظام للحجوزات والإدارة', en: 'Booking & Management System' },
    short: { ar: 'نظّم المواعيد واحفظها إلكترونيًا بدلًا من الاعتماد على الدفتر الورقي.', en: 'Organise appointments and manage them digitally instead of using a paper diary.' },
    pitch: {
      ar: 'نظام يتيح لعملائك حجز المواعيد عبر واجهة سهلة، ويحفظ الحجوزات في قاعدة بيانات، ويوفر لك لوحة لمتابعتها وإدارتها.',
      en: 'A simple booking system that stores appointments in a database and gives you a dashboard to manage them.',
    },
    image: 'images/booking-system.jpg',
    imageAlt: { ar: 'تقويم ورقي مع قطع حمراء ونيلية', en: 'Paper calendar with red and indigo tokens' },
    forWho: [
      { ar: 'الصالونات والعيادات', en: 'Salons and clinics' },
      { ar: 'مراكز التدريب والتعليم', en: 'Training and tutoring centres' },
      { ar: 'القاعات والاستراحات', en: 'Halls and rest houses' },
    ],
    gets: [
      { title: { ar: 'الحجز عبر الجوال', en: 'Mobile booking' }, body: { ar: 'يختار العميل الخدمة والموعد بنفسه دون الحاجة إلى اتصال هاتفي.', en: 'Customers choose a service and time without needing to call.' } },
      { title: { ar: 'قاعدة بيانات منظمة', en: 'Organised database' }, body: { ar: 'جداول MySQL تحفظ بيانات العملاء والمواعيد بوضوح.', en: 'MySQL tables keep customer and appointment records organised.' } },
      { title: { ar: 'لوحة إدارة', en: 'Management dashboard' }, body: { ar: 'تعرض الحجوزات، وتتيح تعديلها وإلغاءها ومتابعة حالتها.', en: 'View, edit or cancel bookings and track their status.' } },
      { title: { ar: 'منع تكرار الحجز', en: 'No double-booking' }, body: { ar: 'آلية تمنع حجز الموعد نفسه أكثر من مرة.', en: 'Rules prevent the same time slot from being booked twice.' } },
    ],
    stack: ['PHP', 'MySQL', 'JavaScript', 'XAMPP'],
  },
  {
    slug: 'mobile-app',
    type: 'mobile_app',
    name: { ar: 'تطبيق جوال', en: 'Mobile App' },
    short: { ar: 'تطبيقات عملية، يتصل بعضها بالأجهزة الذكية عبر البلوتوث.', en: 'Practical apps, including ones that connect to smart devices over Bluetooth.' },
    pitch: {
      ar: 'أطوّر تطبيقات أندرويد عملية وفق فكرتك، مثل الأدوات اليومية وتطبيقات الخدمات والتطبيقات المتصلة بالأجهزة الذكية عبر البلوتوث، ومنها تطبيقا السبحة الذكية ومترجم النصوص اللذان طوّرتهما.',
      en: 'I build practical Android apps for your ideas, from everyday tools and service apps to Bluetooth-connected apps like my Smart Tasbeeh and Text Translator.',
    },
    image: 'images/mobile-app.jpg',
    imageAlt: { ar: 'جوال بجانب سبحة وجهاز بلوتوث صغير', en: 'Phone next to prayer beads and a small Bluetooth device' },
    forWho: [
      { ar: 'أصحاب الأفكار والمشاريع الصغيرة', en: 'Idea owners and small projects' },
      { ar: 'الجمعيات والمبادرات', en: 'Charities and initiatives' },
      { ar: 'من يحتاج إلى ربط جهاز بجواله', en: 'Anyone who needs to connect a device to a phone' },
    ],
    gets: [
      { title: { ar: 'واجهة بسيطة', en: 'Simple interface' }, body: { ar: 'شاشات واضحة وسهلة الاستخدام.', en: 'Clear screens that are easy to use.' } },
      { title: { ar: 'اتصال عبر البلوتوث', en: 'Bluetooth connectivity' }, body: { ar: 'ربط التطبيق بأجهزة ذكية وإرسال البيانات واستقبالها.', en: 'Connect to smart devices and send or receive data.' } },
      { title: { ar: 'حفظ البيانات', en: 'Local data' }, body: { ar: 'حفظ إعدادات المستخدم وسجله على الجهاز.', en: 'Save user settings and history on the device.' } },
      { title: { ar: 'التجربة والاختبار', en: 'Testing' }, body: { ar: 'اختبار التطبيق على أجهزة فعلية قبل تسليمه.', en: 'Test the app on real devices before delivery.' } },
    ],
    stack: ['MIT App Inventor', 'Java', 'Bluetooth'],
  },
  {
    slug: 'ui-ux-design',
    type: 'ui_ux_design',
    name: { ar: 'تصميم واجهات وتجربة مستخدم', en: 'UI / UX Design' },
    short: { ar: 'مظهر متناسق وتجربة استخدام واضحة وسهلة.', en: 'A consistent look and a clear, easy-to-follow experience.' },
    pitch: {
      ar: 'قبل كتابة أي سطر برمجي، أرتب رحلة المستخدم وأصمم الشاشات والألوان والخطوط، ليكون المنتج واضحًا وسهلًا ومتسقًا مع هوية مشروعك.',
      en: 'Before any code: I map your customer’s journey and design the screens, colours and type so the product is clear, easy and true to your brand.',
    },
    image: 'images/ui-ux-design.jpg',
    imageAlt: { ar: 'أشكال ورقية مقصوصة على هيئة واجهة تطبيق', en: 'Paper cut-out shapes laid out as an app interface' },
    forWho: [
      { ar: 'أصحاب المواقع القديمة الراغبون في تجديدها', en: 'Owners of websites that need a refresh' },
      { ar: 'من يعمل على فكرة جديدة', en: 'Anyone starting a new idea' },
      { ar: 'الفرق التي تحتاج إلى تصميم قبل التطوير', en: 'Teams that need design before development' },
    ],
    gets: [
      { title: { ar: 'رحلة المستخدم', en: 'User journey' }, body: { ar: 'خطوات واضحة من الزيارة الأولى حتى إرسال الطلب.', en: 'Clear steps from the first visit to submitting a request.' } },
      { title: { ar: 'نماذج الشاشات', en: 'Screen mock-ups' }, body: { ar: 'تصميم الصفحات الأساسية قبل بدء البرمجة.', en: 'Design key pages before development begins.' } },
      { title: { ar: 'هوية بصرية', en: 'Visual style' }, body: { ar: 'ألوان وخطوط ومسافات متناسقة مع هوية مشروعك.', en: 'Colours, typography and spacing that fit your brand.' } },
      { title: { ar: 'دعم العربية', en: 'Arabic-first' }, body: { ar: 'تصميم يراعي اتجاه الكتابة من اليمين إلى اليسار.', en: 'Layouts designed for right-to-left reading.' } },
    ],
    stack: ['UI/UX', 'HTML5', 'CSS3'],
  },
  {
    slug: 'maintenance',
    type: 'maintenance',
    name: { ar: 'صيانة وتحديث المواقع', en: 'Website Maintenance' },
    short: { ar: 'إصلاح الأعطال، وتحديث المحتوى، ونشر التعديلات.', en: 'Fixes, content updates and publishing.' },
    pitch: {
      ar: 'هل لديك موقع متعطل أو قديم؟ أصلح أعطاله، وأحدّث محتواه وصوره، وأنشر التعديلات على الاستضافة عبر FTP، دون أن تشغل بالك بالتفاصيل.',
      en: 'Have a broken or outdated site? I fix issues, update content and images, and publish changes to your hosting over FTP.',
    },
    image: 'images/maintenance.jpg',
    imageAlt: { ar: 'أدوات نحاسية دقيقة على قماش نيلي', en: 'Fine brass tools on indigo felt' },
    forWho: [
      { ar: 'المواقع القائمة التي تحتاج إلى صيانة', en: 'Existing sites that need maintenance' },
      { ar: 'أصحاب المواقع الذين تعذر عليهم التواصل مع مطورهم السابق', en: 'Owners who can no longer reach their previous developer' },
      { ar: 'من يحتاج إلى تحديث محتوى الموقع دوريًا', en: 'Anyone who needs regular content updates' },
    ],
    gets: [
      { title: { ar: 'إصلاح الأعطال', en: 'Bug fixing' }, body: { ar: 'أشخّص المشكلة وأعالج سببها بدلًا من الاكتفاء بحل مؤقت.', en: 'I diagnose the issue and fix its cause instead of applying a temporary patch.' } },
      { title: { ar: 'تحديث المحتوى', en: 'Content updates' }, body: { ar: 'تحديث النصوص والأسعار والصور، وإضافة صفحات جديدة.', en: 'Update text, prices and images, and add new pages.' } },
      { title: { ar: 'تحسين تجربة الجوال', en: 'Mobile improvements' }, body: { ar: 'تحسين عرض الموقع وسهولة استخدامه على الجوال.', en: 'Improve how the site looks and works on phones.' } },
      { title: { ar: 'النشر والاستضافة', en: 'Hosting & FTP' }, body: { ar: 'رفع الملفات وإدارة إعدادات الاستضافة.', en: 'Upload files and manage hosting settings.' } },
    ],
    stack: ['FTP', 'Git', 'PHP', 'HTML5 / CSS3'],
  },
];

export function serviceBySlug(slug: string | undefined) {
  return SERVICES.find((s) => s.slug === slug);
}
export function slugForType(type: ServiceType): ServiceSlug | null {
  return SERVICES.find((s) => s.type === type)?.slug ?? null;
}

export const SERVICE_LABEL: Record<ServiceType, L> = {
  business_website: { ar: 'موقع تعريفي', en: 'Business website' },
  booking_system: { ar: 'نظام حجوزات', en: 'Booking system' },
  mobile_app: { ar: 'تطبيق جوال', en: 'Mobile app' },
  ui_ux_design: { ar: 'تصميم واجهات', en: 'UI / UX design' },
  maintenance: { ar: 'صيانة وتحديث', en: 'Maintenance' },
  community_package: { ar: 'باقة المجتمع', en: 'Community package' },
  other: { ar: 'شيء آخر', en: 'Something else' },
};

export const STATUS_LABEL: Record<RequestStatus, L> = {
  new: { ar: 'جديد', en: 'New' },
  contacted: { ar: 'تم التواصل', en: 'Contacted' },
  in_progress: { ar: 'قيد التنفيذ', en: 'In progress' },
  completed: { ar: 'مكتمل', en: 'Completed' },
  archived: { ar: 'مؤرشف', en: 'Archived' },
};

export const STATUS_TONE: Record<RequestStatus, string> = {
  new: 'bg-primary text-primary-foreground',
  contacted: 'bg-accent text-accent-foreground',
  in_progress: 'bg-secondary text-secondary-foreground',
  completed: 'bg-[hsl(168_40%_34%)] text-[hsl(38_60%_97%)]',
  archived: 'bg-muted text-muted-foreground',
};

export const BUDGET_LABEL: Record<BudgetRange, L> = {
  under_2k: { ar: 'أقل من 2,000 ريال', en: 'Under SAR 2,000' },
  from_2k_to_5k: { ar: '2,000 – 5,000 ريال', en: 'SAR 2,000 – 5,000' },
  from_5k_to_10k: { ar: '5,000 – 10,000 ريال', en: 'SAR 5,000 – 10,000' },
  over_10k: { ar: 'أكثر من 10,000 ريال', en: 'Over SAR 10,000' },
  undecided: { ar: 'لم أحدد بعد', en: 'Not decided yet' },
};

export const TIMELINE_LABEL: Record<ProjectTimeline, L> = {
  urgent: { ar: 'مستعجل', en: 'Urgent' },
  within_month: { ar: 'خلال شهر', en: 'Within a month' },
  within_quarter: { ar: 'خلال 3 أشهر', en: 'Within 3 months' },
  flexible: { ar: 'مرن', en: 'Flexible' },
};

export const SKILLS: { group: L; items: string[]; learning?: boolean }[] = [
  { group: { ar: 'تطوير الواجهات', en: 'Frontend' }, items: ['HTML5', 'CSS3', 'JavaScript', 'Responsive Web Design'] },
  { group: { ar: 'البرمجة الخلفية وقواعد البيانات', en: 'Backend & databases' }, items: ['PHP', 'MySQL'] },
  { group: { ar: 'تطبيقات الجوال', en: 'Apps' }, items: ['MIT App Inventor', 'Java'] },
  { group: { ar: 'الأدوات', en: 'Tools' }, items: ['Git', 'VS Code', 'XAMPP', 'FTP'] },
  { group: { ar: 'التصميم', en: 'Design' }, items: ['UI/UX'] },
  { group: { ar: 'أتعلمه حاليًا', en: 'Currently learning' }, items: ['React.js', 'Laravel', 'REST APIs'], learning: true },
];

export const PROJECTS: {
  name: L;
  body: L;
  stack: string[];
  href: string;
  image: string;
  imageAlt: L;
  type: L;
  icon: 'tasbeeh' | 'booking' | 'cafe' | 'learning' | 'quality' | 'toolbox' | 'pricing' | 'copy' | 'share';
}[] = [
  {
    name: { ar: 'السبحة الذكية — نسخة الويب', en: 'Smart Tasbeeh — web edition' },
    body: { ar: 'عدّاد محلي بأهداف قابلة للتغيير، مع تلاوة قرآنية مسجّلة ومكتبة أذكار وروابط لمراجعها.', en: 'A local counter with adjustable targets, recorded Quran recitation, and a dhikr library with source links.' },
    stack: ['Local counter', 'Quran audio', 'Hadith references'],
    href: '/tasbeeh',
    image: 'images/preview-tasbeeh.jpg',
    imageAlt: { ar: 'لقطة شاشة فعلية من أداة السبحة الذكية', en: 'Actual screenshot of the Smart Tasbeeh tool' },
    type: { ar: 'عداد محلي ومصادر خارجية', en: 'Local counter & sourced content' },
    icon: 'tasbeeh',
  },
  {
    name: { ar: 'نموذج حجز المواعيد', en: 'Appointment booking demo' },
    body: { ar: 'واجهة تختار فيها خدمة ويومًا ووقتًا، ثم ترى ملخصًا محليًا؛ لا تنشئ حجزًا حقيقيًا.', en: 'Choose a service, day and time, then see a local summary; it does not create a real booking.' },
    stack: ['React', 'TypeScript', 'Responsive UI'],
    href: '/demo/booking',
    image: 'images/preview-booking.jpg',
    imageAlt: { ar: 'لقطة شاشة فعلية من نموذج حجز المواعيد', en: 'Actual screenshot of the appointment booking demo' },
    type: { ar: 'نموذج واجهة تفاعلي', en: 'Interactive UI demo' },
    icon: 'booking',
  },
  {
    name: { ar: 'نموذج قائمة المقهى والسلة', en: 'Café menu and basket demo' },
    body: { ar: 'قائمة تجريبية بصور للأصناف، وتعديل للكميات وحساب للإجمالي دون إرسال طلب أو حفظه.', en: 'A sample photo menu with quantity controls and a live total; no order is submitted or saved.' },
    stack: ['React', 'TypeScript', 'Local state'],
    href: '/demo/cafe',
    image: 'images/preview-cafe.jpg',
    imageAlt: { ar: 'لقطة شاشة فعلية من نموذج قائمة المقهى', en: 'Actual screenshot of the café menu demo' },
    type: { ar: 'نموذج متجر توضيحي', en: 'Illustrative storefront demo' },
    icon: 'cafe',
  },
  {
    name: { ar: 'مختبر React وLaravel وواجهات REST', en: 'React, Laravel & REST practice lab' },
    body: { ar: 'تمارين تفاعلية لتجربة حالة React ومسارات Laravel وطرق HTTP ببيانات محلية؛ لا تنشئ حسابًا أو ترسل طلبات إلى خادم.', en: 'Interactive exercises for React state, Laravel routes and HTTP methods using local sample data; no account or server requests.' },
    stack: ['React', 'Laravel', 'REST / HTTP'],
    href: '/learning-lab',
    image: 'images/preview-learning-lab.jpg',
    imageAlt: { ar: 'لقطة شاشة من مختبر التعلم التفاعلي لـReact وLaravel وREST', en: 'Screenshot of the interactive React, Laravel and REST learning lab' },
    type: { ar: 'مختبر تعلّم — نموذج تعليمي', en: 'Learning lab — educational demo' },
    icon: 'learning',
  },
  {
    name: { ar: 'مختبر تنسيق النص وفحص التباين', en: 'Text formatting & contrast lab' },
    body: { ar: 'أدوات فعلية داخل المتصفح لتصحيح المسافات وعلامات الترقيم العربية وقياس تباين الألوان وفق WCAG.', en: 'Working in-browser tools to clean Arabic spacing and punctuation and measure color contrast against WCAG thresholds.' },
    stack: ['Arabic text', 'WCAG contrast', 'Browser only'],
    href: '/quality-lab',
    image: 'images/preview-quality-lab.jpg',
    imageAlt: { ar: 'لقطة شاشة فعلية من مختبر تنسيق النص وفحص التباين', en: 'Actual screenshot of the text and contrast quality lab' },
    type: { ar: 'أداة جودة تعمل محليًا', en: 'Local quality tool' },
    icon: 'quality',
  },
  {
    name: { ar: 'معاينة بطاقة مشاركة الموقع', en: 'Website share-card preview' },
    body: { ar: 'اكتب عنوانًا ووصفًا ورابطًا، وشاهد بطاقة معاينة قابلة للنسخ قبل نشر صفحة مشروعك. لا تتصل الأداة بمحركات البحث ولا تحفظ مدخلاتك.', en: 'Draft a title, description and URL, then preview and copy a share-card summary. It does not contact search engines or save your input.' },
    stack: ['Live preview', 'Copyable summary', 'Browser only'],
    href: '/share-preview',
    image: 'images/preview-share-card.jpg',
    imageAlt: { ar: 'لقطة شاشة فعلية لأداة معاينة بطاقة مشاركة الموقع', en: 'Actual screenshot of the website share-card preview tool' },
    type: { ar: 'أداة محلية تفاعلية', en: 'Interactive local tool' },
    icon: 'share',
  },
  {
    name: { ar: 'موجز الفكرة وقائمة الإطلاق', en: 'Project brief & launch checklist' },
    body: { ar: 'أنشئ موجزًا قابلًا للنسخ، ثم راجع قائمة إطلاق يدوية؛ اختياراتك تبقى في الصفحة ولا تُرسل أو تُحفظ.', en: 'Build a copyable project brief and review a manual launch checklist; choices stay in the page and are not sent or saved.' },
    stack: ['Project planning', 'Checklist', 'Local state'],
    href: '/toolbox',
    image: 'images/preview-toolbox.jpg',
    imageAlt: { ar: 'لقطة شاشة فعلية من أدوات تخطيط المشروع والاستعداد للإطلاق', en: 'Actual screenshot of the project planning and launch tools' },
    type: { ar: 'أدوات تخطيط محلية', en: 'Local planning tools' },
    icon: 'toolbox',
  },
  {
    name: { ar: 'حاسبة سعر البيع والربح', en: 'Selling price & profit calculator' },
    body: { ar: 'احسب سعرًا يغطي تكلفة الوحدة والتكاليف الإضافية ورسوم الدفع وهامش الربح المستهدف، مع تفصيل واضح.', en: 'Calculate a price that covers unit and extra costs, payment fees, and your target margin, with a clear breakdown.' },
    stack: ['React', 'TypeScript', 'Pricing formula'],
    href: '/pricing-calculator',
    image: 'images/preview-pricing-calculator.jpg',
    imageAlt: { ar: 'لقطة شاشة فعلية لحاسبة سعر البيع والربح', en: 'Actual screenshot of the selling price and profit calculator' },
    type: { ar: 'حاسبة تعمل محليًا', en: 'Browser-local calculator' },
    icon: 'pricing',
  },
  {
    name: { ar: 'منشئ وصف المنتج', en: 'Product description builder' },
    body: { ar: 'رتّب اسم المنتج ومزاياه الحقيقية في مسودة وصف قابلة للنسخ، دون اختراع معلومات أو إرسال بيانات.', en: 'Arrange a product name and its real features into copyable draft text, without inventing claims or sending data.' },
    stack: ['React', 'Local templates', 'Copy to clipboard'],
    href: '/product-copy',
    image: 'images/preview-product-copy.jpg',
    imageAlt: { ar: 'لقطة شاشة فعلية لمنشئ وصف المنتج', en: 'Actual screenshot of the product description builder' },
    type: { ar: 'أداة كتابة محلية', en: 'Browser-local writing tool' },
    icon: 'copy',
  },
];

export const COURSES: L[] = [
  { ar: 'برمجة PHP وإدارة قواعد بيانات MySQL', en: 'PHP Programming & MySQL Database Management' },
  { ar: 'تطوير الويب: HTML5 وCSS3 بمستوى متقدم', en: 'Web Development: Advanced HTML5 & CSS3' },
  { ar: 'تطوير تطبيقات الجوال والربط بالأجهزة الذكية', en: 'Mobile App Development & Connecting to Smart Devices' },
  { ar: 'Java وJavaScript للتطبيقات التفاعلية', en: 'Java & JavaScript for Interactive Applications' },
  { ar: 'تصميم واجهات وتجربة المستخدم UI/UX', en: 'UI/UX Design' },
  { ar: 'مقدمة في اللغة الإنجليزية التقنية', en: 'Introduction to Technical English' },
];

export const COMPETENCIES: L[] = [
  { ar: 'حل المشكلات بأسلوب تحليلي', en: 'Analytical problem solving' },
  { ar: 'التواصل الفعّال', en: 'Effective communication' },
  { ar: 'العمل مع فرق متعددة التخصصات', en: 'Teamwork in multidisciplinary teams' },
  { ar: 'إدارة الوقت', en: 'Time management' },
  { ar: 'سرعة التعلّم الذاتي', en: 'Fast self-learning' },
  { ar: 'الاهتمام بالتفاصيل', en: 'Attention to detail' },
  { ar: 'العمل بكفاءة تحت الضغط', en: 'Working effectively under pressure' },
];

export const EXPERIENCE: { year: string; role: L; org: L; lesson: L; points: L[] }[] = [
  {
    year: '2021',
    role: { ar: 'مساعد مستودع', en: 'Warehouse Assistant' },
    org: { ar: 'أمازون', en: 'Amazon' },
    lesson: { ar: 'الدقة أساس العمل', en: 'Precision is part of the job' },
    points: [
      { ar: 'تنظيم المخزون وضمان دقة حركة البضائع', en: 'Organised inventory and ensured accurate movement of goods' },
      { ar: 'استلام الشحنات والتحقق من مطابقتها للمواصفات', en: 'Received shipments and checked them against specifications' },
      { ar: 'تنفيذ العمليات اللوجستية اليومية بكفاءة', en: 'Carried out daily logistics operations efficiently' },
      { ar: 'الالتزام بمعايير السلامة والجودة', en: 'Followed safety and quality standards' },
    ],
  },
  {
    year: '2022',
    role: { ar: 'مندوب مبيعات', en: 'Sales Representative' },
    org: { ar: 'بيبسيكو', en: 'PepsiCo' },
    lesson: { ar: 'فهم احتياجات العملاء وأهدافهم', en: 'Understanding customers and their goals' },
    points: [
      { ar: 'بناء علاقات مهنية مع العملاء وعرض المنتجات بفاعلية', en: 'Built professional client relationships and presented products effectively' },
      { ar: 'تنفيذ استراتيجيات البيع وتعزيز الوعي بالعلامة التجارية', en: 'Executed sales strategies and grew brand awareness' },
      { ar: 'تحقيق الأهداف الشهرية والربع سنوية باستمرار', en: 'Consistently met monthly and quarterly targets' },
      { ar: 'تحليل بيانات الأداء لتحسين أساليب البيع', en: 'Analysed performance data to improve sales methods' },
    ],
  },
];
