import type { ReactNode } from 'react';
import { Link, Redirect, useLocation } from 'wouter';
import { useClerk } from '@clerk/react';
import { LayoutGrid, Inbox, LogOut, ExternalLink, Lock, RefreshCw } from 'lucide-react';
import { useGetAdminSession } from '@workspace/api-client-react';
import { useLang } from '@/lib/i18n';
import { LogoMark, SaduBand } from './brand';
import { LangToggle } from './site-shell';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

export function useSignOut() {
  const { signOut } = useClerk();
  return () => signOut({ redirectUrl: basePath || '/' });
}

function GateLoading() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-4">
        <LogoMark className="h-14 w-14 animate-pulse" />
        <Skeleton className="h-2 w-32 rounded-full" />
      </div>
    </div>
  );
}

function Restricted({ email }: { email: string | null }) {
  const { t } = useLang();
  const signOut = useSignOut();
  return (
    <div className="flex min-h-[100dvh] flex-col bg-[hsl(var(--ink))] text-[hsl(var(--wool))]">
      <SaduBand />
      <div className="sadu-diamonds flex flex-1 items-center justify-center px-5">
        <div className="max-w-md text-center">
          <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-primary">
            <Lock className="h-9 w-9" />
          </div>
          <h1 className="mt-8 font-display text-3xl font-bold">{t({ ar: 'هذه المساحة خاصة.', en: 'This space is private.' })}</h1>
          <p className="mt-3 leading-7 text-[hsl(var(--wool)/0.7)]">
            {t({ ar: 'لوحة التحكم مخصصة لمروان فقط. أنت مسجّل الدخول بحساب لا يملك صلاحية الوصول.', en: 'The dashboard is for Marwan only. You’re signed in with an account that doesn’t have access.' })}
          </p>
          {email && <p className="num mt-4 inline-block rounded-full bg-[hsl(var(--wool)/0.08)] px-4 py-1.5 text-sm" data-testid="text-restricted-email">{email}</p>}
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <button type="button" onClick={signOut} data-testid="button-restricted-signout" className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[hsl(var(--wool))] px-6 font-semibold text-[hsl(var(--ink))]">
              <LogOut className="h-4 w-4" />
              {t({ ar: 'تسجيل الخروج', en: 'Sign out' })}
            </button>
            <Link href="/" className="inline-flex h-12 items-center justify-center rounded-full border border-[hsl(var(--wool)/0.25)] px-6 font-semibold">
              {t({ ar: 'الموقع العام', en: 'Public site' })}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

function GateError({ retry }: { retry: () => void }) {
  const { t } = useLang();
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-5 text-center">
      <div>
        <LogoMark className="mx-auto h-14 w-14" />
        <h1 className="mt-6 font-display text-2xl font-bold">{t({ ar: 'تعذّر التحقق من الجلسة', en: 'Couldn’t verify your session' })}</h1>
        <button type="button" onClick={retry} className="mt-6 inline-flex h-11 items-center gap-2 rounded-full bg-primary px-6 font-semibold text-primary-foreground">
          <RefreshCw className="h-4 w-4" />
          {t({ ar: 'إعادة المحاولة', en: 'Retry' })}
        </button>
      </div>
    </div>
  );
}

export function AdminGate({ children }: { children: ReactNode }) {
  const session = useGetAdminSession();
  if (session.isLoading) return <GateLoading />;
  if (session.isError || !session.data) return <GateError retry={() => session.refetch()} />;
  if (!session.data.signedIn) return <Redirect to="/sign-in" />;
  if (!session.data.isAdmin) return <Restricted email={session.data.email} />;
  return <AdminLayout email={session.data.email}>{children}</AdminLayout>;
}

function AdminLayout({ children, email }: { children: ReactNode; email: string | null }) {
  const { t } = useLang();
  const [location] = useLocation();
  const signOut = useSignOut();
  const nav = [
    { href: '/admin', label: { ar: 'نظرة عامة', en: 'Overview' }, icon: LayoutGrid, active: location === '/admin' },
    { href: '/admin/requests', label: { ar: 'الطلبات', en: 'Requests' }, icon: Inbox, active: location.startsWith('/admin/requests') },
  ];
  return (
    <div className="min-h-[100dvh] bg-background lg:grid lg:grid-cols-[260px_1fr]">
      <aside className="sticky top-0 hidden h-[100dvh] flex-col bg-sidebar text-sidebar-foreground lg:flex">
        <div className="flex items-center gap-3 px-6 py-6">
          <LogoMark />
          <div>
            <div className="font-display text-sm font-bold">{t({ ar: 'لوحة مروان', en: 'Marwan’s dashboard' })}</div>
            <div className="text-[11px] text-sidebar-foreground/55">{t({ ar: 'طلبات المشاريع', en: 'Project requests' })}</div>
          </div>
        </div>
        <SaduBand className="!h-2 opacity-80" />
        <nav className="mt-6 flex flex-col gap-1 px-3">
          {nav.map((n) => (
            <Link key={n.href} href={n.href} data-testid={`link-admin-${n.href}`} className={cn('flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-colors', n.active ? 'bg-sidebar-primary text-sidebar-primary-foreground' : 'text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground')}>
              <n.icon className="h-4 w-4" />
              {t(n.label)}
            </Link>
          ))}
          <Link href="/" className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-sidebar-foreground/75 hover:bg-sidebar-accent">
            <ExternalLink className="h-4 w-4" />
            {t({ ar: 'الموقع العام', en: 'Public site' })}
          </Link>
        </nav>
        <div className="mt-auto space-y-3 border-t border-sidebar-border p-4">
          <LangToggle light />
          {email && <div className="num truncate text-xs text-sidebar-foreground/55">{email}</div>}
          <button type="button" onClick={signOut} data-testid="button-admin-signout" className="flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-sm text-sidebar-foreground/75 hover:bg-sidebar-accent">
            <LogOut className="h-4 w-4" />
            {t({ ar: 'تسجيل الخروج', en: 'Sign out' })}
          </button>
        </div>
      </aside>

      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex items-center justify-between gap-3 bg-sidebar px-4 py-3 text-sidebar-foreground lg:hidden">
          <Link href="/admin" className="flex items-center gap-2">
            <LogoMark className="h-9 w-9" />
            <span className="font-display text-sm font-bold">{t({ ar: 'لوحة مروان', en: 'Marwan’s dashboard' })}</span>
          </Link>
          <div className="flex items-center gap-2">
            <LangToggle light />
            <button type="button" onClick={signOut} aria-label={t({ ar: 'تسجيل الخروج', en: 'Sign out' })} className="grid h-10 w-10 place-items-center rounded-full border border-sidebar-border">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </header>
        <nav className="sticky top-[64px] z-20 flex gap-1 border-b border-border bg-background/90 px-4 py-2 backdrop-blur lg:hidden">
          {nav.map((n) => (
            <Link key={n.href} href={n.href} className={cn('flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-sm font-medium', n.active ? 'bg-foreground text-background' : 'text-muted-foreground')}>
              <n.icon className="h-4 w-4" />
              {t(n.label)}
            </Link>
          ))}
        </nav>
        <main className="mx-auto max-w-6xl px-4 py-6 md:px-8 md:py-10">{children}</main>
      </div>
    </div>
  );
}

export function StatusPill({ className, children }: { className?: string; children: ReactNode }) {
  return <span className={cn('inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-semibold', className)}>{children}</span>;
}
