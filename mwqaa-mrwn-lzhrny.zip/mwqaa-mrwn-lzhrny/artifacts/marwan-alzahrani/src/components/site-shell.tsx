import { useEffect, useState, type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { AnimatePresence, motion } from 'framer-motion';
import { Menu, X, ArrowUpLeft, ArrowUpRight, MessagesSquare } from 'lucide-react';
import { useLang } from '@/lib/i18n';
import { SERVICES } from '@/lib/content';
import { SaduBand, Wordmark } from './brand';
import { cn } from '@/lib/utils';
import { conversationsHref, useConversationSummaries } from '@/lib/conversations';

export function LangToggle({ className, light }: { className?: string; light?: boolean }) {
  const { lang, toggle } = useLang();
  return (
    <button
      type="button"
      onClick={toggle}
      data-testid="button-lang-toggle"
      aria-label={lang === 'ar' ? 'التبديل إلى الإنجليزية' : 'Switch to Arabic'}
      className={cn(
        'inline-flex h-10 items-center gap-1 rounded-full border px-1 text-xs font-semibold transition-colors',
        light ? 'border-[hsl(var(--wool)/0.25)] text-[hsl(var(--wool))]' : 'border-border bg-card',
        className,
      )}
    >
      <span className={cn('rounded-full px-2.5 py-1.5 transition-colors', lang === 'ar' && 'bg-foreground text-background')}>ع</span>
      <span className={cn('rounded-full px-2.5 py-1.5 transition-colors', lang === 'en' && 'bg-foreground text-background')}>EN</span>
    </button>
  );
}

export function Arrow({ className }: { className?: string }) {
  const { dir } = useLang();
  return dir === 'rtl' ? <ArrowUpLeft className={className} /> : <ArrowUpRight className={className} />;
}

const NAV = [
  { href: '/#services', label: { ar: 'الخدمات', en: 'Services' } },
  { href: '/#work', label: { ar: 'أعمالي', en: 'Work' } },
  { href: '/#about', label: { ar: 'عنّي', en: 'About' } },
  { href: '/community', label: { ar: 'ركن المجتمع', en: 'Community' } },
  { href: '/tasbeeh', label: { ar: 'السبحة', en: 'Tasbeeh' } },
  { href: '/account', label: { ar: 'حسابي', en: 'My account' } },
];

function Header() {
  const { t } = useLang();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();
  const { saved, unread } = useConversationSummaries();
  const myConversation = conversationsHref(saved);

  useEffect(() => setOpen(false), [location]);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 12);
    on();
    window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);

  return (
    <header className={cn('sticky top-0 z-40 transition-all', scrolled ? 'bg-background/85 backdrop-blur-md shadow-[0_1px_0_hsl(var(--border))]' : 'bg-transparent')}>
      <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between gap-4 px-5 md:px-8">
        <Link href="/" data-testid="link-home" className="rounded-xl">
          <Wordmark />
        </Link>
        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => (
            <a key={n.href} href={`${import.meta.env.BASE_URL.replace(/\/$/, '')}${n.href}`} data-testid={`link-nav-${n.href}`} className="rounded-full px-4 py-2 text-sm font-medium text-foreground/80 transition-colors hover:bg-muted hover:text-foreground">
              {t(n.label)}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          {saved.length > 0 && (
            <Link href={myConversation} data-testid="link-header-conversation" className="relative grid h-10 w-10 place-items-center rounded-full border border-border bg-card" aria-label={t({ ar: 'محادثتي', en: 'My conversation' })}>
              <MessagesSquare className="h-5 w-5" />
              {unread > 0 && <span className="absolute -end-1 -top-1 grid min-h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">{unread > 9 ? '9+' : unread}</span>}
            </Link>
          )}
          <LangToggle />
          <Link href="/request" data-testid="link-header-request" className="hidden h-10 items-center gap-2 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5 sm:inline-flex">
            {t({ ar: 'ابدأ مشروعك', en: 'Start a project' })}
          </Link>
          <button type="button" onClick={() => setOpen((o) => !o)} data-testid="button-menu" aria-label={t(open ? { ar: 'إغلاق القائمة', en: 'Close menu' } : { ar: 'فتح القائمة', en: 'Open menu' })} className="grid h-10 w-10 place-items-center rounded-full border border-border bg-card lg:hidden">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="border-t border-border bg-background px-5 pb-6 pt-3 lg:hidden"
          >
            {NAV.map((n, i) => (
              <motion.a
                key={n.href}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04 }}
                href={`${import.meta.env.BASE_URL.replace(/\/$/, '')}${n.href}`}
                onClick={() => setOpen(false)}
                className="flex items-center justify-between border-b border-border/70 py-4 font-display text-xl font-semibold"
              >
                {t(n.label)}
                <Arrow className="h-5 w-5 text-primary" />
              </motion.a>
            ))}
            <Link href={myConversation} onClick={() => setOpen(false)} className="flex items-center justify-between border-b border-border/70 py-4 font-display text-xl font-semibold">
              {t({ ar: 'محادثتي', en: 'My conversation' })}
              {unread > 0 && <span className="rounded-full bg-primary px-2 py-0.5 text-xs text-primary-foreground">{unread > 9 ? '9+' : unread}</span>}
            </Link>
            <Link href="/request" className="mt-5 flex h-12 items-center justify-center rounded-full bg-primary font-semibold text-primary-foreground">
              {t({ ar: 'ابدأ مشروعك', en: 'Start a project' })}
            </Link>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

function ConversationDock({ hidden }: { hidden: boolean }) {
  const { t } = useLang();
  const { saved, unread } = useConversationSummaries();
  if (hidden) return null;
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:inset-x-auto md:bottom-6 md:end-6 md:px-0 md:pb-0">
      <div className={cn('mx-auto flex max-w-md items-center gap-2 rounded-full border border-[hsl(var(--wool)/0.12)] bg-[hsl(var(--ink))] p-1.5 text-[hsl(var(--wool))] shadow-xl md:rounded-full', saved.length === 0 && 'md:hidden')}>
        <Link href="/request" data-testid="link-dock-request" className="flex h-12 flex-1 items-center justify-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground md:hidden">
          {t({ ar: 'ابدأ مشروعك', en: 'Start a project' })}
        </Link>
        {saved.length > 0 && (
          <Link href={conversationsHref(saved)} data-testid="link-dock-conversation" className="relative flex h-12 flex-1 items-center justify-center gap-2 rounded-full px-5 text-sm font-semibold transition-colors hover:bg-[hsl(var(--wool)/0.1)]">
            <MessagesSquare className="h-5 w-5" />
            {t({ ar: 'محادثتي', en: 'My conversation' })}
            {unread > 0 && <span className="grid min-h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">{unread > 9 ? '9+' : unread}</span>}
          </Link>
        )}
      </div>
    </div>
  );
}

function Footer() {
  const { t, lang } = useLang();
  const { saved } = useConversationSummaries();
  return (
    <footer className="relative mt-24 bg-[hsl(var(--ink))] pb-10 text-[hsl(var(--wool))]">
      <SaduBand />
      <div className="sadu-diamonds">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-[1.4fr_1fr_1fr] md:px-8">
          <div>
            <Wordmark light />
            <p className="mt-5 max-w-sm text-sm leading-7 text-[hsl(var(--wool)/0.7)]">
              {t({
                ar: 'مطوّر مواقع وتطبيقات من السعودية. أتابع كل مشروع بنفسي، من أول رسالة حتى ما بعد الإطلاق.',
                en: 'Web & mobile developer from Saudi Arabia. I handle every client personally — from the first message to after launch.',
              })}
            </p>
            <p className="mt-6 max-w-sm text-sm leading-7 text-[hsl(var(--wool)/0.7)]">{t({ ar: 'يجري التواصل وتبادل الردود داخل الموقع عبر صفحة محادثة خاصة.', en: 'Project messages and replies stay on a private conversation page here on the site.' })}</p>
          </div>
          <div>
            <h4 className={cn('mb-4 text-xs font-semibold uppercase text-[hsl(var(--saffron))]', lang === 'en' && 'tracking-widest')}>{t({ ar: 'الخدمات', en: 'Services' })}</h4>
            <ul className="space-y-2.5 text-sm">
              {SERVICES.map((s) => (
                <li key={s.slug}>
                  <Link href={`/services/${s.slug}`} className="text-[hsl(var(--wool)/0.8)] hover:text-[hsl(var(--wool))]">{t(s.name)}</Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className={cn('mb-4 text-xs font-semibold uppercase text-[hsl(var(--saffron))]', lang === 'en' && 'tracking-widest')}>{t({ ar: 'روابط', en: 'Links' })}</h4>
            <ul className="space-y-2.5 text-sm">
              <li><Link href="/request" className="text-[hsl(var(--wool)/0.8)] hover:text-[hsl(var(--wool))]">{t({ ar: 'ابدأ مشروعك', en: 'Start a project' })}</Link></li>
              <li><Link href={conversationsHref(saved)} className="text-[hsl(var(--wool)/0.8)] hover:text-[hsl(var(--wool))]">{t({ ar: 'محادثتي', en: 'My conversation' })}</Link></li>
              <li><Link href="/community" className="text-[hsl(var(--wool)/0.8)] hover:text-[hsl(var(--wool))]">{t({ ar: 'ركن المجتمع', en: 'Community corner' })}</Link></li>
              <li><Link href="/tasbeeh" className="text-[hsl(var(--wool)/0.8)] hover:text-[hsl(var(--wool))]">{t({ ar: 'السبحة الذكية', en: 'Smart Tasbeeh' })}</Link></li>
              <li><Link href="/toolbox" data-testid="link-footer-toolbox" className="text-[hsl(var(--wool)/0.8)] hover:text-[hsl(var(--wool))]">{t({ ar: 'أدوات المشروع', en: 'Project tools' })}</Link></li>
              <li><Link href="/quality-lab" data-testid="link-footer-quality-lab" className="text-[hsl(var(--wool)/0.8)] hover:text-[hsl(var(--wool))]">{t({ ar: 'مختبر الجودة', en: 'Quality lab' })}</Link></li>
              <li><Link href="/account" className="text-[hsl(var(--wool)/0.8)] hover:text-[hsl(var(--wool))]">{t({ ar: 'حساب العميل', en: 'Customer account' })}</Link></li>
            </ul>
          </div>
        </div>
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-3 border-t border-[hsl(var(--wool)/0.1)] px-5 py-6 text-xs text-[hsl(var(--wool)/0.55)] sm:flex-row sm:items-center md:px-8">
          <span>
            <span className="num">© {new Date().getFullYear()}</span> {lang === 'ar' ? 'مروان الزهراني' : 'Marwan Alzahrani'}
          </span>
        </div>
      </div>
    </footer>
  );
}

export function SiteShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const hideDock = location === '/request' || location.startsWith('/c') || location.startsWith('/demo/') || location === '/learning-lab' || location === '/tasbeeh';
  useEffect(() => {
    if (!window.location.hash) window.scrollTo(0, 0);
    else {
      const el = document.getElementById(window.location.hash.slice(1));
      if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth' }), 80);
    }
  }, [location]);
  return (
    <div className="flex min-h-[100dvh] flex-col">
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
      <ConversationDock hidden={hideDock} />
    </div>
  );
}
