import { useState } from 'react';
import { BookOpen, ExternalLink, Headphones, LoaderCircle, ShieldCheck } from 'lucide-react';
import { useLang } from '@/lib/i18n';

type Recitation = {
  id: string;
  surah: number;
  from: number;
  to: number;
  titleAr: string;
  titleEn: string;
  source: string;
};

type RecordedAyah = { numberInSurah: number; text: string; audio: string };

const RECITATIONS: Recitation[] = [
  { id: 'names', surah: 59, from: 22, to: 24, titleAr: 'آيات الأسماء الحسنى — الحشر ٢٢–٢٤', titleEn: 'Names of Allah — Al-Hashr 59:22–24', source: 'https://quran.com/59/22' },
  { id: 'kursi', surah: 2, from: 255, to: 255, titleAr: 'آية الكرسي — البقرة ٢٥٥', titleEn: 'Ayat al-Kursi — Al-Baqarah 2:255', source: 'https://quran.com/2/255' },
  { id: 'ikhlas', surah: 112, from: 1, to: 4, titleAr: 'سورة الإخلاص — ١١٢', titleEn: 'Surah Al-Ikhlas — 112', source: 'https://quran.com/112' },
];

const COMMON_NAMES_99 = [
  'الرحمن', 'الرحيم', 'الملك', 'القدوس', 'السلام', 'المؤمن', 'المهيمن', 'العزيز', 'الجبار', 'المتكبر',
  'الخالق', 'البارئ', 'المصور', 'الغفار', 'القهار', 'الوهاب', 'الرزاق', 'الفتاح', 'العليم', 'القابض',
  'الباسط', 'الخافض', 'الرافع', 'المعز', 'المذل', 'السميع', 'البصير', 'الحكم', 'العدل', 'اللطيف',
  'الخبير', 'الحليم', 'العظيم', 'الغفور', 'الشكور', 'العلي', 'الكبير', 'الحفيظ', 'المقيت', 'الحسيب',
  'الجليل', 'الكريم', 'الرقيب', 'المجيب', 'الواسع', 'الحكيم', 'الودود', 'المجيد', 'الباعث', 'الشهيد',
  'الحق', 'الوكيل', 'القوي', 'المتين', 'الولي', 'الحميد', 'المحصي', 'المبدئ', 'المعيد', 'المحيي',
  'المميت', 'الحي', 'القيوم', 'الواجد', 'الماجد', 'الواحد', 'الأحد', 'الصمد', 'القادر', 'المقتدر',
  'المقدم', 'المؤخر', 'الأول', 'الآخر', 'الظاهر', 'الباطن', 'الوالي', 'المتعالي', 'البر', 'التواب',
  'المنتقم', 'العفو', 'الرؤوف', 'مالك الملك', 'ذو الجلال والإكرام', 'المقسط', 'الجامع', 'الغني', 'المغني', 'المانع',
  'الضار', 'النافع', 'النور', 'الهادي', 'البديع', 'الباقي', 'الوارث', 'الرشيد', 'الصبور',
];

const AUTHENTIC_ADHKAR = [
  {
    id: 'subhan-100',
    ar: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
    detailAr: 'ورد الحث على قولها مئة مرة في اليوم.',
    en: 'The Prophet encouraged saying it one hundred times a day.',
    ref: 'صحيح البخاري ٦٤٠٥',
    url: 'https://sunnah.com/bukhari:6405',
  },
  {
    id: 'tahlil-100',
    ar: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    detailAr: 'ورد فضل قولها مئة مرة في اليوم.',
    en: 'A narration describes the virtue of saying it one hundred times a day.',
    ref: 'صحيح البخاري ٦٤٠٣',
    url: 'https://sunnah.com/bukhari:6403',
  },
];

function isTrustedAudioUrl(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && url.hostname === 'cdn.islamic.network' && url.pathname.startsWith('/quran/audio/');
  } catch {
    return false;
  }
}

export function TasbeehRecitationLibrary() {
  const { t } = useLang();
  const [selected, setSelected] = useState(RECITATIONS[0].id);
  const [ayahs, setAyahs] = useState<RecordedAyah[]>([]);
  const [loadedFor, setLoadedFor] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const passage = RECITATIONS.find((item) => item.id === selected) ?? RECITATIONS[0];

  const loadRecording = async () => {
    setLoading(true);
    setError('');
    setAyahs([]);
    setLoadedFor('');
    try {
      const response = await fetch(`https://api.alquran.cloud/v1/surah/${passage.surah}/ar.alafasy`);
      if (!response.ok) throw new Error('request');
      const payload = await response.json() as {
        code?: number;
        data?: { ayahs?: Array<{ numberInSurah?: number; text?: string; audio?: string }> };
      };
      if (payload.code !== 200 || !Array.isArray(payload.data?.ayahs)) throw new Error('response');
      const selectedAyahs = payload.data.ayahs
        .filter((ayah) => Number(ayah.numberInSurah) >= passage.from && Number(ayah.numberInSurah) <= passage.to)
        .map((ayah) => ({ numberInSurah: Number(ayah.numberInSurah), text: String(ayah.text ?? ''), audio: ayah.audio ?? '' }));
      if (selectedAyahs.length !== passage.to - passage.from + 1 || selectedAyahs.some((ayah) => !ayah.text || !isTrustedAudioUrl(ayah.audio))) {
        throw new Error('audio');
      }
      setAyahs(selectedAyahs);
      setLoadedFor(passage.id);
    } catch {
      setError(t({ ar: 'تعذّر جلب التسجيل الآن. جرّب لاحقًا أو افتح النص من مصدر القرآن.', en: 'The recording could not be loaded. Try again later or open the passage at its Quran source.' }));
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="verified-recitation" data-testid="section-tasbeeh-recitation" aria-labelledby="recitation-heading" className="mx-auto mt-8 max-w-5xl scroll-mt-28 rounded-[1.6rem] border border-card-border bg-card p-5 shadow-sm sm:p-7">
      <div className="flex items-start gap-3">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><Headphones className="h-5 w-5" aria-hidden="true" /></span>
        <div>
          <h2 id="recitation-heading" className="font-display text-xl font-bold">{t({ ar: 'تلاوة مسجّلة بصوت قارئ حقيقي', en: 'Recorded recitation by a real Quran reciter' })}</h2>
          <p className="mt-1 text-sm leading-6 text-muted-foreground">{t({ ar: 'اختر مقطعًا ثم حمّل التلاوة المسجّلة للشيخ مشاري العفاسي. هذا تسجيل قرآن حقيقي، وليس صوتًا آليًا؛ ولا يكرّر العدّاد نطقًا مصطنعًا عند الضغط.', en: 'Choose a passage and load Mishary Alafasy’s recorded recitation. This is an actual Quran recording, not synthetic speech; the counter does not produce artificial speech on each tap.' })}</p>
        </div>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
        <label className="grid gap-2 text-sm font-semibold">
          {t({ ar: 'المقطع القرآني', en: 'Quran passage' })}
          <select data-testid="select-recorded-quran" value={selected} onChange={(event) => { setSelected(event.target.value); setAyahs([]); setLoadedFor(''); setError(''); }} className="h-11 rounded-xl border border-input bg-background px-3">
            {RECITATIONS.map((item) => <option key={item.id} value={item.id}>{t({ ar: item.titleAr, en: item.titleEn })}</option>)}
          </select>
        </label>
        <button type="button" data-testid="button-load-quran-recording" onClick={() => void loadRecording()} disabled={loading} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-foreground px-5 text-sm font-semibold text-background disabled:opacity-60">
          {loading ? <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden="true" /> : <BookOpen className="h-4 w-4" aria-hidden="true" />}
          {loading ? t({ ar: 'جارٍ جلب التسجيل…', en: 'Loading recording…' }) : t({ ar: loadedFor === selected ? 'إعادة تحميل التلاوة' : 'حمّل التلاوة', en: loadedFor === selected ? 'Reload recitation' : 'Load recitation' })}
        </button>
      </div>

      <p data-testid="text-recitation-source" className="mt-3 text-xs leading-5 text-muted-foreground">
        {t({ ar: 'المصدر الصوتي: AlQuran Cloud — إصدار العفاسي. لا يُطلب حساب. عند التحميل يتصل المتصفح بالمصدر لجلب نص الآيات وروابط التسجيل، ويُحمّل الصوت من خادمه عند التشغيل.', en: 'Audio source: AlQuran Cloud — Alafasy edition. No account is required. Loading contacts the source for verse text and recording links; audio streams from its host when played.' })}
      </p>
      <a data-testid="link-full-quran" href="https://quran.com/" target="_blank" rel="noreferrer" className="mt-3 inline-flex min-h-10 items-center gap-2 rounded-full border border-primary/25 bg-primary/[.04] px-4 text-sm font-semibold text-primary underline-offset-4 hover:underline">
        {t({ ar: 'افتح المصحف كاملًا على Quran.com', en: 'Open the full Quran at Quran.com' })}
        <ExternalLink className="h-4 w-4" aria-hidden="true" />
      </a>
      {error && <p role="alert" data-testid="error-quran-recording" className="mt-3 rounded-xl bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}
      {ayahs.length > 0 && loadedFor === selected && (
        <div data-testid="list-recorded-ayahs" className="mt-5 space-y-3">
          {ayahs.map((ayah) => (
            <article key={ayah.numberInSurah} data-testid={`card-recorded-ayah-${ayah.numberInSurah}`} className="rounded-xl border border-border bg-background p-4">
              <p dir="rtl" lang="ar" data-testid={`text-recorded-ayah-${ayah.numberInSurah}`} className="font-display text-lg leading-9">{ayah.text}<span className="num ms-2 inline-flex h-7 min-w-7 items-center justify-center rounded-full bg-muted px-2 text-xs">{ayah.numberInSurah}</span></p>
              <audio data-testid={`audio-recorded-ayah-${ayah.numberInSurah}`} controls preload="none" src={ayah.audio} className="mt-3 h-10 w-full" aria-label={t({ ar: `تلاوة الآية ${ayah.numberInSurah} بصوت مشاري العفاسي`, en: `Ayah ${ayah.numberInSurah} recited by Mishary Alafasy` })} />
            </article>
          ))}
        </div>
      )}

      <div id="religious-sources" className="mt-6 scroll-mt-28 border-t border-border pt-5">
        <h2 className="font-display text-xl font-bold">{t({ ar: 'النصوص والأدلة', en: 'Texts and references' })}</h2>
        <p className="mt-1 text-xs leading-5 text-muted-foreground">{t({ ar: 'افتح مرجع النص للتثبت من ألفاظه وسياقه. قائمة الأسماء المشهورة هنا ليست ترتيبًا منصوصًا عليه في الحديث.', en: 'Open each source to review its wording and context. The commonly circulated names list is not presented as a hadith-prescribed sequence.' })}</p>
        <div className="mt-4 grid gap-5 lg:grid-cols-2">
        <section data-testid="section-names-of-allah" aria-labelledby="names-heading">
          <h3 id="names-heading" className="font-display font-bold">{t({ ar: 'الأسماء الحسنى — قائمة مشهورة', en: 'The Beautiful Names — a widely circulated list' })}</h3>
          <p className="mt-1 text-xs leading-5 text-muted-foreground">{t({ ar: 'ثبوت أن لله تسعةً وتسعين اسمًا ورد في الحديث، لكن تعداد هذه الأسماء بهذا الترتيب ليس نص الحديث نفسه؛ هذه قائمة مشهورة للتعلّم، فراجع مصادرها.', en: 'A hadith affirms that Allah has 99 names, but this enumeration and order are not the hadith’s own wording. This is a commonly circulated study list; consult the sources.' })}</p>
          <details data-testid="details-names-of-allah" className="mt-3 rounded-xl border border-border bg-background p-3">
            <summary className="cursor-pointer text-sm font-semibold">{t({ ar: `عرض الأسماء (${COMMON_NAMES_99.length})`, en: `Show names (${COMMON_NAMES_99.length})` })}</summary>
            <div className="mt-3 flex flex-wrap gap-2">{COMMON_NAMES_99.map((name, index) => <span key={`${index}-${name}`} data-testid={`name-of-allah-${index + 1}`} lang="ar" dir="rtl" className="rounded-full border border-border bg-card px-3 py-1.5 text-sm">{name}</span>)}</div>
          </details>
          <div className="mt-3 flex flex-wrap gap-3">
            <a data-testid="link-quran-names-source" href="https://quran.com/7/180" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary underline underline-offset-4">{t({ ar: 'الأسماء الحسنى في القرآن ٧:١٨٠', en: 'Beautiful Names in Quran 7:180' })}<ExternalLink className="h-3 w-3" aria-hidden="true" /></a>
            <a data-testid="link-hadith-ninety-nine-names" href="https://sunnah.com/bukhari:2736" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary underline underline-offset-4">{t({ ar: 'حديث التسعة والتسعين — البخاري ٢٧٣٦', en: 'Hadith of the 99 names — Bukhari 2736' })}<ExternalLink className="h-3 w-3" aria-hidden="true" /></a>
          </div>
        </section>

        <section data-testid="section-authentic-adhkar" aria-labelledby="adhkar-sources-heading">
          <h3 id="adhkar-sources-heading" className="font-display font-bold">{t({ ar: 'أذكار مع تخريجها', en: 'Dhikr with hadith references' })}</h3>
          <p className="mt-1 text-xs leading-5 text-muted-foreground">{t({ ar: 'هذه النصوص مرتبطة بمراجع الحديث؛ التسجيلات الصوتية لها غير متاحة هنا بعد، لذلك لا نستبدلها بنطق آلي.', en: 'These texts link to hadith references. Their recordings are not available here yet, so we do not substitute synthetic speech.' })}</p>
          <div className="mt-3 space-y-2">
            {AUTHENTIC_ADHKAR.map((item) => (
              <article key={item.id} data-testid={`card-authentic-dhikr-${item.id}`} className="rounded-xl border border-border bg-background p-3">
                <p lang="ar" dir="rtl" className="text-sm font-semibold leading-7">{item.ar}</p>
                <p className="mt-1 text-xs leading-5 text-muted-foreground">{t({ ar: item.detailAr, en: item.en })}</p>
                <a data-testid={`link-hadith-${item.id}`} href={item.url} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-primary underline underline-offset-4">{item.ref}<ExternalLink className="h-3 w-3" aria-hidden="true" /></a>
              </article>
            ))}
          </div>
        </section>
        </div>
      </div>

      <p data-testid="notice-recitation-scope" className="mt-5 flex items-start gap-2 border-t border-border pt-4 text-xs leading-5 text-muted-foreground">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
        {t({ ar: 'التلاوة اختيارية وتبدأ بضغطك على مشغّل الصوت. محتوى الحديث يُفتح في مصدره، ولا يوجد ادعاء بتسجيلات صوتية للأذكار غير المتحقّق منها.', en: 'Recitation is optional and starts only when you press play. Hadith content opens at its source; no unverified dhikr recordings are presented.' })}
      </p>
    </section>
  );
}
