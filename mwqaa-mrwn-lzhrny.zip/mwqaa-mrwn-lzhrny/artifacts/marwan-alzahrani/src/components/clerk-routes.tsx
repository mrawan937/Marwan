import { lazy, useEffect, useRef, type ReactNode } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { arSA } from '@clerk/localizations';
import { Link, Route, Switch, useLocation } from 'wouter';
import { LogoMark, SaduBand } from '@/components/brand';
import { LangToggle } from '@/components/site-shell';
import { useLang } from '@/lib/i18n';

const AdminOverview = lazy(() => import('@/pages/admin/overview'));
const AdminRequests = lazy(() => import('@/pages/admin/requests'));
const AdminRequestDetail = lazy(() => import('@/pages/admin/request-detail'));
const CustomerAccount = lazy(() => import('@/pages/account'));

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: 'hsl(4 72% 46%)',
    colorForeground: 'hsl(234 45% 14%)',
    colorMutedForeground: 'hsl(234 16% 36%)',
    colorDanger: 'hsl(356 70% 42%)',
    colorBackground: 'hsl(40 55% 97%)',
    colorInput: 'hsl(38 45% 94%)',
    colorInputForeground: 'hsl(234 45% 14%)',
    colorNeutral: 'hsl(234 30% 30%)',
    fontFamily: "'IBM Plex Sans Arabic', 'IBM Plex Sans', system-ui, sans-serif",
    borderRadius: '0.85rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[hsl(40_55%_97%)] rounded-[1.75rem] w-[420px] max-w-full overflow-hidden border border-[hsl(34_24%_82%)] shadow-[0_30px_70px_-24px_hsl(234_45%_14%/0.34)]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: "text-[hsl(234_45%_14%)] font-bold text-2xl [font-family:'Alexandria',sans-serif]",
    headerSubtitle: 'text-[hsl(234_16%_36%)]',
    socialButtonsBlockButtonText: 'text-[hsl(234_45%_14%)] font-medium',
    formFieldLabel: 'text-[hsl(234_45%_14%)] font-semibold',
    footerActionLink: 'text-[hsl(4_72%_46%)] font-semibold',
    footerActionText: 'text-[hsl(234_16%_36%)]',
    dividerText: 'text-[hsl(234_16%_36%)]',
    identityPreviewEditButton: 'text-[hsl(4_72%_46%)]',
    formFieldSuccessText: 'text-[hsl(168_40%_30%)]',
    alertText: 'text-[hsl(234_45%_14%)]',
    logoBox: 'justify-center h-14',
    logoImage: 'h-14 w-14',
    socialButtonsBlockButton: 'border border-[hsl(34_22%_74%)] bg-[hsl(40_55%_97%)] rounded-xl',
    formButtonPrimary: 'bg-[hsl(4_72%_46%)] text-[hsl(38_60%_97%)] rounded-full h-11 font-semibold shadow-none',
    formFieldInput: 'bg-[hsl(38_45%_94%)] border border-[hsl(34_22%_74%)] text-[hsl(234_45%_14%)] rounded-xl h-11',
    footerAction: 'bg-transparent',
    dividerLine: 'bg-[hsl(34_24%_80%)]',
    alert: 'bg-[hsl(4_72%_46%/0.08)] border border-[hsl(4_72%_46%/0.25)] rounded-xl',
    otpCodeFieldInput: 'border border-[hsl(34_22%_74%)] text-[hsl(234_45%_14%)] rounded-lg',
    formFieldRow: 'gap-3',
    main: 'gap-5',
  },
};

function AuthFrame({ children }: { children: ReactNode }) {
  const { t } = useLang();
  return (
    <div className="grid min-h-[100dvh] bg-background lg:grid-cols-[1fr_1.1fr]">
      <aside className="relative hidden flex-col justify-between overflow-hidden bg-[hsl(var(--ink))] p-12 text-[hsl(var(--wool))] lg:flex">
        <div className="sadu-diamonds absolute inset-0" />
        <Link href="/" className="relative flex items-center gap-3">
          <LogoMark className="h-12 w-12" />
          <span className="font-display text-lg font-bold">
            {t({ ar: 'مروان الزهراني', en: 'Marwan Alzahrani' })}
          </span>
        </Link>
        <div className="relative">
          <h1 className="font-display text-5xl font-extrabold leading-tight">
            {t({ ar: 'تابع مشروعك.', en: 'Follow your project.' })}
            <span className="block text-[hsl(var(--saffron))]">
              {t({ ar: 'كل التفاصيل في مكان واحد.', en: 'Every detail in one place.' })}
            </span>
          </h1>
          <p className="mt-5 max-w-md leading-8 text-[hsl(var(--wool)/0.7)]">
            {t({
              ar: 'سجّل الدخول لمتابعة طلباتك والتواصل بشأنها عبر محادثة خاصة.',
              en: 'Sign in to follow your requests and discuss them in a private conversation.',
            })}
          </p>
        </div>
        <SaduBand className="relative -mx-12 !w-[calc(100%+6rem)]" />
      </aside>
      <div className="flex flex-col">
        <div className="flex items-center justify-between p-5">
          <Link
            href="/"
            className="text-sm font-medium text-muted-foreground hover:text-foreground"
          >
            {t({ ar: 'العودة إلى الموقع', en: 'Back to site' })}
          </Link>
          <LangToggle />
        </div>
        <div className="flex flex-1 items-center justify-center px-4 pb-12">
          {children}
        </div>
      </div>
    </div>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        qc.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);

  return null;
}

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

function ClerkRoutes() {
  const [, setLocation] = useLocation();
  const { lang } = useLang();

  const localization =
    lang === 'ar'
      ? {
          ...arSA,
          formFieldInputPlaceholder__emailAddress: 'أدخل بريدك الإلكتروني',
          formFieldInputPlaceholder__password: 'أدخل كلمة المرور',
          signIn: {
            ...arSA.signIn,
            start: {
              ...arSA.signIn?.start,
               title: 'أهلًا بك',
               subtitle: 'سجّل الدخول لمتابعة طلباتك ومحادثاتك.',
            },
          },
          signUp: {
            ...arSA.signUp,
            start: {
              ...arSA.signUp?.start,
               title: 'إنشاء حساب',
               subtitle: 'أنشئ حسابًا لمتابعة طلباتك ومحادثاتك.',
            },
          },
        }
      : {
          signIn: {
            start: {
               title: 'Welcome back',
               subtitle: 'Sign in to follow your requests and conversations.',
            },
          },
          signUp: {
            start: {
               title: 'Create an account',
               subtitle: 'Create an account to follow your requests and conversations.',
            },
          },
        };

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      signInFallbackRedirectUrl={`${basePath}/admin`}
      signUpFallbackRedirectUrl={`${basePath}/admin`}
      localization={localization}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <ClerkQueryClientCacheInvalidator />
      <Switch>
        <Route path="/account" component={CustomerAccount} />
        <Route path="/admin" component={AdminOverview} />
        <Route path="/admin/requests" component={AdminRequests} />
        <Route path="/admin/requests/:id" component={AdminRequestDetail} />
        <Route
          path="/sign-in/*?"
          component={() => (
            <AuthFrame>
              <SignIn
                routing="path"
                path={`${basePath}/sign-in`}
                signUpUrl={`${basePath}/sign-up`}
              />
            </AuthFrame>
          )}
        />
        <Route
          path="/sign-up/*?"
          component={() => (
            <AuthFrame>
              <SignUp
                routing="path"
                path={`${basePath}/sign-up`}
                signInUrl={`${basePath}/sign-in`}
              />
            </AuthFrame>
          )}
        />
      </Switch>
    </ClerkProvider>
  );
}

export default ClerkRoutes;