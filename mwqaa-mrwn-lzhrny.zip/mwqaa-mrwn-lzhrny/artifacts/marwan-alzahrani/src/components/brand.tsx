import type { ServiceType } from '@workspace/api-client-react';
import { cn } from '@/lib/utils';
import { useLang } from '@/lib/i18n';

export const asset = (p: string) => `${import.meta.env.BASE_URL}${p}`;

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={cn('h-10 w-10 shrink-0', className)} aria-hidden="true">
      <rect width="64" height="64" rx="16" fill="hsl(var(--ink))" />
      <path d="M0 52 L8 44 L16 52 L24 44 L32 52 L40 44 L48 52 L56 44 L64 52 L64 64 L0 64 Z" fill="hsl(var(--sadu))" />
      <path d="M15 42 V20 L32 34 L49 20 V42" fill="none" stroke="hsl(var(--wool))" strokeWidth="6" strokeLinecap="square" />
      <rect x="28.5" y="9" width="7" height="7" transform="rotate(45 32 12.5)" fill="hsl(var(--saffron))" />
    </svg>
  );
}

export function Wordmark({ className, light }: { className?: string; light?: boolean }) {
  const { lang } = useLang();
  return (
    <span className={cn('flex items-center gap-2.5', className)}>
      <LogoMark />
      <span className="leading-none">
        <span className={cn('block font-display text-[1.05rem] font-bold tracking-tight', light ? 'text-[hsl(var(--wool))]' : 'text-foreground')}>
          {lang === 'ar' ? 'مروان الزهراني' : 'Marwan Alzahrani'}
        </span>
        <span className={cn('mt-1 block text-[0.68rem] font-medium', light ? 'text-[hsl(var(--wool)/0.65)]' : 'text-muted-foreground')}>
          {lang === 'ar' ? 'Marwan Alzahrani' : 'مروان الزهراني'}
        </span>
      </span>
    </span>
  );
}

/* ——— Custom service glyphs: drawn on a 48 grid, 2.5 stroke, with a Sadu-diamond accent ——— */
const stroke = { fill: 'none', stroke: 'currentColor', strokeWidth: 2.5, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };

function Diamond({ x, y, s = 5 }: { x: number; y: number; s?: number }) {
  return <rect x={x - s / 2} y={y - s / 2} width={s} height={s} transform={`rotate(45 ${x} ${y})`} fill="hsl(var(--sadu))" />;
}

export function ServiceIcon({ type, className }: { type: ServiceType; className?: string }) {
  const cls = cn('h-10 w-10', className);
  switch (type) {
    case 'business_website':
      return (
        <svg viewBox="0 0 48 48" className={cls} aria-hidden="true">
          <path {...stroke} d="M6 14h36v24H6z" />
          <path {...stroke} d="M6 20h36" />
          <path {...stroke} d="M12 8l4 6M24 6v8M36 8l-4 6" />
          <path {...stroke} d="M12 27h10M12 32h6" />
          <path {...stroke} d="M29 26h7v7h-7z" />
          <Diamond x={24} y={43} />
        </svg>
      );
    case 'booking_system':
      return (
        <svg viewBox="0 0 48 48" className={cls} aria-hidden="true">
          <path {...stroke} d="M7 11h34v29H7z" />
          <path {...stroke} d="M7 19h34M15 6v8M33 6v8" />
          <path {...stroke} d="M13 25h4M22 25h4M31 25h4M13 32h4M22 32h4" />
          <Diamond x={33} y={33} s={7} />
        </svg>
      );
    case 'mobile_app':
      return (
        <svg viewBox="0 0 48 48" className={cls} aria-hidden="true">
          <path {...stroke} d="M14 5h16a3 3 0 0 1 3 3v32a3 3 0 0 1-3 3H14a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3z" />
          <path {...stroke} d="M19 38h6" />
          <path {...stroke} d="M37 17c2.5 2 4 4.5 4 7s-1.5 5-4 7M37 21c1 .8 1.5 1.9 1.5 3s-.5 2.2-1.5 3" />
          <Diamond x={22} y={20} s={7} />
        </svg>
      );
    case 'ui_ux_design':
      return (
        <svg viewBox="0 0 48 48" className={cls} aria-hidden="true">
          <path {...stroke} d="M6 8h22v16H6zM6 30h12v10H6zM24 30h18v10H24z" />
          <path {...stroke} d="M34 6l8 8-12 12h-8v-8z" />
          <Diamond x={14} y={16} s={6} />
        </svg>
      );
    case 'maintenance':
      return (
        <svg viewBox="0 0 48 48" className={cls} aria-hidden="true">
          <path {...stroke} d="M29 7a9 9 0 0 0-8 12L8 32a4 4 0 0 0 6 6l13-13a9 9 0 0 0 12-8l-6 2-4-4z" />
          <path {...stroke} d="M30 34l4 4 8-8" />
          <Diamond x={11} y={35} s={4} />
        </svg>
      );
    case 'community_package':
      return (
        <svg viewBox="0 0 48 48" className={cls} aria-hidden="true">
          <path {...stroke} d="M8 22L24 9l16 13" />
          <path {...stroke} d="M12 19v20h24V19" />
          <path {...stroke} d="M24 36s-7-4-7-9a3.5 3.5 0 0 1 7-1 3.5 3.5 0 0 1 7 1c0 5-7 9-7 9z" />
          <Diamond x={24} y={4} s={4} />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 48 48" className={cls} aria-hidden="true">
          <circle {...stroke} cx="24" cy="24" r="16" />
          <path {...stroke} d="M24 16v16M16 24h16" />
          <Diamond x={24} y={4} s={4} />
        </svg>
      );
  }
}

/* Contact glyphs */
export function WhatsAppGlyph({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={cn('h-5 w-5', className)} aria-hidden="true">
      <path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.6 0-3.1-.4-4.4-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.7-1.4.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3c-.2.3-.9.9-.9 2.2s.9 2.5 1 2.7c.1.2 1.8 2.8 4.4 3.9 1.6.7 2.3.8 3.1.6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1 0-.3-.1-.5-.2z" />
    </svg>
  );
}
export function PhoneGlyph({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={cn('h-5 w-5', className)} aria-hidden="true">
      <path {...stroke} strokeWidth={1.9} d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z" />
    </svg>
  );
}
export function MailGlyph({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={cn('h-5 w-5', className)} aria-hidden="true">
      <path {...stroke} strokeWidth={1.9} d="M3 6h18v12H3z" />
      <path {...stroke} strokeWidth={1.9} d="M3 7l9 6 9-6" />
    </svg>
  );
}

export function SaduBand({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn('sadu-band w-full', className)} />;
}
