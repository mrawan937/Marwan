import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { X } from 'lucide-react';
import { asset } from '@/components/brand';
import { useLang } from '@/lib/i18n';

const SCENE_DURATION = 4800;
const EASE = [0.22, 1, 0.36, 1] as const;

type Copy = { ar: string; en: string };

const SCENES: Array<{ eyebrow: Copy; title: Copy; body: Copy }> = [
  {
    eyebrow: { ar: 'مروان الزهراني · أعمال رقمية', en: 'Marwan Alzahrani · Digital work' },
    title: { ar: 'أهلًا بك', en: 'Welcome' },
    body: { ar: 'من الفكرة إلى تجربة رقمية واضحة', en: 'From an idea to a clear digital experience' },
  },
  {
    eyebrow: { ar: '01 / الفكرة', en: '01 / THE IDEA' },
    title: { ar: 'الفكرة تأخذ شكلًا', en: 'An idea takes shape' },
    body: { ar: 'بنية واضحة، وتجربة سهلة.', en: 'A clear structure. An effortless experience.' },
  },
  {
    eyebrow: { ar: '02 / ما نبنيه', en: '02 / WHAT WE BUILD' },
    title: { ar: 'مواقع. تجارب. أنظمة.', en: 'Websites. Experiences. Systems.' },
    body: { ar: 'كل خدمة تبدأ بفهم احتياج مشروعك.', en: 'Every project starts by understanding your needs.' },
  },
  {
    eyebrow: { ar: '03 / التفاصيل', en: '03 / THE DETAILS' },
    title: { ar: 'كل تفصيل له مكان.', en: 'Every detail has a place.' },
    body: { ar: 'تصميم مدروس، واهتمام من أول خطوة حتى الإطلاق.', en: 'Thoughtful design, from the first step to launch.' },
  },
  {
    eyebrow: { ar: 'مروان الزهراني', en: 'MARWAN ALZAHRANI' },
    title: { ar: 'فكرتك، بتجربة تليق بها.', en: 'Your idea, brought to life.' },
    body: { ar: 'استكشف الأعمال والخدمات وابدأ مشروعك.', en: 'Explore the work, discover the services, start your project.' },
  },
];

const SERVICES: Copy[] = [
  { ar: 'مواقع', en: 'Websites' },
  { ar: 'تجارب', en: 'Experiences' },
  { ar: 'أنظمة', en: 'Systems' },
];

function SceneArtwork({ index, lang }: { index: number; lang: 'ar' | 'en' }) {
  if (index === 0) {
    return (
      <div className="welcome-mark-stage" aria-hidden="true">
        <div className="welcome-mark-orbit welcome-mark-orbit-one" />
        <div className="welcome-mark-orbit welcome-mark-orbit-two" />
        <div className="welcome-mark-diamond" />
        <img src={asset('logo.svg')} alt="" className="welcome-mark-image" />
        <div className="welcome-mark-sadu" />
      </div>
    );
  }
  if (index === 1) {
    return (
      <div className="welcome-browser-art" aria-hidden="true">
        <div className="welcome-browser">
          <div className="welcome-browser-bar"><i /><i /><i /><span /></div>
          <div className="welcome-browser-content">
            <div className="welcome-browser-copy">
              <b />
              <strong />
              <strong />
              <small />
              <small />
              <em />
            </div>
            <div className="welcome-browser-image"><span /></div>
          </div>
        </div>
        <div className="welcome-browser-phone"><span /><b /><i /><i /><em /></div>
      </div>
    );
  }
  if (index === 2) {
    return (
      <div className="welcome-service-art" dir={lang === 'ar' ? 'rtl' : 'ltr'} aria-hidden="true">
        {SERVICES.map((service, i) => (
          <div className={`welcome-service-tile welcome-service-tile-${i + 1}`} key={service.en}>
            <span>0{i + 1}</span>
            <b>{service[lang]}</b>
            <i className={`welcome-service-glyph welcome-service-glyph-${i + 1}`} />
          </div>
        ))}
      </div>
    );
  }
  if (index === 3) {
    return (
      <div className="welcome-detail-art" aria-hidden="true">
        <div className="welcome-detail-sheet welcome-detail-sheet-back">
          <span>MA / SPECIMEN</span><b>م</b><i /><i />
        </div>
        <div className="welcome-detail-sheet welcome-detail-sheet-front">
          <span>BOOKING FLOW</span>
          <div className="welcome-detail-grid">{Array.from({ length: 6 }, (_, i) => <i key={i} />)}</div>
          <b /><b />
        </div>
        <div className="welcome-detail-thread" />
      </div>
    );
  }
  return (
    <div className="welcome-final-mark" aria-hidden="true">
      <div className="welcome-final-orbit" />
      <img src={asset('logo.svg')} alt="" />
      <span>MARWAN<br />ALZAHRANI</span>
    </div>
  );
}

export function WelcomeIntro() {
  const { lang } = useLang();
  const reduceMotion = useReducedMotion();
  const closeRef = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(() => {
    if (typeof window === 'undefined') return false;
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    return !reduce;
  });
  const [scene, setScene] = useState(0);

  useEffect(() => {
    if (reduceMotion && open) setOpen(false);
  }, [open, reduceMotion]);

  useEffect(() => {
    if (!open) return;
    document.body.style.overflow = 'hidden';
    closeRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(() => {
      if (scene < SCENES.length - 1) setScene((current) => current + 1);
      else setOpen(false);
    }, SCENE_DURATION);
    return () => window.clearTimeout(timer);
  }, [open, scene]);

  if (!open) return null;
  const copy = SCENES[scene];

  return (
    <div
      className={`welcome-intro ${scene === 1 || scene === 4 ? 'welcome-intro-ink' : scene === 2 ? 'welcome-intro-carmine' : ''}`}
      role="dialog"
      aria-modal="true"
      aria-label={lang === 'ar' ? 'ترحيب بموقع مروان الزهراني' : 'Welcome to Marwan Alzahrani’s website'}
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
      data-testid="welcome-intro"
    >
      <div className="welcome-grain" aria-hidden="true" />
      <button
        ref={closeRef}
        type="button"
        onClick={() => setOpen(false)}
        className="welcome-skip"
        aria-label={lang === 'ar' ? 'تخطي المقدمة والدخول إلى الموقع' : 'Skip intro and enter the website'}
        data-testid="button-skip-intro"
      >
        <span>{lang === 'ar' ? 'تخطي المقدمة' : 'Skip intro'}</span>
        <X aria-hidden="true" />
      </button>
      <div className="welcome-frame">
        <div className="welcome-topline">
          <span>{lang === 'ar' ? 'مروان الزهراني' : 'MARWAN ALZAHRANI'}</span>
          <span className="welcome-scene-number">0{scene + 1} <i /> 05</span>
        </div>

        <AnimatePresence mode="wait" initial={false}>
          <motion.main
            className={`welcome-scene welcome-scene-${scene + 1}`}
            key={scene}
            initial={reduceMotion ? false : { opacity: 0, y: 16, scale: 0.985 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={reduceMotion ? undefined : { opacity: 0, y: -12, scale: 1.012 }}
            transition={{ duration: 0.52, ease: EASE }}
          >
            <div className="welcome-copy">
              <p className="welcome-eyebrow">{copy.eyebrow[lang]}</p>
              <h1>{copy.title[lang]}</h1>
              <p className="welcome-description">{copy.body[lang]}</p>
            </div>
            <SceneArtwork index={scene} lang={lang} />
          </motion.main>
        </AnimatePresence>

        <div className="welcome-footer">
          <span>{lang === 'ar' ? 'من الفكرة إلى تجربة رقمية واضحة' : 'BUILT AROUND YOUR IDEA'}</span>
          <span className="welcome-progress-label">{lang === 'ar' ? 'استكشف الموقع' : 'EXPLORE THE SITE'} <b>↗</b></span>
        </div>
      </div>
      <div className="welcome-progress-track" aria-hidden="true">
        <motion.div
          key={`progress-${scene}`}
          className="welcome-progress"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: SCENE_DURATION / 1000, ease: 'linear' }}
        />
      </div>
    </div>
  );
}

export function BrandedLoading() {
  const { lang } = useLang();
  return (
    <div className="brand-loading" role="status" aria-live="polite" data-testid="status-page-loading">
      <img src={asset('logo.svg')} alt="" aria-hidden="true" />
      <div className="brand-loading-copy">
        <strong>{lang === 'ar' ? 'مروان الزهراني' : 'Marwan Alzahrani'}</strong>
        <span>{lang === 'ar' ? 'لحظات ونبدأ…' : 'Just a moment…'}</span>
      </div>
      <div className="brand-loading-rule" aria-hidden="true"><i /></div>
    </div>
  );
}
