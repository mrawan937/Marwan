import { lazy, Suspense, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { LangProvider } from '@/lib/i18n';
import { BrandedLoading, WelcomeIntro } from '@/components/welcome-intro';

const NotFound = lazy(() => import('@/pages/not-found'));
const Home = lazy(() => import('@/pages/home'));
const ServicePage = lazy(() => import('@/pages/service'));
const RequestPage = lazy(() => import('@/pages/request'));
const ConversationsPage = lazy(() => import('@/pages/conversations'));
const ConversationPage = lazy(() => import('@/pages/conversation'));
const Community = lazy(() => import('@/pages/community'));
const Tasbeeh = lazy(() => import('@/pages/tasbeeh'));
const BookingDemo = lazy(() => import('@/pages/demo-booking'));
const CafeDemo = lazy(() => import('@/pages/demo-cafe'));
const LearningLab = lazy(() => import('@/pages/learning-lab'));
const Toolbox = lazy(() => import('@/pages/toolbox'));
const QualityLab = lazy(() => import('@/pages/quality-lab'));
const PricingCalculator = lazy(() => import('@/pages/pricing-calculator'));
const ProductCopyBuilder = lazy(() => import('@/pages/product-copy-builder'));
const SharePreview = lazy(() => import('@/pages/share-preview'));
const ClerkRoutes = lazy(() => import('@/components/clerk-routes'));

const queryClient = new QueryClient({
  defaultOptions: { queries: { refetchOnWindowFocus: false, retry: 1 } },
});
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function Router() {
  const [location] = useLocation();
  const showWelcome = location === '/' && !(typeof window !== 'undefined' && window.location.hash);
  return (
    <RoutedErrorBoundary>
      {showWelcome && <WelcomeIntro />}
      <Suspense
        fallback={<BrandedLoading />}
      >
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/services/:slug" component={ServicePage} />
          <Route path="/request" component={RequestPage} />
          <Route path="/c" component={ConversationsPage} />
          <Route path="/c/:token" component={ConversationPage} />
          <Route path="/community" component={Community} />
          <Route path="/tasbeeh" component={Tasbeeh} />
          <Route path="/demo/booking" component={BookingDemo} />
          <Route path="/demo/cafe" component={CafeDemo} />
          <Route path="/learning-lab" component={LearningLab} />
          <Route path="/toolbox" component={Toolbox} />
          <Route path="/quality-lab" component={QualityLab} />
          <Route path="/pricing-calculator" component={PricingCalculator} />
          <Route path="/product-copy" component={ProductCopyBuilder} />
          <Route path="/share-preview" component={SharePreview} />
          <Route path="/account" component={ClerkRoutes} />
          <Route path="/admin" component={ClerkRoutes} />
          <Route path="/admin/requests" component={ClerkRoutes} />
          <Route path="/admin/requests/:id" component={ClerkRoutes} />
          <Route path="/sign-in/*?" component={ClerkRoutes} />
          <Route path="/sign-up/*?" component={ClerkRoutes} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <LangProvider>
          <WouterRouter base={basePath}>
            <Router />
          </WouterRouter>
        </LangProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;