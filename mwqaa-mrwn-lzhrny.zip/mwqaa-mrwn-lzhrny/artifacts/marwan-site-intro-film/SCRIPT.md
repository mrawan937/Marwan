# افتتاحية الموقع — مروان الزهراني

## Director's treatment

- **Promise:** A distinctive welcome into Marwan's digital world: idea, design, and a clear experience, carried by the real brand.
- **Identity:** Supplied Sadu Ink palette: indigo `#1A1F4A`, wool `#F6F0E4`, Sadu carmine `#C3352B`, saffron `#F4B52E`. Alexandria for Arabic display, IBM Plex Sans for supporting copy, IBM Plex Mono for technical annotations.
- **Hero:** The exact supplied Marwan Alzahrani logo; its saffron diamond becomes the seed from which the film's visual world unfolds.
- **Motion:** Sadu thread drawing, interface forms opening and reflowing, compound aperture/split transitions that carry the same diamond.
- **Arc:** A warm welcome becomes a glimpse of digital craft and services, then closes on the actual brand lockup.
- **Payoff:** The closing mark collapses to the same saffron spark and wool field as the opener, allowing the website overlay to loop smoothly while preserving the parent's skip control outside the film.
- **Format/runtime:** 16:9 landscape, 24 seconds; Arabic-first with a small English counterpart, designed as a cinematic first-visit welcome film.

## Timeline

| Shot | Time | Focus | Main action | Composition / handoff |
| --- | --- | --- | --- | --- |
| 01 | 0.00–4.00 | «أهلًا بك» and the first spark | Diamond strikes, woven strokes build a frame, welcome resolves | Asymmetric wool canvas; diamond opens into indigo aperture |
| 02 | 4.00–9.00 | An idea becoming a clear experience | Browser and mobile compositions unfold from one thread | Indigo macro-to-wide site study; frame edge becomes split |
| 03 | 9.00–14.00 | Websites, experiences, digital systems | Three kinetic words drive three distinct interface transformations | Carmine multi-panel montage; moving diamond exits to gallery |
| 04 | 14.00–19.00 | Range and care across digital touchpoints | Layout, mobile, and flow artifacts orbit and settle into a design world | Wool gallery planes; planes fold to logo's crown |
| 05 | 19.00–24.00 | The actual identity and welcome takeaway | Official logo and bilingual name resolve, hold, then loop to opening | Centered indigo lockup, structurally distinct from prior scenes |

## Shot-by-shot script

### Shot 01 / 0.00–4.00s / 4.00s — «أهلًا بك»

**Purpose:** Make the visitor feel welcomed immediately and establish the real brand's visual signature.

**Exact content and holds:** `أهلًا بك` begins revealing at 0.36s, resolves by 1.08s, and remains through 3.25s. `مروان الزهراني` begins at 1.06s and resolves by 1.56s, holding through 3.40s. Small `MARWAN ALZAHRANI` begins at 0.18s and resolves by 0.73s, holding through 3.40s.

**Composition and artistic idea:** Wool-colored field. A saffron diamond snaps just right of center; the Arabic welcome owns the left half, with indigo and carmine Sadu diagonals woven through the right. The lines form an aperture rather than ornamental backdrop. Soft paper-like light, low grain.

**Timed choreography:** 0.00–0.20s: the saffron spark is visible immediately, snapping from 0.18 to 1.0 scale; the outlined Sadu diamond sits behind it. 0.22–0.70s: two Sadu thread paths trace outward from the spark. 0.36–1.08s: Arabic welcome unmasks upward. 0.18–0.73s: Latin name settles in the eyebrow zone; 1.06–1.56s: Arabic name resolves below. 1.30–2.35s: the final Sadu path folds into an indigo circle. 2.35–3.35s: a short camera push draws focus to the aperture center; thread continues to wrap the circle. 3.35–4.00s: aperture swells through the lens, with its diamond center preserved.

**Transition contract:** Aperture scales to fill the frame; Shot 02 opens on the same dark circle and exact saffron center point. Compound handoff: circle scale-through plus two Sadu strokes splitting outward.

**Assets and technique:** Supplied official mark copied unchanged to `public/images/marwan-mark.svg`; custom SVG thread paths; locally loaded Alexandria and IBM Plex Sans.

**Sound intent:** Instrumental score only, warm first impact and a clear musical lift toward the aperture. Beat alignment unverified until the generated bed is measured.

### Shot 02 / 4.00–9.00s / 5.00s — «الفكرة تأخذ شكلًا»

**Purpose:** Suggest the designed experience visitors are about to enter, not a generic loading screen or fabricated project screenshot.

**Exact content and holds:** `الفكرة تأخذ شكلًا` begins at 4.34s, resolves by 5.06s, and holds through 8.58s. `بنية واضحة، وتجربة سهلة.` begins at 4.94s and holds through 8.58s. Small `A DIGITAL EXPERIENCE` appears from 4.18s through 8.25s. `STRUCTURE / CLARITY / CARE` appears from 5.35s, resolves by 5.75s, and holds through the outgoing cut.

**Composition and artistic idea:** Deep indigo stage, with a large browser-like canvas right of center and a slim mobile silhouette behind it. Arabic phrase occupies a left text column. A saffron thread physically connects the large and small frames, and layout blocks reflow between them as one continuous design.

**Timed choreography:** 0.00–0.50s: incoming aperture opens and tilts; a split indigo panel is visible behind it. 0.35–1.15s: browser frame pulls back from extreme crop to 72% of frame height, the mobile silhouette unfolding in parallax. 0.68–1.35s: headline resolves by a vertical mask. 1.48–2.50s: image and content regions draw into browser; same regions snap into stacked mobile proportions. 2.60–3.30s: saffron thread draws toward a second interface plane; microcopy arrives along its route. 3.55–4.25s: browser reflows from wide editorial layout to a more compact page arrangement. 4.30–5.00s: carmine panel pivots toward camera and crosses the lens as a moving plane.

**Transition contract:** Frame edge sweeps out and becomes the first vertical shutter of Shot 03. Compound handoff: perspective flip plus panel wipe; saffron thread carries through the cut.

**Assets and technique:** Original abstract SVG/CSS interface study only; no fabricated client work, numbers, logos, prices, or performance claims. Staggered type masks, perspective frames, continuous thread path.

**Sound intent:** Instrumental score; the frame landing and exit are intended to meet strong accents. No VO or SFX requested.

### Shot 03 / 9.00–14.00s / 5.00s — «من التصميم إلى الاستخدام»

**Purpose:** Show the breadth of Marwan's stated digital work through distinct visual forms.

**Exact content and holds:** `مواقع` resolves by 9.38s, `تجارب` resolves by 10.89s, and `أنظمة` resolves by 12.20s; each remains until the next word's 0.38s replacement. Associated labels `WEB` / `UI · UX` / `BOOKING` arrive with their respective word and remain until it changes. `تخدم الفكرة بوضوح` begins at 12.95s and resolves by 13.23s, holding through 13.72s.

**Composition and artistic idea:** Carmine stage cut into three indigo vertical shutters. A hero word (30vmin) belongs to each shutter; a saffron tile dashes across and transforms the same abstract interface from a page to a mobile experience to a booking grid. The text and artifacts never compete for the same zone.

**Timed choreography:** 0.00–0.24s: inherited panel opens into three shutters; first word fires within 40ms of the final shutter reveal. 0.24–1.16s: page-frame strokes draw around `مواقع`. 1.18–1.44s: short split shear transfers camera to the mobile shutter; `تجارب` stamps on and frame content reflows. 1.52–2.50s: layout blocks respond in three beats, moving with the saffron tile. 2.56–2.84s: whip to the final panel, calendar frame forms around the tile. 2.92–3.84s: `أنظمة` settles; a booking grid resolves sequentially. 3.90–4.32s: shutters pull back to a continuous wide strip; final phrase clips on. 4.32–5.00s: panels fold inward around the diamond, which exits toward a cream field.

**Transition contract:** Saffron tile becomes the pin for Shot 04's orbiting gallery; compound shutter collapse and a centerward whip keep it in motion across the boundary.

**Assets and technique:** SVG/CSS line-drawn illustrative page, mobile frame, and calendar; type scale 30vmin for hero words; word changes are short, stable reads. No interface elements are interactive.

**Sound intent:** Three transformations land on rhythmic musical accents; exact onset alignment checked after the track exists.

### Shot 04 / 14.00–19.00s / 5.00s — «كل تفصيل له مكان»

**Purpose:** Give the entrance film a crafted, dimensional bridge from service range to the person behind the brand.

**Exact content and holds:** `كل تفصيل` and `له مكان.` begin together at 14.28s, resolve by 14.86s, and hold through 18.60s. Labels `LAYOUT`, `MOBILE`, `FLOW` begin sequentially at 15.12s, 16.04s, 16.94s and each is replaced by the next at the corresponding beat.

**Composition and artistic idea:** Wool gallery with three distinct planes: cropped Arabic type specimen at left, mobile composition at rear center, and compact booking-flow tile at right foreground. The planes orbit around a persistent Sadu diamond, connected by fine thread. Captions stay in clear negative space instead of sitting on the panels.

**Timed choreography:** 0.00–0.64s: central diamond grows from incoming tile; planes hinge open at differing depths. 0.60–1.30s: type specimen turns toward camera and first phrase masks on. 1.34–2.12s: mobile plane pushes forward; visual blocks switch order once; second phrase completes. 2.15–3.00s: booking-flow tile pivots to frontal view and stages connect one-by-one; its micro label arrives. 3.00–3.72s: camera arcs around the group to reveal a shared Sadu thread. 3.72–4.30s: all planes settle into one clear composition and hold briefly. 4.30–5.00s: planes fold in sequence around the diamond; saffron tile locks into the logo-crown position.

**Transition contract:** Folds close around the exact saffron crown point; Shot 05 starts with that diamond at logo coordinates. Compound handoff: multi-plane fold plus wool-to-indigo iris.

**Assets and technique:** Original CSS/SVG planes and thin path annotations; controlled perspective with restrained depth. No client project is implied by these illustrations.

**Sound intent:** A measured lift on the planes settling; cadence clears space for the wordmark. No VO/SFX requested.

### Shot 05 / 19.00–24.00s / 5.00s — «مروان الزهراني»

**Purpose:** Conclude the welcome with the supplied identity at readable scale, not another service beat.

**Exact content and holds:** Official logo begins at 19.14s and resolves by 19.86s; Arabic name begins at 19.42s and resolves by 20.08s; Latin name begins at 19.68s and resolves by 20.14s. `من الفكرة إلى تجربة رقمية واضحة` begins at 20.12s and resolves by 20.52s. `BUILT AROUND YOUR IDEA` appears in the lower-left microtype zone. All lockup copy holds until the compressing transition starts at 22.65s.

**Composition and artistic idea:** Full indigo field, palette inversion. The exact supplied SVG mark is centered above bilingual wordmark; no added mark or changed logo colors. Deliberate negative space replaces the busy forms of the middle. A single thin wool orbit stays behind, never crossing the logo or words.

**Timed choreography:** 0.14–0.86s: inherited diamond expands to the actual official mark geometry; original carmine base, wool M, and saffron crown remain untouched. 0.42–1.08s: Arabic name resolves through a vertical mask; Latin counterpart settles at 0.68–1.14s. 0.86–1.32s: saffron rule traces below the wordmark. 1.12–1.52s: takeaway appears as one stable line. 1.52–3.65s: lockup read; one orbiting stroke draws behind without crossing the mark or words. 3.65–4.45s: the line turns into the opener's diagonal, wordmark and mark compress toward its crown. 4.53–5.00s: indigo iris recedes to wool, leaving the exact initial saffron spark at the same coordinates and size.

**Transition contract:** Last frame matches Shot 01 first frame—wool field and saffron diamond in the same position, size, and color. Compound handoff: logo compresses into crown diamond while the indigo field closes as an iris from 23.53s to 24.00s, leaving no dead tail.

**Assets and technique:** Exact mark at `public/images/marwan-mark.svg`; wordmark typeset in Alexandria; deterministic masks and scale motion, no added logo artwork.

**Sound intent:** Instrumental score resolves seamlessly to the opening pulse. No voiceover and no extra effects requested.

## Pre-code review

- The film is a proper website welcome, not a loading placeholder: it opens with «أهلًا بك», gives a concise view of digital craft, and resolves on the actual identity.
- Adjacent shots vary framing, scale, palette, and mechanic: woven aperture, pulled-back interface, kinetic multi-panel word montage, orbiting gallery, centered end lockup.
- Illustrative screens are original, abstract studies; there are no fabricated case studies, client names, claims, prices, or performance data.
- Each shot has multiple timed changes and outgoing motion in its final fifth. The opener's first second contains a spark and greeting; the outro returns to that exact image for an intentional loop.
- Hero words use 30vmin scale, normal headlines 7–11vmin, support 3–3.5vmin, micro-labels at least 1.9vmin, all within safe insets.

## Audio spec

- Runtime: 24 s (scene durations total).
- Music: original locally synthesized cinematic minimal piano, warm plucked strings, and restrained hand percussion; 120 BPM with a half-time feel, welcoming, intimate, and quietly confident; no vocals. Accent notes at 4.00s (site reveal), 9.00s (service montage), 14.00s (gallery), and 19.00s (official identity); resolved loop-compatible ending.
- Voiceover: none requested.
- SFX: none requested.
- Playback file: `public/audio/bg_music.mp3`.
- Beat alignment: measured the bed in 50 ms RMS windows. Positive RMS jumps at the authored cut points are approximately +9.94 dB at 4.00s, +4.57 dB at 9.00s, +7.85 dB at 14.00s, and +4.36 dB at 19.00s. Cuts remain at 4.00 / 9.00 / 14.00 / 19.00 seconds.
