import { useState } from 'react';
import { motion } from 'framer-motion';
import { useSceneTimer } from '@/lib/video';

const EASE = [0.22, 1, 0.36, 1] as const;

export function Scene5() {
  const [closing, setClosing] = useState(false);
  const [loopPoint, setLoopPoint] = useState(false);
  useSceneTimer([
    { time: 3650, callback: () => setClosing(true) },
    { time: 4530, callback: () => setLoopPoint(true) },
  ]);

  return (
    <motion.section
      className="absolute inset-0 overflow-hidden"
      initial={{ opacity: 0.84, scale: 1.04, backgroundColor: '#1a1f4a' }}
      animate={{
        opacity: 1,
        scale: 1,
        backgroundColor: loopPoint ? '#f6f0e4' : '#1a1f4a',
      }}
      exit={{ opacity: 0, scale: 1.04 }}
      transition={{ duration: loopPoint ? 0.46 : 0.56, ease: EASE }}
    >
      <motion.div
        className="absolute left-1/2 top-1/2 h-[72vmin] w-[72vmin] -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#f6f0e4]/10"
        animate={{ opacity: loopPoint ? 0 : 1, rotate: 360, scale: loopPoint ? 0.5 : 1 }}
        transition={{ opacity: { duration: 0.22 }, scale: { duration: 0.6, ease: EASE }, rotate: { duration: 42, repeat: Infinity, ease: 'linear' } }}
      />
      <motion.div
        className="absolute left-1/2 top-1/2 h-[58vmin] w-[58vmin] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-[#f4b52e]/30"
        animate={{ opacity: loopPoint ? 0 : 0.8, rotate: -360 }}
        transition={{ opacity: { duration: 0.22 }, rotate: { duration: 34, repeat: Infinity, ease: 'linear' } }}
      />

      <motion.div
        className="absolute left-1/2 top-1/2 z-10 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center text-center"
        animate={{
          opacity: closing ? 0 : 1,
          scale: closing ? 0.1 : 1,
          x: closing ? '22vw' : 0,
          y: closing ? '3vh' : 0,
        }}
        transition={{ duration: closing ? 0.5 : 0.56, ease: EASE }}
      >
        <motion.img
          src={`${import.meta.env.BASE_URL}images/marwan-mark.svg`}
          alt="شعار مروان الزهراني"
          className="h-[18vmin] w-[18vmin] object-contain"
          initial={{ scale: 0.46, rotate: -12, opacity: 0 }}
          animate={{ scale: 1, rotate: 0, opacity: 1 }}
          transition={{ duration: 0.72, delay: 0.14, ease: EASE }}
        />
        <motion.h1
          className="scene-copy mb-0 mt-[2.1vmin] text-[5.7vmin] font-semibold leading-[1.4] tracking-[-.035em] text-[#f6f0e4]"
          dir="rtl"
          initial={{ opacity: 0, y: 22, clipPath: 'inset(100% 0 0 0)' }}
          animate={{ opacity: 1, y: 0, clipPath: 'inset(0 0 0 0)' }}
          transition={{ duration: 0.66, delay: 0.42, ease: EASE }}
        >
          مروان الزهراني
        </motion.h1>
        <motion.p
          className="scene-body mb-0 mt-[.7vmin] text-[2.4vmin] tracking-[.08em] text-[#f6f0e4]/55"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.46, delay: 0.68, ease: EASE }}
        >
          MARWAN ALZAHRANI
        </motion.p>
        <motion.div
          className="mt-[2.3vmin] h-[.45vmin] w-[11vmin] bg-[#f4b52e]"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: closing ? 0 : 1 }}
          transition={{ duration: 0.46, delay: 0.86, ease: EASE }}
        />
        <motion.p
          className="scene-body mb-0 mt-[1.9vmin] text-[3vmin] text-[#f6f0e4]/76"
          dir="rtl"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: closing ? 0 : 1, y: 0 }}
          transition={{ duration: 0.4, delay: 1.12, ease: EASE }}
        >
          من الفكرة إلى تجربة رقمية واضحة
        </motion.p>
      </motion.div>

      <motion.div
        className="pointer-events-none absolute left-[calc(72%-0.55vmin)] top-[calc(45%-0.55vmin)] z-20 h-[1.1vmin] w-[1.1vmin] rotate-45 bg-[#f4b52e]"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: loopPoint ? 1 : 0, opacity: loopPoint ? 1 : 0 }}
        transition={{ duration: 0.26, ease: EASE }}
        aria-hidden="true"
      />

      <motion.div
        className="scene-mono absolute bottom-[6vh] left-[6vw] text-[1.8vmin] text-[#f6f0e4]/28"
        animate={{ opacity: loopPoint ? 0 : 1 }}
        transition={{ duration: 0.2 }}
      >
        BUILT AROUND YOUR IDEA
      </motion.div>
    </motion.section>
  );
}
