import { motion } from 'framer-motion';

const EASE = [0.22, 1, 0.36, 1] as const;

export function Scene1() {
  return (
    <motion.section
      className="scene-wool scene-safe absolute inset-0 overflow-hidden"
      initial={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
      animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
      exit={{ opacity: 0, scale: 1.055, filter: 'blur(10px)' }}
      transition={{ duration: 0.58, ease: EASE }}
    >
      <div className="absolute inset-0 opacity-[.22]" aria-hidden="true">
        <div className="absolute left-[6vw] top-[8vh] h-[.45vmin] w-[18vw] bg-[#c3352b]" />
        <div className="absolute bottom-[9vh] right-[5vw] h-[.45vmin] w-[16vw] bg-[#1a1f4a]" />
        <span className="scene-mono absolute bottom-[7.2vh] left-[6vw] text-[1.8vmin]">01 / WELCOME</span>
      </div>

      <div className="relative z-10 flex h-full items-center">
        <div className="relative z-20 ml-[3vw] w-[51vw]">
          <motion.p
            className="scene-mono mb-[2.3vmin] text-[2vmin] text-[#c3352b]"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.55, delay: 0.18, ease: EASE }}
          >
            MARWAN ALZAHRANI
          </motion.p>
          <motion.h1
            className="scene-copy m-0 max-w-[50vw] text-[10.2vmin] font-semibold leading-[1.34] tracking-[-.045em]"
            dir="rtl"
            initial={{ clipPath: 'inset(100% 0 0 0)' }}
            animate={{ clipPath: 'inset(0% 0 0 0)' }}
            transition={{ duration: 0.72, delay: 0.36, ease: EASE }}
          >
            أهلًا بك
            <span className="mr-[.12em] text-[#c3352b]">.</span>
          </motion.h1>
          <motion.p
            className="scene-body mt-[2.4vmin] text-[3.2vmin] font-medium text-[#1a1f4a]/70"
            dir="rtl"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.06, ease: EASE }}
          >
            مروان الزهراني
          </motion.p>
        </div>

        <div className="absolute right-[7vw] top-1/2 h-[55vmin] w-[40vw] -translate-y-1/2">
          <motion.div
            className="absolute left-[29%] top-[17%] h-[27vmin] w-[27vmin] rotate-45 border-[.72vmin] border-[#1a1f4a]"
            initial={{ scale: 0.82, opacity: 0.35 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 280, damping: 22, delay: 0.18 }}
          />
          <motion.div
            className="absolute left-[calc(29%+9.2vmin)] top-[calc(17%+9.2vmin)] h-[8.6vmin] w-[8.6vmin] rotate-45 bg-[#f4b52e]"
            initial={{ scale: 0.18, opacity: 1 }}
            animate={{ scale: [0.16, 1.08, 1], opacity: 1 }}
            transition={{ type: 'spring', stiffness: 310, damping: 19, delay: 0.06 }}
          />
          <svg className="absolute inset-0 h-full w-full overflow-visible" viewBox="0 0 720 600" fill="none" aria-hidden="true">
            <motion.path
              d="M48 420 L170 298 L290 418 L410 298 L532 420 L652 300"
              stroke="#C3352B"
              strokeWidth="8"
              strokeLinecap="square"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 1 }}
              transition={{ duration: 0.72, delay: 0.26, ease: EASE }}
            />
            <motion.path
              d="M90 510 L210 390 L330 510 L450 390 L570 510"
              stroke="#1A1F4A"
              strokeWidth="5"
              strokeLinecap="square"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 0.62 }}
              transition={{ duration: 0.72, delay: 0.48, ease: EASE }}
            />
            <motion.circle
              cx="362"
              cy="344"
              r="94"
              stroke="#1A1F4A"
              strokeWidth="2"
              initial={{ pathLength: 0, rotate: -65 }}
              animate={{ pathLength: 0.74, rotate: 0 }}
              transition={{ duration: 1.1, delay: 1.3, ease: EASE }}
            />
          </svg>
          <motion.div
            className="absolute left-[53%] top-[38%] h-[15vmin] w-[15vmin] rounded-full bg-[#1a1f4a]"
            initial={{ scale: 0 }}
            animate={{ scale: [0, 1, 1.18] }}
            transition={{ duration: 0.9, delay: 2.72, ease: EASE }}
          />
          <motion.div
            className="absolute left-[calc(53%+6.3vmin)] top-[calc(38%+6.3vmin)] z-10 h-[2.3vmin] w-[2.3vmin] rotate-45 bg-[#f4b52e]"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 280, damping: 18, delay: 2.84 }}
          />
        </div>
      </div>

      <motion.div
        className="pointer-events-none absolute inset-0 z-30 bg-[#1a1f4a]"
        initial={{ clipPath: 'circle(0% at 64% 50%)' }}
        animate={{ clipPath: ['circle(0% at 64% 50%)', 'circle(0% at 64% 50%)', 'circle(0% at 64% 50%)'] }}
        exit={{ clipPath: 'circle(150% at 64% 50%)' }}
        transition={{ duration: 0.42, ease: EASE }}
        aria-hidden="true"
      />
    </motion.section>
  );
}
