import { useState } from 'react';
import { motion } from 'framer-motion';
import { useSceneTimer } from '@/lib/video';

const EASE = [0.22, 1, 0.36, 1] as const;
const TAGS = ['LAYOUT', 'MOBILE', 'FLOW'];

export function Scene4() {
  const [tagIndex, setTagIndex] = useState(-1);
  useSceneTimer([
    { time: 1120, callback: () => setTagIndex(0) },
    { time: 2040, callback: () => setTagIndex(1) },
    { time: 2940, callback: () => setTagIndex(2) },
  ]);

  return (
    <motion.section
      className="scene-wool absolute inset-0 overflow-hidden"
      initial={{ opacity: 0.8, clipPath: 'circle(20% at 52% 50%)', rotateZ: -1.4 }}
      animate={{ opacity: 1, clipPath: 'circle(150% at 52% 50%)', rotateZ: 0 }}
      exit={{ opacity: 0, scale: 0.95, clipPath: 'inset(0 50% 0 50%)' }}
      transition={{ duration: 0.64, ease: EASE }}
    >
      <div className="absolute inset-0 opacity-[.11]" aria-hidden="true">
        <div className="absolute left-[11vw] top-[10vh] h-[1px] w-[78vw] bg-[#1a1f4a]" />
        <div className="absolute bottom-[12vh] left-[11vw] h-[1px] w-[78vw] bg-[#1a1f4a]" />
      </div>
      <motion.div
        className="absolute left-1/2 top-[52%] h-[68vmin] w-[68vmin] -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#c3352b]/40"
        animate={{ rotate: 360 }}
        transition={{ duration: 24, repeat: Infinity, ease: 'linear' }}
      />
      <motion.div
        className="absolute left-1/2 top-[52%] h-[56vmin] w-[56vmin] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-[#1a1f4a]/20"
        animate={{ rotate: -360 }}
        transition={{ duration: 31, repeat: Infinity, ease: 'linear' }}
      />

      <div className="absolute left-[8vw] top-[8vh] z-20">
        <motion.p
          className="scene-mono m-0 text-[1.9vmin] text-[#c3352b]"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.18 }}
        >
          DETAILS / 04
        </motion.p>
        <motion.h2
          className="scene-copy mt-[1.5vmin] text-[6.2vmin] font-semibold leading-[1.3] tracking-[-.04em]"
          dir="rtl"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.58, delay: 0.28, ease: EASE }}
        >
          كل تفصيل
          <br />
          <span className="text-[#c3352b]">له مكان.</span>
        </motion.h2>
      </div>

      <motion.div
        className="absolute left-[16vw] top-[28vh] h-[56vh] w-[72vw]"
        style={{ perspective: '1200px', transformStyle: 'preserve-3d' }}
        initial={{ scale: 0.78, rotateY: 12, rotateZ: 2, opacity: 0 }}
        animate={{ scale: 1, rotateY: 0, rotateZ: 0, opacity: 1 }}
        transition={{ duration: 0.9, delay: 0.16, ease: EASE }}
      >
        <motion.div
          className="soft-shadow absolute left-[0%] top-[9%] h-[70%] w-[33%] border border-[#1a1f4a]/16 bg-[#eee6d8] p-[2vmin]"
          initial={{ x: -70, rotateY: -20, rotateZ: -7, opacity: 0 }}
          animate={{ x: 0, rotateY: -8, rotateZ: -5, opacity: 1 }}
          transition={{ duration: 0.82, delay: 0.28, ease: EASE }}
        >
          <div className="scene-mono text-[1.55vmin] text-[#c3352b]">MA / SPECIMEN</div>
          <div className="absolute left-[12%] top-[31%] text-[9vmin] font-semibold leading-none text-[#1a1f4a]" dir="rtl">م</div>
          <div className="absolute bottom-[17%] left-[13%] h-[.85vmin] w-[60%] bg-[#1a1f4a]/70" />
          <div className="absolute bottom-[11%] left-[13%] h-[.75vmin] w-[41%] bg-[#c3352b]/65" />
          <div className="absolute right-[11%] top-[13%] h-[1.1vmin] w-[1.1vmin] rotate-45 bg-[#f4b52e]" />
        </motion.div>

        <motion.div
          className="soft-shadow absolute left-[33%] top-[1%] h-[91%] w-[31%] border-[.55vmin] border-[#1a1f4a] bg-[#c3352b] p-[1vmin]"
          initial={{ y: 80, rotateY: 8, rotateZ: 5, opacity: 0 }}
          animate={{ y: 0, rotateY: 0, rotateZ: 3, opacity: 1 }}
          transition={{ duration: 0.82, delay: 0.45, ease: EASE }}
        >
          <div className="relative h-full w-full border border-[#f6f0e4]/40">
            <div className="absolute left-[13%] top-[14%] h-[.85vmin] w-[43%] bg-[#f4b52e]" />
            <div className="absolute inset-x-[13%] top-[25%] h-[38%] bg-[#1a1f4a]">
              <div className="absolute right-[11%] top-[14%] h-[39%] w-[42%] border border-[#f4b52e]" />
              <div className="absolute bottom-[12%] left-[12%] h-[.65vmin] w-[56%] bg-[#f6f0e4]" />
            </div>
            <div className="absolute bottom-[15%] left-[13%] h-[.75vmin] w-[69%] bg-[#f6f0e4]/75" />
            <div className="absolute bottom-[10%] left-[13%] h-[.65vmin] w-[43%] bg-[#f6f0e4]/40" />
          </div>
        </motion.div>

        <motion.div
          className="soft-shadow absolute right-[0%] top-[19%] h-[66%] w-[34%] border border-[#1a1f4a]/15 bg-[#f6f0e4] p-[2vmin]"
          initial={{ x: 65, rotateY: 20, rotateZ: 8, opacity: 0 }}
          animate={{ x: 0, rotateY: 8, rotateZ: 6, opacity: 1 }}
          transition={{ duration: 0.84, delay: 0.62, ease: EASE }}
        >
          <div className="scene-mono text-[1.55vmin] text-[#837c71]">BOOKING FLOW</div>
          <div className="mt-[2vmin] grid h-[55%] grid-cols-3 grid-rows-2 gap-[.8vmin]">
            {[0, 1, 2, 3, 4, 5].map((cell) => (
              <span
                key={cell}
                className={`border ${cell === 4 ? 'border-[#c3352b] bg-[#c3352b]' : 'border-[#1a1f4a]/18 bg-[#eee6d8]'}`}
              />
            ))}
          </div>
          <div className="absolute bottom-[12%] left-[11%] h-[.8vmin] w-[62%] bg-[#1a1f4a]/60" />
          <div className="absolute bottom-[7%] left-[11%] h-[.7vmin] w-[42%] bg-[#1a1f4a]/25" />
        </motion.div>

        <svg className="pointer-events-none absolute inset-0 z-10 h-full w-full overflow-visible" viewBox="0 0 900 560" fill="none" aria-hidden="true">
          <motion.path
            d="M48 400 L170 278 L292 400 L414 278 L536 400 L658 278 L800 420"
            stroke="#F4B52E"
            strokeWidth="7"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 0.95 }}
            transition={{ duration: 1.5, delay: 0.56, ease: EASE }}
          />
          <motion.circle
            cx="450"
            cy="320"
            r="16"
            fill="#F4B52E"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 280, damping: 20, delay: 0.82 }}
          />
        </svg>
      </motion.div>

      <motion.div
        className="scene-mono absolute bottom-[7vh] right-[8vw] z-20 flex h-[4vmin] items-center justify-end text-[1.8vmin] text-[#1a1f4a]/65"
        key={tagIndex}
        initial={{ opacity: 0, x: 12 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3, ease: EASE }}
      >
        {tagIndex >= 0 && TAGS[tagIndex]}
      </motion.div>
    </motion.section>
  );
}
