import { motion } from 'framer-motion';

const EASE = [0.22, 1, 0.36, 1] as const;

export function Scene2() {
  return (
    <motion.section
      className="scene-ink absolute inset-0 overflow-hidden"
      initial={{ opacity: 0.8, scale: 1.055, filter: 'blur(10px)' }}
      animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
      exit={{ opacity: 0, scale: 1.04, rotateY: -5, filter: 'blur(8px)' }}
      transition={{ duration: 0.62, ease: EASE }}
    >
      <div className="sadu-grid absolute inset-0 opacity-[.3]" aria-hidden="true" />
      <motion.div
        className="absolute -left-[20vmin] top-[21%] h-[78vmin] w-[78vmin] rounded-full border border-[#f6f0e4]/10"
        animate={{ rotate: 360 }}
        transition={{ duration: 26, repeat: Infinity, ease: 'linear' }}
      />
      <motion.div
        className="absolute -left-[15vmin] top-[25%] h-[67vmin] w-[67vmin] rounded-full border border-[#f4b52e]/30"
        animate={{ rotate: -360 }}
        transition={{ duration: 32, repeat: Infinity, ease: 'linear' }}
      />

      <div className="absolute left-[7vw] top-[20vh] z-20 w-[37vw]">
        <motion.p
          className="scene-mono mb-[2vmin] text-[1.9vmin] text-[#f4b52e]"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.18 }}
        >
          A DIGITAL EXPERIENCE
        </motion.p>
        <motion.h2
          className="scene-copy m-0 text-[7.6vmin] font-semibold leading-[1.4] tracking-[-.035em]"
          dir="rtl"
          initial={{ clipPath: 'inset(0 0 100% 0)' }}
          animate={{ clipPath: 'inset(0 0 0% 0)' }}
          transition={{ duration: 0.72, delay: 0.34, ease: EASE }}
        >
          الفكرة
          <br />
          تأخذ شكلًا
        </motion.h2>
        <motion.p
          className="scene-body mt-[2.6vmin] text-[3vmin] text-[#f6f0e4]/65"
          dir="rtl"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.45, delay: 0.94 }}
        >
          بنية واضحة، وتجربة سهلة.
        </motion.p>
      </div>

      <motion.div
        className="absolute right-[9vw] top-[10vh] h-[77vh] w-[47vw] origin-center"
        initial={{ scale: 0.68, rotateY: -22, rotateZ: 4, x: 90, opacity: 0 }}
        animate={{ scale: 1, rotateY: -7, rotateZ: -2, x: 0, opacity: 1 }}
        transition={{ duration: 1.1, delay: 0.2, ease: EASE }}
        style={{ perspective: '1100px', transformStyle: 'preserve-3d' }}
      >
        <motion.div
          className="absolute right-[5%] top-[6%] h-[88%] w-[85%] border border-[#f6f0e4]/35 bg-[#f6f0e4] p-[1.2vmin] text-[#1a1f4a] shadow-[0_3vmin_9vmin_rgba(0,0,0,.32)]"
          animate={{ y: [0, -0.7, 0] }}
          transition={{ duration: 4.6, repeat: Infinity, ease: 'easeInOut' }}
        >
          <div className="flex h-[7%] items-center gap-[.7vmin] border-b border-[#1a1f4a]/15 px-[1.1vmin]">
            <i className="h-[.7vmin] w-[.7vmin] rounded-full bg-[#c3352b]" />
            <i className="h-[.7vmin] w-[.7vmin] rounded-full bg-[#f4b52e]" />
            <i className="h-[.7vmin] w-[.7vmin] rounded-full bg-[#1a1f4a]/30" />
            <div className="ml-[1vmin] h-[.8vmin] w-[34%] rounded-full bg-[#1a1f4a]/10" />
            <div className="ml-auto h-[.8vmin] w-[11%] rounded-full bg-[#c3352b]/60" />
          </div>
          <div className="relative flex h-[88%] overflow-hidden">
            <div className="absolute inset-0 bg-[#e7dece]" />
            <div className="absolute left-[8%] top-[14%] w-[45%]">
              <div className="mb-[1.8vmin] h-[1vmin] w-[33%] bg-[#c3352b]" />
              <div className="mb-[1.1vmin] h-[2.1vmin] w-[90%] bg-[#1a1f4a]" />
              <div className="mb-[1.1vmin] h-[2.1vmin] w-[72%] bg-[#1a1f4a]" />
              <div className="mt-[2vmin] h-[.9vmin] w-[76%] bg-[#1a1f4a]/25" />
              <div className="mt-[.9vmin] h-[.9vmin] w-[59%] bg-[#1a1f4a]/25" />
              <div className="mt-[2.4vmin] h-[3.3vmin] w-[18vmin] bg-[#c3352b]" />
            </div>
            <motion.div
              className="absolute bottom-[11%] right-[8%] h-[52%] w-[31%] bg-[#1a1f4a]"
              initial={{ scaleY: 0, transformOrigin: 'bottom' }}
              animate={{ scaleY: 1 }}
              transition={{ duration: 0.7, delay: 1.08, ease: EASE }}
            >
              <div className="absolute inset-x-[13%] top-[17%] h-[42%] border border-[#f4b52e]/75" />
              <div className="absolute bottom-[13%] left-[15%] h-[.8vmin] w-[61%] bg-[#f6f0e4]" />
              <div className="absolute bottom-[7%] left-[15%] h-[.7vmin] w-[43%] bg-[#f6f0e4]/45" />
            </motion.div>
            <div className="absolute bottom-[8%] left-[8%] h-[.8vmin] w-[38%] bg-[#1a1f4a]/20" />
          </div>
        </motion.div>

        <motion.div
          className="soft-shadow absolute bottom-[1%] left-[4%] h-[51%] w-[22%] border-[.65vmin] border-[#f6f0e4] bg-[#c3352b] p-[.9vmin]"
          initial={{ y: 90, x: -40, rotateZ: -12, opacity: 0 }}
          animate={{ y: 0, x: 0, rotateZ: -8, opacity: 1 }}
          transition={{ duration: 0.74, delay: 0.82, ease: EASE }}
        >
          <div className="relative h-full w-full border border-[#f6f0e4]/40">
            <div className="absolute left-[12%] top-[18%] h-[1vmin] w-[55%] bg-[#f6f0e4]/80" />
            <div className="absolute left-[12%] top-[25%] h-[1vmin] w-[42%] bg-[#f6f0e4]/45" />
            <div className="absolute inset-x-[12%] top-[39%] h-[31%] border border-[#f4b52e]" />
            <div className="absolute bottom-[11%] left-[12%] h-[.75vmin] w-[67%] bg-[#f6f0e4]/65" />
          </div>
        </motion.div>

        <motion.svg
          className="absolute -left-[11%] top-[57%] z-20 h-[20%] w-[54%] overflow-visible"
          viewBox="0 0 440 150"
          fill="none"
          aria-hidden="true"
        >
          <motion.path
            d="M8 136 L98 44 L188 136 L278 44 L370 136 L432 74"
            stroke="#F4B52E"
            strokeWidth="8"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1, delay: 1.25, ease: EASE }}
          />
        </motion.svg>
      </motion.div>

      <motion.div
        className="absolute bottom-[7vh] left-[7vw] flex items-center gap-[1.2vmin] text-[#f6f0e4]/40"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.35, duration: 0.4 }}
      >
        <span className="h-[.65vmin] w-[.65vmin] rotate-45 bg-[#f4b52e]" />
        <span className="scene-mono text-[1.8vmin]">STRUCTURE / CLARITY / CARE</span>
      </motion.div>
    </motion.section>
  );
}
