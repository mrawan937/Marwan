import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useSceneTimer } from '@/lib/video';

const EASE = [0.22, 1, 0.36, 1] as const;
const SERVICES = [
  { word: 'مواقع', label: 'WEB', kind: 'page' },
  { word: 'تجارب', label: 'UI · UX', kind: 'mobile' },
  { word: 'أنظمة', label: 'BOOKING', kind: 'flow' },
] as const;

export function Scene3() {
  const [active, setActive] = useState(0);
  const [summary, setSummary] = useState(false);
  useSceneTimer([
    { time: 1510, callback: () => setActive(1) },
    { time: 2820, callback: () => setActive(2) },
    { time: 3950, callback: () => setSummary(true) },
  ]);

  return (
    <motion.section
      className="scene-carmine absolute inset-0 overflow-hidden"
      initial={{ opacity: 0.8, clipPath: 'inset(0 8% 0 8%)', scale: 1.06 }}
      animate={{ opacity: 1, clipPath: 'inset(0 0% 0 0%)', scale: 1 }}
      exit={{ opacity: 0, clipPath: 'inset(0 0 0 100%)', scale: 0.96 }}
      transition={{ duration: 0.52, ease: EASE }}
    >
      <div className="absolute inset-0" aria-hidden="true">
        <div className="absolute inset-y-0 left-[33.333%] w-px bg-[#f6f0e4]/22" />
        <div className="absolute inset-y-0 left-[66.666%] w-px bg-[#f6f0e4]/22" />
        <div className="absolute -right-[22vmin] -top-[38vmin] h-[84vmin] w-[84vmin] rotate-45 border border-[#f6f0e4]/18" />
        <div className="absolute -right-[10vmin] -top-[26vmin] h-[60vmin] w-[60vmin] rotate-45 border border-[#f4b52e]/65" />
      </div>

      <div className="absolute left-[6vw] top-[6vh] z-20">
        <p className="scene-mono m-0 text-[1.9vmin] text-[#f6f0e4]/65">DIGITAL CRAFT / 03</p>
      </div>

      <div className="absolute left-1/2 top-[17vh] z-10 flex w-[88vw] -translate-x-1/2 flex-col items-center">
        <AnimatePresence mode="sync">
          <motion.div
            key={active}
            className="absolute top-0 flex flex-col items-center"
            initial={{ scale: 1.24, opacity: 0, filter: 'blur(9px)', y: 18 }}
            animate={{ scale: 1, opacity: 1, filter: 'blur(0px)', y: 0 }}
            exit={{ scale: 0.72, opacity: 0, filter: 'blur(8px)', y: -24 }}
            transition={{ duration: 0.38, ease: EASE }}
          >
            <span
              className="scene-copy whitespace-nowrap font-semibold leading-[1.12] tracking-[-.06em] text-[#f6f0e4]"
              dir="rtl"
              style={{ fontSize: '29vmin' }}
            >
              {SERVICES[active].word}
            </span>
            <span className="scene-mono mt-[.5vmin] text-[2.2vmin] text-[#f4b52e]">
              {SERVICES[active].label}
            </span>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="absolute bottom-[7vh] left-[6vw] right-[6vw] z-20 flex h-[30vh] items-end justify-center gap-[2vw]">
        {SERVICES.map((service, index) => {
          const selected = index === active;
          return (
            <motion.div
              key={service.kind}
              className={`relative flex h-full flex-1 items-center justify-center border p-[1.6vmin] ${selected ? 'border-[#f4b52e] bg-[#1a1f4a] shadow-[0_1.8vmin_4vmin_rgba(26,31,74,.28)]' : 'border-[#f6f0e4]/26 bg-[#a22d28]/28'}`}
              animate={{ scale: selected ? 1 : 0.91, y: selected ? 0 : 6, opacity: selected ? 1 : 0.6 }}
              transition={{ duration: 0.44, ease: EASE }}
            >
              {service.kind === 'page' && (
                <div className="h-[81%] w-[88%] border border-[#f6f0e4]/55 bg-[#f6f0e4] p-[1vmin]">
                  <div className="mb-[1.2vmin] h-[.7vmin] w-[31%] bg-[#c3352b]" />
                  <div className="h-[1.2vmin] w-[75%] bg-[#1a1f4a]" />
                  <div className="mt-[.7vmin] h-[1.2vmin] w-[51%] bg-[#1a1f4a]" />
                  <div className="mt-[1.3vmin] h-[35%] w-full bg-[#d9cfbe]" />
                </div>
              )}
              {service.kind === 'mobile' && (
                <div className="relative h-[92%] w-[24%] min-w-[6.2vmin] rounded-[1.3vmin] border-[.55vmin] border-[#f6f0e4] bg-[#c3352b] p-[.55vmin]">
                  <div className="h-full w-full border border-[#f6f0e4]/45">
                    <div className="mx-auto mt-[1.4vmin] h-[.6vmin] w-[48%] bg-[#f4b52e]" />
                    <div className="mx-[.6vmin] mt-[1vmin] h-[20%] bg-[#f6f0e4]/25" />
                    <div className="mx-[.6vmin] mt-[.7vmin] h-[.65vmin] bg-[#f6f0e4]/70" />
                    <div className="mx-[.6vmin] mt-[.5vmin] h-[.65vmin] w-[70%] bg-[#f6f0e4]/40" />
                  </div>
                </div>
              )}
              {service.kind === 'flow' && (
                <div className="grid h-[77%] w-[74%] grid-cols-3 grid-rows-2 gap-[.8vmin]">
                  {[0, 1, 2, 3, 4, 5].map((cell) => (
                    <span
                      key={cell}
                      className={`border ${cell === 4 ? 'border-[#f4b52e] bg-[#f4b52e]' : 'border-[#f6f0e4]/40 bg-[#f6f0e4]/10'}`}
                    />
                  ))}
                </div>
              )}
              <span className="scene-mono absolute bottom-[.8vmin] right-[1vmin] text-[1.5vmin] text-[#f6f0e4]/55">
                0{index + 1}
              </span>
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {summary && (
          <motion.p
            className="scene-body absolute bottom-[3.3vh] left-1/2 z-30 m-0 -translate-x-1/2 text-[3.1vmin] text-[#f6f0e4]"
            dir="rtl"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.28, ease: EASE }}
          >
            تخدم الفكرة بوضوح
          </motion.p>
        )}
      </AnimatePresence>
    </motion.section>
  );
}
