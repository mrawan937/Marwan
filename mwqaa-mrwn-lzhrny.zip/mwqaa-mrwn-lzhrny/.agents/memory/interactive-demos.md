---
name: Interactive demo policy
description: How to present functional portfolio demos without implying fictional samples are client work or real transactions.
---

Keep interactive examples clearly distinguished from actual client projects. Every showcased service or demo should have a relevant image or illustration and a recognizable icon, with no empty media placeholders. Use illustrative sample data, require no personal/contact details, and keep demo state local to the page. State before interaction that demos do not create real bookings/orders, call APIs, send email, or persist data.

**Why:** The owner wants visitors to verify working interfaces and see complete visual presentation, while portfolio credibility requires that sample flows not be mistaken for completed customer work or real transactions.

**How to apply:** For new portfolio demos, create a dedicated demo section/page and disclose the limits in both Arabic and English; do not add these samples to the client-work gallery.

The owner liked the practical, browser-local tool approach and wants additions to be distinct from existing demos rather than duplicates.

**Why:** The owner explicitly praised the project brief and launch checklist and asked for more useful work.

**How to apply:** Prefer new, working utilities with clear boundaries, such as local text formatting or accessibility calculations, and make each one reachable from the portfolio.

For Quran and hadith content, use attributed primary-source text and real human recitation recordings only; never present browser or generated speech as an authentic religious recording. If a trustworthy recording for an individual dhikr is unavailable, say so instead of fabricating one. A common 99-name enumeration must not be described as the exact wording or order of the hadith.

**Why:** The owner specifically rejected poor synthetic voices and asked for genuine, verifiable verses, adhkar, hadith, and names.

**How to apply:** Keep the source and reciter visible, request external audio only after the visitor asks to load it, and make any gaps in verified adhkar recordings explicit.
