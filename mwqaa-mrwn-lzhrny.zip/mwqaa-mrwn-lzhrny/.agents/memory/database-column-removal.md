---
name: Dropping database columns
description: Safe development workflow for removing PostgreSQL columns from this project.
---

When removing PostgreSQL columns in development, drop them explicitly with `psql` before running Drizzle push. Drizzle's interactive push may interpret removed columns as rename candidates and then wait for confirmation in a TTY.

**Why:** A non-interactive schema push can stall on the rename prompt, and accepting the wrong action can preserve columns that were meant to be removed.

**How to apply:** Confirm the exact development columns to remove, drop only those columns with `psql`, then run the usual Drizzle push. Do not apply this development workflow to production; production schema changes go through Publish.