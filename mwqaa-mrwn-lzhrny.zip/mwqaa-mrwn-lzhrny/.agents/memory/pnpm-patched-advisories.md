---
name: Patched-package audit reports
description: Handling a pnpm advisory when the upstream package has no published fixed version.
---

When an upstream package has no patched release, a `pnpm.patchedDependencies` security fix may still appear in `pnpm audit` under the vulnerable upstream version. Do not hide the advisory by falsifying package metadata or suppressing the report. Keep the narrow patch, test both safe behavior and the exploit-shaped input, and report the remaining version-based audit finding explicitly.

**Why:** In this workspace, the `braces` advisory had no published fixed version, while the vulnerable implementation could be mitigated with a bounded nesting parser guard.

**How to apply:** Recheck whether upstream has released a fix during later dependency maintenance; replace the local patch with the official compatible release when available and confirm the audit result. To verify a patched transitive dependency, resolve it from the consuming package's dependency graph rather than the workspace root, then test normal and exploit-shaped inputs.
