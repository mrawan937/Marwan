---
name: Admin login visibility
description: Public-facing visibility of the owner-only dashboard sign-in.
---

Do not show an owner sign-in link in the public site's navigation or footer. Keep the authenticated dashboard and direct `/admin` route available to the owner.

**Why:** Public visitors were clicking the owner link and reaching the sign-in page, which is confusing for customer-facing navigation.

**How to apply:** Remove public entry links rather than changing authentication or deleting the admin routes.