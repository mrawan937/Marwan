---
name: Verification recipes for this site
description: How to test owner-only API routes without an auth bypass, screenshot pitfalls, test-data hygiene, and the real-email side effect of form tests.
---

## Owner-only API routes can't be called with curl
The dashboard endpoints require a Clerk session plus an `ADMIN_EMAILS` match, and the screenshot browser can't sign in.
**How to apply:** for an end-to-end check, write a throwaway entry that mounts the real admin router on a bare express app, bundle it with esbuild, and use an esbuild `onResolve` plugin to swap only the `lib/admin` module for a stub that calls `next()`. Run it against the dev DB, then delete the entry and the bundle.
**Why:** this tests the real handlers, SQL and Zod response parsing while leaving production auth untouched. A temporary bypass in app code could ship by accident.

## Signed-in dashboard UI needs the browser tester
The screenshot browser is always signed out, so it only ever shows the sign-in page for /admin.
**How to apply:** have the tester sign in to Clerk programmatically as a generated `owner-<nanoid>@example.com`. Clerk marks emails created through its backend as verified, so that user passes the verified-email check. Then have the tester restart the API workflow with a runtime `ADMIN_EMAILS` override that adds that address, and restart it again without overrides at the end. Afterwards, delete the `@example.com` users from the dev Clerk instance, and delete the test rows and reset the sequence.
**Why:** this exercises the real owner check without editing the shared `ADMIN_EMAILS` env and without creating an account under the owner's real email.

## Full-page screenshots look blank in the middle
Sections use framer-motion `whileInView` reveals, and a `fullPage` capture doesn't scroll, so those sections stay invisible.
**How to apply:** take a tall `viewportSize` (e.g. 1280x3000) instead of `fullPage` to see below-the-fold sections.

## Test-data hygiene
The owner wants a real site, not demo data. Never seed fake requests.
**How to apply:**
- Delete any rows created by curl tests.
- If the table is empty afterwards, restart `project_requests_id_seq` at 1, so the first real request becomes MZ-0001.
- The form's rate limiter keeps its counts in memory. Restart the API after testing it, or your own IP stays blocked for 15 minutes.

## Every form submission emails the owner for real
Each successful POST to the request form sends a Gmail alert from the owner's own account to everyone in `ADMIN_EMAILS`, so it lands in his real inbox.
**How to apply:** keep form-submission tests to a minimum and tell the user before sending any. Label test requests clearly (e.g. "تجربة …"), use his own number so no stranger gets contacted, and delete them afterwards. If a tester run overrides `ADMIN_EMAILS` with an `@example.com` address, the alert goes there and the bounce lands in his Gmail, so avoid submitting the form in that run. To confirm a send without opening his mail, read the message back with `format=metadata` through the connectors SDK (run node from the api-server directory).
**Why:** the user agreed to one test email only. Surprise emails or bounces would look like spam or a malfunction to him.

## Bundle API tests before running them with Node
The API TypeScript source uses bundler-style extensionless relative imports, which Node's native ESM resolver cannot load directly from a test importing `.ts` files.
**How to apply:** bundle the `.mjs` test entry and its TypeScript source dependencies with the already-installed esbuild CLI, leave npm packages external, then run the generated file with `node --test` and remove it afterward.
**Why:** this keeps tests dependency-free while exercising the actual source helpers without changing the API's production module format.
