---
name: Private conversation flow
description: Project-specific rule for customer contact and replies on Marwan Alzahrani’s site.
---

Customer requests and conversation replies should stay in the site’s private conversation flow. Do not add direct WhatsApp, phone, or email contact buttons.

**Why:** The user wants customer communication to remain private and connected to each project request on the site.

**How to apply:** Preserve this flow when editing contact calls to action, request copy, navigation, or messaging features. Optional email alerts may notify customers about replies, but conversation replies themselves stay on the site.

Customer accounts are optional: submissions made while signed in are linked to that Clerk account; guest submissions remain available through their private conversation links. Do not automatically claim older guest requests by matching an unverified email.

**Why:** Keep request submission accessible to guests while limiting account access to requests linked through an authenticated identity.

**How to apply:** Keep guest forms working. Only use the server-verified Clerk user ID when associating a new request with an account; require a secure verification flow before linking legacy requests.