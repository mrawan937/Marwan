# مروان الزهراني — Marwan Alzahrani

Permanent bilingual (Arabic-first, English toggle) personal-brand and client website for Marwan Alzahrani, a Saudi web & mobile developer: services as products, real portfolio and CV, a project-request form, private on-site client conversations, a community corner (discounted package for productive families/charities + free Smart Tasbeeh web tool), and a private owner-only dashboard.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm --filter @workspace/marwan-alzahrani run dev` — run the website (Vite)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL`, Clerk keys (auto-provisioned), `ADMIN_EMAILS` (comma-separated owner emails allowed into the dashboard and notified about new requests and client messages)
- Integration: Gmail connector (`google-mail`, the owner's own account) sends owner alerts and a one-line client reply alert when the client provided an email address

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Web: React + Vite + Tailwind v4 + wouter (artifact `artifacts/marwan-alzahrani`, served at `/`)
- API: Express 5 (`artifacts/api-server`), PostgreSQL + Drizzle ORM, Zod, Orval codegen
- Auth: Replit-managed Clerk (owner login only)

## Where things live

- API contract (source of truth): `lib/api-spec/openapi.yaml`
- DB schema: `lib/db/src/schema/`
- API routes: `artifacts/api-server/src/routes/` (public `projectRequests.ts` and `conversations.ts`, owner-only `admin.ts`)
- Owner check: `artifacts/api-server/src/lib/admin.ts`
- New-request email alert (Arabic RTL email, Gmail connector): `artifacts/api-server/src/lib/notify.ts`
- Site content (services, CV, portfolio) is static bilingual frontend content inside the web artifact

## Architecture decisions

- Persistent backend data includes project requests, private conversation messages, push subscriptions and VAPID settings; all marketing/CV content is static frontend content.
- Dashboard access = signed in with Clerk AND a verified email listed in `ADMIN_EMAILS`. Signed-out → 401, other accounts → 403.
- The home page stays public even when the owner is signed in (no redirect to the dashboard); after sign-in the owner lands on `/admin`.
- Request references are derived from the row id (`MZ-0007`), not stored.
- Enum-like columns are plain text validated by the OpenAPI/Zod enums, so adding a service needs no DB migration.
- The public form is rate limited in memory per IP (5 per 15 minutes); restarting the API resets it.
- Smart Tasbeeh is client-side only (localStorage).
- New requests and the first unread client message alert the owner addresses in `ADMIN_EMAILS`. Client reply alerts are sent only when the client supplied an email address; all actual conversation replies stay on the private site page.
- Notification tokens are stored in the client's browser; treat each conversation URL as a secret and never expose access tokens in logs or admin API responses.
- Email sends are awaited (8s timeout) before responding because published servers may pause work after the response; a failed email is logged and never fails the request or message (it remains saved in the dashboard).
- Links in that email use only this app's own hosts (`REPLIT_DOMAINS` / `REPLIT_DEV_DOMAIN`); the request's `Origin` is used only if it matches one, so a forged header can't plant an outside link.

## Product

- Public: home, service product pages (`/services/:slug`), request form (`/request?service=`), community corner (`/community`), free tasbeeh (`/tasbeeh`).
- Client: `/c` saved conversation list and `/c/:token` private conversation, status tracking, unread reply indicators, browser notifications and optional email alerts.
- Owner: `/admin` overview, `/admin/requests` list with filters/search/unread badges, `/admin/requests/:id` details with status, private notes, message thread, replies and delete.

## User preferences

- The user writes in Arabic; reply in Arabic.
- Never invent testimonials, numbers, client names or prices. Prices show as "اطلب عرض سعر" until Marwan provides his own.
- No stock or generated photos representing Marwan; he may send his own photo later.

## Gotchas

- `lib/api-client-react/tsconfig.json` needs `dom.iterable` in `lib` — the Orval-generated client calls `Headers.entries()`.
- Clerk's `arSA` localization leaves some strings undefined (e.g. email/password input placeholders), so they show in English unless overridden in `App.tsx`.
- `og:image` is still a relative path; social previews (WhatsApp) need the absolute production URL once the site is published.
- Drizzle's interactive push can interpret dropped columns as renames and requires a TTY; explicitly drop removed development columns with psql before running schema push.
- Clerk + Tailwind v4: keep `@layer theme, base, clerk, components, utilities;` before the tailwind import and `tailwindcss({ optimize: false })` in vite config, or Clerk UI breaks in production builds.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- See the `clerk-auth` skill for auth wiring and customization
